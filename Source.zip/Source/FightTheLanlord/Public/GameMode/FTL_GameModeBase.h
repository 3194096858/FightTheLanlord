﻿
#pragma once
//#include "GameState/FTL_GameStateBase.h"

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "FTL_GameModeBase.generated.h"

class AFTL_GameStateBase;
class UFTL_GameInstance;
class UFTL_AssetManger;

class UAudioManager;
class UDelegateManager;


UCLASS()
class FIGHTTHELANLORD_API AFTL_GameModeBase : public AGameModeBase
{
	GENERATED_BODY()
public:
	AFTL_GameModeBase();
protected:
	virtual void BeginPlay() override;
public:
	virtual void Tick(float DeltaTime) override;
	virtual void PostLogin(APlayerController* NewPlayer) override;
	virtual void Logout(AController* Exiting) override;



public:


private:
	
	UPROPERTY()
	TObjectPtr<UFTL_GameInstance> GameInstance;

public:

protected:
	UFUNCTION()
	bool GetIsInServer();
	UFUNCTION()
	UFTL_GameInstance* GetGameInstance();

private:
	

};
