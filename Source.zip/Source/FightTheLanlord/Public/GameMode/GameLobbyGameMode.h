﻿
#pragma once

#include "CoreMinimal.h"
#include "GameMode/FTL_GameModeBase.h"
#include "GameLobbyGameMode.generated.h"

UCLASS()
class FIGHTTHELANLORD_API AGameLobbyGameMode : public AFTL_GameModeBase
{
	GENERATED_BODY()

public:
	AGameLobbyGameMode();
protected:
	virtual void BeginPlay() override;
public:
	virtual void Tick(float DeltaTime) override;
	virtual void PostLogin(APlayerController* NewPlayer) override;
	virtual void Logout(AController* Exiting) override;

private:
	

public:
	UFUNCTION()
	int32 GetCurrentPlayerNumber();


};
