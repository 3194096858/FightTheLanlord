﻿
#pragma once
#include "Struct/GameplayInformation.h"

#include "Struct/CardInformation.h"
#include "Enum/HandType.h"
#include "Struct/HandTypeInformation.h"
#include "CoreMinimal.h"
#include "GameMode/FTL_GameModeBase.h"
#include "BattleGameMode.generated.h"

class ABattleLevelPlayerController;

USTRUCT()
struct FTurnHandTypeInformation
{
	GENERATED_BODY()
	FHandTypeInformation Information;
	int32 PlayerID = -1;

};




UCLASS()
class FIGHTTHELANLORD_API ABattleGameMode : public AFTL_GameModeBase
{
	GENERATED_BODY()

public:
	ABattleGameMode();
protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(EEndPlayReason::Type EndPlayReason) override;
public:
	virtual void Tick(float DeltaTime) override;
	virtual void PostLogin(APlayerController* NewPlayer) override;
	virtual void Logout(AController* Exiting) override;
	virtual void PreLogin(const FString& Options, const FString& Address, const FUniqueNetIdRepl& UniqueId, FString& ErrorMessage);
	virtual void InitGame(const FString& MapName, const FString& Options, FString& ErrorMessage) override;
public:


private:
	FGameplayInformation GameplayInformation;
	FTimerHandle CountdownTimerHandle;
	TMap<int32, TArray<FCardInformation>> PlayerCardHandMap;
	TMap<int32, TArray<FCardInformation>> AIPlayerCardHandMap;
	TMap<int32, int32> PlayerAFKNumberMap;
	TMap<int32,FString> ClientGUIDMap;
	int32 LanlordPlayerID = -1;
	int32 CurrentTurnPlayerID = -1;
	int32 WinnerPlayerID = -1;
	FTurnHandTypeInformation CurrentTurnHandTypeInformation;
	FTurnHandTypeInformation LastTurnHandTypeInformation;
	int32 TurnTimeleft = 30;
	TArray<FCardInformation> HoleCardArray;
	FTimerHandle QuitSessionTimerHandle;
	bool IsGameOver = false;
	bool IsGameStart = false;

public:
	UFUNCTION()
	bool CheckClientGUIDIsExist(const FString& GUID);
	UFUNCTION()
	void OnCheckClientGUIDComplete(const FString& GUID,bool IsExist);
	UFUNCTION()
	void AddClientGUID(int32 PlayerID,const FString& GUID);
	UFUNCTION()
	void OnPlayerTimeout();
	UFUNCTION()
	void OnPlayerSendMessage(int32 PlayerID, const FString& Message);
	UFUNCTION()
	FTurnHandTypeInformation GetLastTurnHandTypeInformation();
	UFUNCTION()
	int32 GetCurrentPlayerNumber();
	UFUNCTION()
	void QuitSession();
	UFUNCTION()
	void OnDealCardComplete(int32 PlayerID);
	UFUNCTION()
	TArray<FCardInformation> GetPlayerCardHand(int32 PlayerID);
	UFUNCTION()
	void OnGameStart();
	UFUNCTION()
	void OnGameOver();
	UFUNCTION()
	int32 GetHandTypeValue(const TArray<FCardInformation>& CardArray);
	UFUNCTION()
	EHandType CheckIsLegalHandType(const TArray<FCardInformation>& CardArray);
	UFUNCTION()
	bool CheckHandTypeIsTripletWithKicker(const TArray<FCardInformation>& CardArray);
	UFUNCTION()
	bool CheckHandTypeIsAirplane(const TArray<FCardInformation>& CardArray);
	UFUNCTION()
	bool CheckHandTypeIsAirplaneWithWing(const TArray<FCardInformation>& CardArray);
	UFUNCTION()
	bool CheckHandTypeIsSingleStraight(const TArray<FCardInformation>& CardArray);
	UFUNCTION()
	bool CheckHandTypeIsPairStraight(const TArray<FCardInformation>& CardArray);
	UFUNCTION()
	bool CheckHandTypeIsFourWithTwo(const TArray<FCardInformation>& CardArray);
	UFUNCTION()
	void OnPlayerPlayCard(int32 PlayerID, const TArray<FCardInformation>& CardArray);
	UFUNCTION()
	void OnAIPlayerPlayCard(int32 PlayerID, TArray<FCardInformation> CardArray);
	UFUNCTION()
	void OnPlayerPass(int32 PlayerID);
	UFUNCTION()
	void OnTurnStart(int32 PlayerID);
	UFUNCTION()
	void OnTurnEnd(int32 PlayerID);
	UFUNCTION()
	int32 GetCurrentTurnPlayerID();
	UFUNCTION()
	int32 GetLanlordPlayerID();
	UFUNCTION()
	void InitializePlayerID(APlayerController* PlayerController);
private:
	void InitializePlayerHoleCard(APlayerController* PlayerController);
	UFUNCTION()
	void InitializePlayerCardHand(APlayerController* PlayerController);
	UFUNCTION()
	void Countdown();
	UFUNCTION()
	ABattleLevelPlayerController* GetCurrentTurnPlayerController();
	ABattleLevelPlayerController* GetPlayerController(int32 PlayerID);
	ABattleLevelPlayerController* GetPlayerController(const FString& GUID);
	UFUNCTION()
	TArray<ABattleLevelPlayerController*> GetAllPlayerController();
	UFUNCTION()
	void RemoveCardFromPlayerCardHand(int32 PlayerID, const TArray<FCardInformation>& CardArray);
};
