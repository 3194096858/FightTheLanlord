﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameMode/FTL_GameModeBase.h"
#include "MainGameMode.generated.h"


UCLASS()
class FIGHTTHELANLORD_API AMainGameMode : public AFTL_GameModeBase
{
	GENERATED_BODY()
public:
	AMainGameMode();
protected:
	virtual void BeginPlay() override;
public:
	virtual void Tick(float DeltaTime) override;

private:
	
public:



};
