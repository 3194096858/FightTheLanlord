﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once
#include "Enum/PlayerPlayCardFailureReason.h"

#include "Struct/CardInformation.h"
////#include "Struct/HandTypeInformation.h"
#include "Enum/HandType.h"
#include "CoreMinimal.h"
#include "PlayerController/PlayerControllerBase.h"
#include "BattleLevelPlayerController.generated.h"




UCLASS()
class FIGHTTHELANLORD_API ABattleLevelPlayerController : public APlayerControllerBase
{
	GENERATED_BODY()

public:
	ABattleLevelPlayerController();
protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(EEndPlayReason::Type EndPlayResason) override;
	virtual void OnRep_PlayerState() override;
public:
	virtual void Tick(float DeltaTime) override;

public:

private:

public:
	UFUNCTION(Client, Unreliable)
	void Client_OnServerCheckClientGUIDComplete(bool IsExist);
	UFUNCTION(Client, Unreliable)
	void Client_CheckClientGUIDIsExistInServer();
	UFUNCTION(Server, Unreliable)
	void Server_CheckClientGUIDIsExistInServer(const FString& GUID);
	UFUNCTION(Client, Unreliable)
	void Client_AddClientGUIDToServer();
	UFUNCTION(Server, Unreliable)
	void Server_AddClientGUIDToServer(int32 PlayerID, const FString& GUID);
	UFUNCTION(Server, Unreliable)
	void Server_SendMessage(int32 PlayerID,const FString& Message);
	UFUNCTION(Client, Unreliable)
	void Client_SendMessage(int32 PlayerID,const FString& Message);
	/*UFUNCTION(Client, Unreliable)
	void Client_OnPlayerLogout();*/
	UFUNCTION(Client, Unreliable)
	void Client_PlaySFX(EHandType HandType, int32 Value);
	UFUNCTION(Server, Unreliable)
	void Server_PlaySFX(const TArray<FCardInformation>& CardArray);
	UFUNCTION(Client, Unreliable)
	void Client_OnGameOver(int32 LanlordPlayerID, int32 WinnerPlayerID);
	UFUNCTION()
	int32 GetPlayerID();
	UFUNCTION(Client, Unreliable)
	void Client_SetCountdownTimerText(int32 CurrentSecond);
	UFUNCTION(Client, Unreliable)
	void Client_OnTurnStart(int32 PlayerID);
	UFUNCTION(Client, Unreliable)
	void Client_OnTurnEnd(int32 PlayerID);
	UFUNCTION(Server, Unreliable)
	void Server_PlayCard(int32 PlayerID, const TArray<FCardInformation>& CardArray);
	UFUNCTION(Client, Unreliable)
	void Client_PlayCard();
	UFUNCTION(Client, Unreliable)
	void Client_Pass();
	UFUNCTION(Server, Unreliable)
	void Server_Pass(int32 PlayerID);
	UFUNCTION(Client, Unreliable)
	void Client_AddCardToPlayerCardHand(const TArray<FCardInformation>& CardArray);
	UFUNCTION(Client, Unreliable)
	void Client_OnPlayCardFailed(const EPlayerPlayCardFailureReason& FailureReason);
	UFUNCTION(Client, Unreliable)
	void Client_OnPlayerPlayCardSucceed(int32 PlayerID,const TArray<FCardInformation>& CardArray);
	UFUNCTION(Client, Unreliable)
	void Client_UpdatePlayerCardNumber(int32 PlayerID, int32 NewValue);
	UFUNCTION(Server, Unreliable)
	void Server_OnDealCardComplete(int32 PlayerID);
	UFUNCTION(Client, Unreliable)
	void Client_InitializeHoleCard(const TArray<FCardInformation>& CardArray);
	UFUNCTION(Client, Unreliable)
	void Client_OnPlayerPass(int32 PlayerID);
protected:
	virtual void Client_BeginPlay_Implementation() override;
	virtual void Client_EndPlay_Implementation() override;
private:
	UFUNCTION()
	void OnDealCardComplete();



};
