﻿
#pragma once


#include "Components/CanvasPanelSlot.h"

#include "CoreMinimal.h"
#include "GameFramework/PlayerController.h"
#include "PlayerControllerBase.generated.h"


class UFTL_GameInstance;


UCLASS()
class FIGHTTHELANLORD_API APlayerControllerBase : public APlayerController
{
	GENERATED_BODY()
public:
	APlayerControllerBase();
protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(EEndPlayReason::Type EndPlayResason) override;

public:
	virtual void Tick(float DeltaTime) override;

private:
	UPROPERTY()
	TObjectPtr<UFTL_GameInstance> GameInstance;


public:
	
	UFUNCTION(Client, Unreliable)
	virtual void Client_QuitSession();
	UFUNCTION(Client, Unreliable)
	virtual void Client_OnLocalClientSwitchLevel();
protected:
	UFUNCTION(Client, Unreliable)
	virtual void Client_BeginPlay();
	UFUNCTION(Client, Unreliable)
	virtual void Client_EndPlay();
	UFUNCTION()
	UFTL_GameInstance* GetGameInstance();

	
private:
	


};
