﻿
#pragma once

#include "CoreMinimal.h"
#include "PlayerController/PlayerControllerBase.h"
#include "MainPageLevelPlayerController.generated.h"



UCLASS()
class FIGHTTHELANLORD_API AMainPageLevelPlayerController : public APlayerControllerBase
{
	GENERATED_BODY()

public:
	AMainPageLevelPlayerController();
protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(EEndPlayReason::Type EndPlayResason) override;

public:
	virtual void Tick(float DeltaTime) override;

public:
	FDelegateHandle QuitGameHandle;
private:


public:

protected:
	virtual void Client_BeginPlay_Implementation() override;
	virtual void Client_EndPlay_Implementation() override;

private:
	UFUNCTION()
	void OnGameQuit();



};
