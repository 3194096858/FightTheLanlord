﻿
#pragma once

#include "CoreMinimal.h"
#include "PlayerController/PlayerControllerBase.h"
#include "GameLobbyLevelPlayerController.generated.h"

UCLASS()
class FIGHTTHELANLORD_API AGameLobbyLevelPlayerController : public APlayerControllerBase
{
	GENERATED_BODY()

public:
	AGameLobbyLevelPlayerController();
protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(EEndPlayReason::Type EndPlayResason) override;

public:
	virtual void Tick(float DeltaTime) override;

private:
	FDelegateHandle StartGameHandle;


public:
	UFUNCTION(Client, Unreliable)
	void Client_SetGameLobbyPanelPlayerNumber(int32 CurrentNumber);
	UFUNCTION(Client, Unreliable)
	void Client_OnGameStart();
protected:
	virtual void Client_BeginPlay_Implementation() override;
	virtual void Client_EndPlay_Implementation() override;

private:
	
};
