﻿
#pragma once

#include "CoreMinimal.h"
#include "PlayerController/PlayerControllerBase.h"
#include "MainLevelPlayerController.generated.h"




UCLASS()
class FIGHTTHELANLORD_API AMainLevelPlayerController : public APlayerControllerBase
{
	GENERATED_BODY()

public:
	AMainLevelPlayerController();
protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(EEndPlayReason::Type EndPlayResason) override;

public:
	virtual void Tick(float DeltaTime) override;

private:


public:

protected:
	virtual void Client_BeginPlay_Implementation() override;
	virtual void Client_EndPlay_Implementation() override;

private:
	UFUNCTION()
	void InitializeScreen();





};
