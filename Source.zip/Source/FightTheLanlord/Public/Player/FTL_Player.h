﻿
#pragma once

#include "CoreMinimal.h"
#include "Player/PlayerBase.h"
#include "FTL_Player.generated.h"

UCLASS()
class FIGHTTHELANLORD_API AFTL_Player : public APlayerBase
{
	GENERATED_BODY()

public:
	AFTL_Player();
protected:
	virtual void BeginPlay() override;
public:
	virtual void Tick(float DeltaTime) override;
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;

};
