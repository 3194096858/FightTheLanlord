﻿
#pragma once

#include "CoreMinimal.h"
#include "Player/PlayerBase.h"
#include "AIPlayer.generated.h"

class UFTL_GameInstance;
class AAIController;



UCLASS()
class FIGHTTHELANLORD_API AAIPlayer : public APlayerBase
{
	GENERATED_BODY()

public:
	AAIPlayer();
protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(EEndPlayReason::Type EndPlayResason) override;
public:
	virtual void Tick(float DeltaTime) override;
public:

	UPROPERTY(EditAnywhere, Category = "AI")
	TSubclassOf<AAIController> AIControllerClass2;
private:
    UPROPERTY()
	TObjectPtr<UFTL_GameInstance> GameInstance = nullptr;

public:

private:
	UFUNCTION()
	UFTL_GameInstance* GetGameInstance();
	UFUNCTION()
	void OnObjectBeginPlay(AActor* Object);
	UFUNCTION()
	void OnObjectEndPlay(AActor* Object);

	UFUNCTION()
	void OnGameOver(bool IsLanlordWin);
	UFUNCTION()
	void OnCreateAIPlayer(int32 PlayerID);
};
