﻿
#pragma once

#include "CoreMinimal.h"
#include "Engine/GameInstance.h"
#include "FTL_GameInstance.generated.h"


class UAudioManager;
class UDelegateManager;
class UFTL_AssetManager;
class UWidegtManager;
class AFTL_GameStateBase;
class UGameSettingsManager;
class UGameSessionManager;
class UFTL_TimerManager;
class UCardLibrary;
class ULevelManager;
class UObjectPoolManager;


UCLASS()
class FIGHTTHELANLORD_API UFTL_GameInstance : public UGameInstance
{
	GENERATED_BODY()

public:
	UFTL_GameInstance();
	virtual void Init() override;
	virtual void OnStart() override;


public:
    UPROPERTY(EditAnywhere, Category = "AssetManager")
	TSubclassOf<UFTL_AssetManager> AssetManagerClass;
	FString ClientGUID;
private:
	UPROPERTY()
	TObjectPtr<UFTL_AssetManager> AssetManager;
	UPROPERTY()
	TObjectPtr<UAudioManager> AudioManager;
	UPROPERTY()
	TObjectPtr<UDelegateManager> DelegateManager;
	UPROPERTY()
	TObjectPtr<UWidgetManager> WidgetManager;
	UPROPERTY()
    TObjectPtr<AFTL_GameStateBase> GameState;
	UPROPERTY()
	TObjectPtr<UGameSettingsManager> GameSettingsManager;
	UPROPERTY()
	TObjectPtr<UGameSessionManager> GameSessionManager;
	UPROPERTY()
	TObjectPtr<UFTL_TimerManager> TimerManager;
	UPROPERTY()
	TObjectPtr<UCardLibrary> CardLibrary;
	UPROPERTY()
	TObjectPtr<ULevelManager> LevelManager;
	UPROPERTY()
	TObjectPtr<UObjectPoolManager> ObjectPoolManager;
	FTimerHandle TimerHandle;
public:
	UFUNCTION()
	UGameSessionManager* GetGameSessionManager();
	UFUNCTION()
	UGameSettingsManager* GetGameSettingsManager();
	UFUNCTION()
	UWidgetManager* GetWidgetManager();
	UFUNCTION()
	UAudioManager* GetAudioManager();
	UFUNCTION()
	UDelegateManager* GetDelegateManager();
	UFUNCTION()
	UFTL_AssetManager* GetAssetManager();
	UFUNCTION()
	UFTL_TimerManager* GetTimerManager();
	UFUNCTION()
	AFTL_GameStateBase* GetGameState(); 
	UFUNCTION()
	UCardLibrary* GetCardLibrary();
	UFUNCTION()
	ULevelManager* GetLevelManager();
	UFUNCTION()
	UObjectPoolManager* GetObjectPoolManager();
	UFUNCTION()
	void DestroyCardLibrary();
	void JoinSelectedSession(bool IsServer);

private:
	void OnNetworkFailure(UWorld* World,UNetDriver* NetDriver,ENetworkFailure::Type FailureType, const FString& ErrorString);
	UFUNCTION()
	void OnQuitSessionComplete(const FName& Session);
	UFUNCTION()
	void OnJoinSessionComplete(const FName& Session);
	UFUNCTION()
	void OnLocalClientSwitchLevel();
	UFUNCTION()
	void OnLocalClientSwitchLevelComplete(const FString& CurrentLevelName);
	UFUNCTION()
	void OnPlayLoadingAnimationComplete(bool IsForward);

};
