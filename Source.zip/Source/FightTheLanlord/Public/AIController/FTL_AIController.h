﻿
#pragma once


#include "Enum/HandType.h"
#include "Struct/HandTypeInformation.h"
#include "Struct/CardInformation.h"
#include "CoreMinimal.h"
#include "AIController.h"
#include "FTL_AIController.generated.h"


class ABattleGameMode;
class UFTL_GameInstance;
class UBehaviorTreeComponent;

UCLASS()
class FIGHTTHELANLORD_API AFTL_AIController : public AAIController
{
	GENERATED_BODY()

public:
	AFTL_AIController();
protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(EEndPlayReason::Type EndPlayResason) override;
public:
	virtual void Tick(float DeltaTime) override;
	virtual void OnPossess(APawn* InPawn) override;
public:

private:
	UPROPERTY(VisibleAnywhere, Category = "Component")
	TObjectPtr<UBehaviorTreeComponent> BehaviorTreeComponent;
	TArray<FCardInformation> CardArray;
	TArray<FCardInformation> SelectedCardArray;
	int32 PlayerID = -1;
	TObjectPtr<ABattleGameMode> GameMode = nullptr;
	TObjectPtr<UFTL_GameInstance> GameInstance = nullptr;
public:
	UFUNCTION()
	bool CheckHasValidHandType();
	UFUNCTION()
	void RemoveAllSelectedCard();
	UFUNCTION()
	TArray<FHandTypeInformation> GetAllAirplaneHandTypeInformation();
	UFUNCTION()
	TArray<FHandTypeInformation> GetAllBombHandTypeInformation();
	UFUNCTION()
	TArray<FHandTypeInformation> GetAllTripletWithKickerHandTypeInformation();
	UFUNCTION()
	TArray<FHandTypeInformation> GetAllTripletHandTypeInformation();
	UFUNCTION()
	TArray<FHandTypeInformation> GetAllPossibleHandTypeInformation();
	UFUNCTION()
	void SetPlayerCardHand(const TArray<FCardInformation>& NewArray);
	UFUNCTION()
	void RemoveCardFormCardHand(const TArray<FCardInformation>& Array);
	UFUNCTION()
	void SetPlayerID(int32 NewID);
	UFUNCTION()
	int32 GetPlayerID();
	UFUNCTION()
	void PlayCard();
	UFUNCTION()
	void Pass();
	
private:
	UFUNCTION()
	ABattleGameMode* GetGameMode();
	UFUNCTION()
	void OnObjectBeginPlay(AActor* Object);
	UFUNCTION()
	void OnObjectEndPlay(AActor* Object);
	UFUNCTION()
	void OnGameOver(bool IsLanlordWin);
	UFUNCTION()
	UFTL_GameInstance* GetGameInstance();
};
