﻿
#pragma once

#include "OnlineSessionSettings.h"
#include "OnlineSubsystem.h"
#include "Interfaces/OnlineSessionInterface.h"

#include "CoreMinimal.h"
#include "Widget/WidgetBase.h"
#include "GameSessionPanel.generated.h"

class UScrollBox;
class UCreateSessionPanel;
class USearchSessionPanel;
class USessionWidget;
class USizeBox;
class UImage;
class UButtonWidget;
class UEditableTextBoxWidget;


UCLASS()
class FIGHTTHELANLORD_API UGameSessionPanel : public UWidgetBase
{
	GENERATED_BODY()
public:
	virtual void NativeConstruct() override;
	virtual void NativePreConstruct() override;
	virtual void NativeDestruct() override;
	virtual void NativeOnInitialized() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;
public:
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UButtonWidget> CreateButton;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UButtonWidget> SearchButton;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UScrollBox> ScrollBox;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UEditableTextBoxWidget> EditableTextBox;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UImage> BackGroundImage;

private:




public:

private:
	UFUNCTION()
	USessionWidget* GetSession(const FString& SessionName);
	UFUNCTION()
	void RemoveAllInvalidSession();
	UFUNCTION()
	void ShowAllSession();
	UFUNCTION()
	void HideAllSession();
	UFUNCTION()
	bool GetHasSession(const FString& SessionName);
	UFUNCTION()
	TArray<USessionWidget*> GetAllSession();
	UFUNCTION()
	void AddSession(USessionWidget* Session);
	UFUNCTION()
	void RemoveSession(USessionWidget* Session);
	UFUNCTION()
	void InitializeEditableTextBox();
	UFUNCTION()
	void OnClickCreateButton();
	UFUNCTION()
	void OnClickSearchButton();
	UFUNCTION()
	void InitializeCreateButton();
	UFUNCTION()
	void InitializeSearchButton();
	UFUNCTION()
	void OnCreateSession();
	UFUNCTION()
	void OnSearchSession();
	UFUNCTION()
	void OnJoinSessionComplete(const FName& SessionName);
	UFUNCTION()
	void OnDestroySessionComplete(const FName& SessionName);
	UFUNCTION()
	void OnCreateSessionComplete(const FName& SessionName);
	void OnSearchSessionComplete(TSharedPtr<FOnlineSessionSearch> SessionSearch);
	UFUNCTION()
	void OnGameSessionPanelOpen();
	UFUNCTION()
	void OnGameSessionPanelClose();



};
