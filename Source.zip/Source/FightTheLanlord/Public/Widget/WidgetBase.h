﻿
#pragma once
#include "Struct/GameProperty.h"

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "WidgetBase.generated.h"


class UImage;
class USizeBox;
class UTexture2D;
class UTextBlockWidget;
class UButton;
class UWidgetAnimation;
class AFTL_GameModeBase;
class UFTL_GameInstance;

UCLASS()
class FIGHTTHELANLORD_API UWidgetBase : public UUserWidget
{
	GENERATED_BODY()
public:
	virtual void NativeOnInitialized() override;
	virtual void NativeConstruct() override;
	virtual void NativePreConstruct() override;
	virtual void NativeDestruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

public:
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<USizeBox> SizeBox;
	
protected:
	UPROPERTY(BlueprintReadWrite)
	TObjectPtr<UWidgetAnimation> WidgetAnimation;
	FGameProperty AnimationPlayRate = FGameProperty(1.0f,0.1f,10.0f);
	UPROPERTY()
	FVector2D WidgetSize = FVector2D(500.0f, 500.0f);
private:
	UPROPERTY()
	TObjectPtr<UFTL_GameInstance> GameInstance;



public:
	UFUNCTION(BlueprintCallable)
	void SetWidgetSize(const FVector2D& NewSize);

	FVector2D GetWidgetSize();

	UFUNCTION()
	void SetAnimationPlayRate(float NewPlayRate);
	UFUNCTION()
	float GetAnimationPlayRate();
	UFUNCTION()
	void SetRelativePosition(const FVector2D& NewPosition);
	UFUNCTION()
	FVector2D GetRelativePosition();
	UFUNCTION()
	void Open(int32 ZOrder = 0);
	UFUNCTION()
	void Close();
	

protected:
	UFTL_GameInstance* GetGameInstance();
	UFUNCTION()
	bool GetIsInServer();
	UFUNCTION()
	virtual void OnLocalClientGameStateCompleteInitialize();
	UFUNCTION()
	virtual void OnLocalClientPlayerStateCompleteInitialize();
	UFUNCTION()
	virtual void OnServerGameStateCompleteInitialize();
	UFUNCTION()
	virtual void OnLocalClientPlayerControllerCompleteInitialize();
private:








};
