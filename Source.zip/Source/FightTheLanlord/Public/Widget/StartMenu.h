﻿
#pragma once

#include "CoreMinimal.h"
#include "Widget/WidgetBase.h"
#include "StartMenu.generated.h"

class USizeBox;
class UImage;
class UButtonWidget;




UCLASS()
class FIGHTTHELANLORD_API UStartMenu : public UWidgetBase
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;
	virtual void NativePreConstruct() override;
	virtual void NativeDestruct() override;
	virtual void NativeOnInitialized() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

private:
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UImage> GameTitleImage;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UButtonWidget> StartGameButton;




public:
	
private:
	UFUNCTION()
	void InitializeStartGameButton();
	UFUNCTION()
	void OnClickStartGameButton();

	UFUNCTION()
	void OnStartMenuOpen();


	UFUNCTION()
	void OnStartMenuClose();


};
