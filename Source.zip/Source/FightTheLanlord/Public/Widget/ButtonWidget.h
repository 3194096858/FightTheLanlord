﻿
#pragma once


#include "Struct/WidgetAsset.h"

#include "Struct/WidgetData.h"
#include "Struct/GameProperty.h"

#include "CoreMinimal.h"
#include "Widget/WidgetBase.h"
#include "ButtonWidget.generated.h"



class UImage;
class USizeBox;
class UTexture2D;
class UTextBlockWidget;
class UButton;
class UWidgetAnimation;

DECLARE_DELEGATE(FOnClick);
DECLARE_DELEGATE(FOnPress);
DECLARE_DELEGATE(FOnRelease);


UCLASS()
class FIGHTTHELANLORD_API UButtonWidget : public UWidgetBase
{
	GENERATED_BODY()
public:
	virtual void NativeOnInitialized() override;
	virtual void NativeConstruct() override;
	virtual void NativePreConstruct() override;
	virtual void NativeDestruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;
public:
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UButton> Button;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UImage> Icon;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UImage> BackGroundImage;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UTextBlockWidget> TextBlock;
	
	FOnClick OnClick;
	FOnPress OnPress;
	FOnRelease OnRelease;

private:


public:
	UFUNCTION()
	void SetIconSlateBrush(const FSlateBrush& NewSlateBrush);
	UFUNCTION()
	void SetBackGroundImageSlateBrush(const FSlateBrush& NewSlateBrush);
	UFUNCTION()
	void SetIconVisibility(const ESlateVisibility& NewVisibility);
	UFUNCTION()
	void SetBackGroundImageVisibility(const ESlateVisibility& NewVisibility);
	UFUNCTION()
	void SetTextBackGroundImageVisibility(const ESlateVisibility& NewVisibility);
	UFUNCTION()
	void SetTextBlockVisibility(const ESlateVisibility& NewVisibility);
	void SetText(const FText& NewText);
	void SetText(const FString& NewText);

	UFUNCTION()
	void SetIconRelativePosition(const FVector2D& OffsetPosition);
	UFUNCTION()
	void SetTextRelativePosition(const FVector2D& OffsetPosition);
	UFUNCTION()
	void SetIconImage(UTexture2D* NewIcon);
	UFUNCTION()
	void SetBackGroundImage(UTexture2D* NewBackGround);
	UFUNCTION()
	void SetBackGroundImageColor(const FColor& NewColor);
	UFUNCTION()
	void SetIconColor(const FColor& NewColor);
	void SetIconSize(const FVector2D& NewSize);
	void SetIconSize(float NewSize);
	UFUNCTION()
	void SetFontSize(int32 NewSize);
	UFUNCTION()
	void SetFontColor(const FColor& NewColor);
	UFUNCTION()
	void SetFontInformation(const FSlateFontInfo& NewFont);

	void GetText(FText& Result);
	void GetText(FString& Result);
	void GetText(int32& Result);



private:
	UFUNCTION()
	void OnClickButton();
	UFUNCTION()
	void OnPressButton();
	UFUNCTION()
	void OnReleaseButton();





};
