﻿
#pragma once

#include "CoreMinimal.h"
#include "Widget/WidgetBase.h"
#include "OperationPanel.generated.h"


class UCardHandWidget;
class UButtonWidget;
class UPlayerPanel;
class UCountdownTimerWidget;



UCLASS()
class FIGHTTHELANLORD_API UOperationPanel : public UWidgetBase
{
	GENERATED_BODY()

public:
	virtual void NativeOnInitialized() override;
	virtual void NativeConstruct() override;
	virtual void NativePreConstruct() override;
	virtual void NativeDestruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;
public:
	

private:
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UButtonWidget> PlayCardButton;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UButtonWidget> PassButton;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UButtonWidget> MessageButton;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UCardHandWidget> CardHand;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UCountdownTimerWidget> CountdownTimer;


public:
	UFUNCTION()
	void SetCountdownTimerText(int32 CurrentSecond);
	UFUNCTION()
	void ShowCardHand();
	UFUNCTION()
	void HideCardHand();
	UFUNCTION()
	TArray<UCardWidget*> GetAllCardFromCardHand();
	UFUNCTION()
	void AddCardToCardHand(UCardWidget* Card);
	UFUNCTION()
	void RemoveCardFromCardHand(UCardWidget* Card);
	UFUNCTION()
	void RemoveAllCardFromCardHand();
	UFUNCTION()
	void ShowCountdownTimer();
	UFUNCTION()
	void HideCountdownTimer();
	UFUNCTION()
	void PlayDealCardAnimation();
protected:
	virtual void OnLocalClientGameStateCompleteInitialize() override;
	virtual void OnServerGameStateCompleteInitialize() override;
	virtual void OnLocalClientPlayerControllerCompleteInitialize() override;
private:
	UFUNCTION()
	void InitializePlayCardButton();
	UFUNCTION()
	void InitializePassButton();
	UFUNCTION()
	void InitializeMessageButton();
	UFUNCTION()
	void InitializeCountdownTimer();
	UFUNCTION()
	void InitializeCardHand();
	UFUNCTION()
	void OnClickMessageButton();
	UFUNCTION()
	void OnClickPlayCardButton();
	UFUNCTION()
	void OnClickPassButton();
	UFUNCTION()
	void OnOperationPanelOpen();
	UFUNCTION()
	void OnOperationPanelClose();
	UFUNCTION()
	void OnDealCardComplete();
	UFUNCTION()
	void OnGameOver(bool IsLanlordWin);
};
