﻿
#pragma once

#include "Struct/WidgetAsset.h"

#include "Struct/WidgetData.h"

#include "Components/CanvasPanelSlot.h"
#include "Struct/GameProperty.h"

#include "CoreMinimal.h"
#include "Widget/WidgetBase.h"
#include "ComboBoxWidget.generated.h"

class UComboBoxMenuWidget;
class UComboBoxItemWidget;
class UScrollBox;
class UComboBoxString;
class USliderWidget;
class UCheckBox;
class UImage;
class USizeBox;
class UTexture2D;
class UTextBlockWidget;
class UButtonWidget;
class UWidgetAnimation;

DECLARE_DELEGATE_TwoParams(FOnSelectionChange, FString, ESelectInfo::Type)
DECLARE_DELEGATE(FOnOpenMenu)

UCLASS()
class FIGHTTHELANLORD_API UComboBoxWidget : public UWidgetBase
{
	GENERATED_BODY()
	UComboBoxWidget();
public:
	virtual void NativeOnInitialized() override;
	virtual void NativeConstruct() override;
	virtual void NativePreConstruct() override;
	virtual void NativeDestruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;
public:
	
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UButtonWidget> Button;
	
	FOnSelectionChange OnSelectionChange;
	FOnOpenMenu OnOpenMenu;

private:
	UPROPERTY()
	TObjectPtr<UComboBoxMenuWidget> Menu;
public:

	UFUNCTION()
	void SetButtonRelativePosition(const FVector2D& NewPosition);
	UFUNCTION()
	void SetButtonTextRelativePosition(const FVector2D& NewPosition);
	UFUNCTION()
	void SetDownArrowSlateBrush(const FSlateBrush& NewSlateBrush);
	UFUNCTION()
	void SetButtonSlateBrush(const FSlateBrush& NewSlateBrush);
	UFUNCTION()
	void SetMenuAnimationPlayRate(float NewPlayRate);
	UFUNCTION()
	void OpenMenu(const FVector2D& Size, const FAnchorData& AnchorData);
	UFUNCTION()
	void CloseMenu();
	UFUNCTION()
	FVector2D GetMenuSzie();
	UFUNCTION()
	void SetMenuSize(const FVector2D& NewSize);
	UFUNCTION()
	void SetItemSize(const FVector2D& NewSize);
	UFUNCTION()
	void SetDownArrowRelativePosition(const FVector2D& NewPosition);
	UFUNCTION()
	void SetMenuRelativePosition(const FVector2D& NewPosition);
	UFUNCTION()
	UComboBoxMenuWidget* GetMenu();
	UFUNCTION()
	void ShowMenuScrollBar();
	UFUNCTION()
	void HideMenuScrollBar();
	UFUNCTION()
	void SetDownArrowImageColor(const FColor& NewColor);
	UFUNCTION()
	void SetMenuBackGroundImageColor(const FColor& NewColor);
	UFUNCTION()
	void SetItemBackGroundImageColor(const FColor& NewColor);
	UFUNCTION()
	void SetItemBackGroundImageVisibility(const ESlateVisibility& NewVisibility);
	UFUNCTION()
	void SetDownArrowVisibility(const ESlateVisibility& NewVisibility);
	UFUNCTION()
	void SetButtonBackGroundImageColor(const FColor& NewColor);
	UFUNCTION()
	void SetDownArrowImage(UTexture2D* NewImage);
	UFUNCTION()
	void SetDownArrowSize(const FVector2D& NewSize);
	UFUNCTION()
	void SetItemFontInformation(const FSlateFontInfo& NewFontInformation);
	UFUNCTION()
	void SetButtonFontColor(const FColor& NewColor);
	UFUNCTION()
	void SetButtonFontSize(int32 NewSize);
	UFUNCTION()
	void SetItemBackGroundImage(UTexture2D* NewImage);
	UFUNCTION()
	void SetItemFontColor(const FColor& NewColor);
	UFUNCTION()
	void SetItemFontSize(int32 NewSize);
	UFUNCTION()
	void SetMenuBackGroundImage(UTexture2D* NewImage);
	UFUNCTION()
	void SetButtonBackGroundImage(UTexture2D* NewImage);
	UFUNCTION()
	void SetButtonText(const FString& Target);
	UFUNCTION()
	void AddOption(const FString& Target, const FMargin& ItemPadding);
	UFUNCTION()
	void SetTextBlockVisibility(const ESlateVisibility& NewVisibility);
	
	UFUNCTION()
	void SetButtonFontInformation(const FSlateFontInfo& NewFont);
private:
	UFUNCTION()
	void OnSelectionUpdate(FString SelectedItem,ESelectInfo::Type SelectionInfo);
	UFUNCTION()
	void OnMenuOpen();



};
