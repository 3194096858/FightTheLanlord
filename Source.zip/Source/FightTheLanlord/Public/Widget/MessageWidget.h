﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Widget/WidgetBase.h"
#include "MessageWidget.generated.h"



class USizeBox;
class UImage;
class UButtonWidget;
class UButton;
class UTextBlockWidget;


UCLASS()
class FIGHTTHELANLORD_API UMessageWidget : public UWidgetBase
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;
	virtual void NativePreConstruct() override;
	virtual void NativeDestruct() override;
	virtual void NativeOnInitialized() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;
public:
	
private:
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UTextBlockWidget> TextBlock;

public:
	UFUNCTION()
	void SetMessage(int32 PlayerID,const FString& NewMessage);

	
};
