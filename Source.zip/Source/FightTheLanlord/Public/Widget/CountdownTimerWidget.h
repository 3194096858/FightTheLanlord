﻿
#pragma once

#include "CoreMinimal.h"
#include "Widget/WidgetBase.h"
#include "CountdownTimerWidget.generated.h"

class UTextBlockWidget;

UCLASS()
class FIGHTTHELANLORD_API UCountdownTimerWidget : public UWidgetBase
{
	GENERATED_BODY()

protected:
	virtual void NativeOnInitialized() override;
	virtual void NativeConstruct() override;
	virtual void NativePreConstruct() override;
	virtual void NativeDestruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

public:
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UTextBlockWidget> TextBlock;
	
private:

public:
	UFUNCTION()
	void InitializeTextBlock(FTextBlockWidgetData Data, FTextBlockWidgetAsset Asset);
	UFUNCTION()
	void SetCountdownTimerIcon(UTexture2D* NewIcon);
	UFUNCTION()
	void SetText(int32 CurrentSecond);

};
