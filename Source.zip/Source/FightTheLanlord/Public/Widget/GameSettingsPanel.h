﻿
#pragma once

#include "CoreMinimal.h"
#include "Widget/WidgetBase.h"
#include "GameSettingsPanel.generated.h"

class UAudioSettingsPanel;
class UOperationSettingsPanel;
class UDisplaySettingsPanel;
class USizeBox;
class UImage;
class UButtonWidget;





UCLASS()
class FIGHTTHELANLORD_API UGameSettingsPanel : public UWidgetBase
{
	GENERATED_BODY()
public:
	virtual void NativeConstruct() override;
	virtual void NativePreConstruct() override;
	virtual void NativeDestruct() override;
	virtual void NativeOnInitialized() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;
public:
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UAudioSettingsPanel> AudioSettingsPanel;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UDisplaySettingsPanel> DisplaySettingsPanel;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UOperationSettingsPanel> OperationSettingsPanel;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UButtonWidget> AudioButton;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UButtonWidget> DisplayButton;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UButtonWidget> OperationButton;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UImage> BackGroundImage;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UButtonWidget> ReturnButton;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UButtonWidget> ResetButton;
private:




public:

private:
	UFUNCTION()
	void InitializeAudioButton();
	UFUNCTION()
	void InitializeDisplayButton();
	UFUNCTION()
	void InitializeOperationButton();
	UFUNCTION()
	void InitializeReturnButton();
	UFUNCTION()
	void InitializeResetButton();
	UFUNCTION()
	void OnGameSettingsPanelOpen();
	UFUNCTION()
	void OnGameSettingsPanelClose();
	UFUNCTION()
	void OnClickReturnButton();
	UFUNCTION()
	void OnClickResetButton();
	UFUNCTION()
	void OnClickAudioButton();
	UFUNCTION()
	void OnClickDisplayButton();
	UFUNCTION()
	void OnClickOperationButton();

};
