﻿
#pragma once

#include "CoreMinimal.h"
#include "Widget/WidgetBase.h"
#include "HoleCardPanel.generated.h"




class UImage;
class USizeBox;
class UTexture2D;
class UTextBlockWidget;
class UButton;
class UWidgetAnimation;
class UCardWidget;
class UCardWidget;
class UOverlay;

UCLASS()
class FIGHTTHELANLORD_API UHoleCardPanel : public UWidgetBase
{
	GENERATED_BODY()
public:
	virtual void NativeOnInitialized() override;
	virtual void NativeConstruct() override;
	virtual void NativePreConstruct() override;
	virtual void NativeDestruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;
public:


private:
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UOverlay> Overlay;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UImage> BackGroundImage;
	

public:
	UFUNCTION()
	void AddCard(const TArray<FCardInformation>& CardArray);
	UFUNCTION()
	void RemoveCard(UCardWidget* Card);
	UFUNCTION()
	void Clear();
	UFUNCTION()
	TArray<UCardWidget*> GetAllCard();
	UFUNCTION()
	void UpdateCardRelativeTransform();
private:
	UFUNCTION()
	void OnHoleCardPanelOpen();
	UFUNCTION()
	void OnHoleCardPanelClose();
	UFUNCTION()
	void AddWidgetToOverlay(UWidgetBase* Widget);


	UFUNCTION()
	void OnDealCardComplete();

	UFUNCTION()
	void OnGameOver(bool IsLanlordWin);


};
