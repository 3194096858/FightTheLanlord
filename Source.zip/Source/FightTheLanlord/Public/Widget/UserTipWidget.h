﻿
#pragma once

#include "CoreMinimal.h"
#include "Widget/WidgetBase.h"
#include "UserTipWidget.generated.h"


class UCanvasPanel;

class UResourcePanel;
class ULoadingWidget;
class UTextBlockWidget;



UCLASS()
class FIGHTTHELANLORD_API UUserTipWidget : public UWidgetBase
{
	GENERATED_BODY()
protected:
	virtual void NativeOnInitialized() override;
	virtual void NativeConstruct() override;
	virtual void NativePreConstruct() override;
	virtual void NativeDestruct() override;
public:
	
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UCanvasPanel> CanvasPanel;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<ULoadingWidget> LoadingWidget;
	/*UPROPERTY(meta = (BindWidget))
	TObjectPtr<UTextBlockWidget> SessionNumberLimitTip;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UTextBlockWidget> SessionSearchResultTip;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UTextBlockWidget> LanlordPlayerTip;*/

private:

public:
	///UFUNCTION()
///	void SetSessionNumberLimitTipText(const FString& NewText);
	UFUNCTION()
	void PlayLoadingAnimation(bool IsForward = true);
	UFUNCTION()
	void AddWidgetToCanvasPanel(UWidgetBase* Widget, const FVector2D& Size, const FAnchorData& AnchorData);
	UFUNCTION()
	void RemoveWidgetFromCanvasPanel(UWidgetBase* Widget);

private:
	

};
