﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Widget/WidgetBase.h"
#include "TipWidgetBase.generated.h"


class UTextBlockWidget;



UCLASS()
class FIGHTTHELANLORD_API UTipWidgetBase : public UWidgetBase
{
	GENERATED_BODY()

protected:
	virtual void NativeOnInitialized() override;
	virtual void NativeConstruct() override;
	virtual void NativePreConstruct() override;
	virtual void NativeDestruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

public:
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UTextBlockWidget> TextBlock;
	
private:

public:


};
