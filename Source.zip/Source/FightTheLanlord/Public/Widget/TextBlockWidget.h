﻿
#pragma once

#include "Struct/WidgetAsset.h"

#include "Struct/WidgetData.h"

#include "CoreMinimal.h"
#include "Widget/WidgetBase.h"
#include "TextBlockWidget.generated.h"




class UImage;
class USizeBox;
class UTexture2D;
class UTextBlock;
class UButton;
class UWidgetAnimation;



UCLASS()
class FIGHTTHELANLORD_API UTextBlockWidget : public UWidgetBase
{
	GENERATED_BODY()

public:
	virtual void NativeOnInitialized() override;
	virtual void NativeConstruct() override;
	virtual void NativePreConstruct() override;
	virtual void NativeDestruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;
public:
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UTextBlock> TextBlock;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UImage> BackGroundImage;
	
private:
	///FSlateFontInfo FontInformation;

	
public:
	void SetText(const FString& NewText);
	UFUNCTION()
	void SetBackGroundImageColor(const FColor& NewColor);
	UFUNCTION()
	void SetBackGroundImageSlateBrush(const FSlateBrush& NewSlateBrush);
	UFUNCTION()
	void SetBackGroundImageVisibility(const ESlateVisibility& NewVisibility);
	UFUNCTION()
	void SetTextVisibility(const ESlateVisibility& NewVisibility);
	UFUNCTION()
	void SetTextRelativePosition(const FVector2D& NewPosition);
	UFUNCTION()
	void SetBackGroundImage(UTexture2D* NewImage);
	UFUNCTION()
	void SetFontSize(int32 NewSize);
	UFUNCTION()
	void SetFontColor(const FColor& NewColor);
	UFUNCTION()
	void SetFontInformation(const FSlateFontInfo& NewFont);
	void SetText(int32 Number);
	void SetText(const FText& NewText);
	void GetText(FText& Result);
	void GetText(FString& Result);
	void GetText(int32& Result);





};
