﻿
#pragma once

#include "OnlineSessionSettings.h"
#include "OnlineSubsystem.h"
#include "Interfaces/OnlineSessionInterface.h"

#include "CoreMinimal.h"
#include "Widget/WidgetBase.h"
#include "SessionWidget.generated.h"


class USizeBox;
class UImage;
class UButtonWidget;
class UButton;
class UTextBlockWidget;

UCLASS()
class FIGHTTHELANLORD_API USessionWidget : public UWidgetBase
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;
	virtual void NativePreConstruct() override;
	virtual void NativeDestruct() override;
	virtual void NativeOnInitialized() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;
public:
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UButtonWidget> JoinButton;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UButtonWidget> DeleteButton;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UTextBlockWidget> NameTextBlock;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UImage> Icon;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UImage> BackGroundImage;

private:




public:
	UFUNCTION()
	void SetSessionName(const FString& NewName);
	UFUNCTION()
	FString GetSessionName();
	UFUNCTION()
	void RemoveFromScrollBox();
	UFUNCTION()
	void SetDeleteButtonVisibility(const ESlateVisibility& NewVisibility);


private:
	UFUNCTION()
	void OnClickJoinButton();
	UFUNCTION()
	void OnClickDeleteButton();
	UFUNCTION()
	void InitializeJoinButton();
	UFUNCTION()
	void InitializeDeleteButton();
	UFUNCTION()
	void OnSearchSession();
	UFUNCTION()
	void OnJoinSessionComplete(const FName& SessionName);
	UFUNCTION()
	void OnDestroySessionComplete(const FName& SessionName);
	UFUNCTION()
	void OnQuitSessionComplete(const FName& SessionName);




};
