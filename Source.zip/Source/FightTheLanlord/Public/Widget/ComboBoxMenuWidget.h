﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Widget/WidgetBase.h"
#include "ComboBoxMenuWidget.generated.h"

class UComboBoxItemWidget;
class UScrollBox;
class UComboBoxString;
class USliderWidget;
class UCheckBox;
class UImage;
class USizeBox;
class UTexture2D;
class UTextBlockWidget;
class UButtonWidget;
class UWidgetAnimation;


UCLASS()
class FIGHTTHELANLORD_API UComboBoxMenuWidget : public UWidgetBase
{
	GENERATED_BODY()
public:
	virtual void NativeOnInitialized() override;
	virtual void NativeConstruct() override;
	virtual void NativePreConstruct() override;
	virtual void NativeDestruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;
public:
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UScrollBox> ScrollBox;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UImage> BackGroundImage;
private:
	FScrollBoxStyle Style;

public:
	UFUNCTION()
	void SetItemSize(const FVector2D& NewSize);
	UFUNCTION()
	void SetItemFontSize(int32 NewSize);
	UFUNCTION()
	void SetScrollBarVisibility(const ESlateVisibility& NewVisibility);
	UFUNCTION()
	void AddItem(UComboBoxItemWidget* Item,const FMargin& ItemPadding);
	UFUNCTION()
	TArray<UComboBoxItemWidget*> GetAllItem();
	UFUNCTION()
	void SetBackGroundImageColor(const FColor& NewColor);
	UFUNCTION()
	void SetItemBackGroundImageColor(const FColor& NewColor);
	UFUNCTION()
	void SetItemBackGroundImageVisibility(const ESlateVisibility& NewVisibility);
	UFUNCTION()
	void SetItemFontInformation(const FSlateFontInfo& NewFontInformation);
	UFUNCTION()
	void SetItemFontColor(const FColor& NewColor);
	UFUNCTION()
	void SetItemBackGroundImage(UTexture2D* NewImage);
	UFUNCTION()
	void SetBackGroundImage(UTexture2D* NewImage);

	UFUNCTION()
	void SetBackGroundImageSlateBrush(const FSlateBrush& NewBackGroundImageSlateBrush);
	
};
