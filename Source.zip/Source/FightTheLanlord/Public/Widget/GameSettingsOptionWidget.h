﻿
#pragma once

#include "Struct/WidgetAsset.h"

#include "Struct/WidgetData.h"
#include "Enum/GameSettingsOptionType.h"

#include "Components/CanvasPanelSlot.h"
#include "Struct/GameProperty.h"

#include "CoreMinimal.h"
#include "Widget/WidgetBase.h"
#include "GameSettingsOptionWidget.generated.h"


class UComboBoxWidget;
class USliderWidget;
class UCheckBoxWidget;
class UImage;
class USizeBox;
class UTexture2D;
class UTextBlockWidget;
class UButton;
class UWidgetAnimation;
class UWidgetBase;
class UComboBoxMenuWidget;


DECLARE_DELEGATE_TwoParams(FOnComboBoxSelectionChange, FString, ESelectInfo::Type)
DECLARE_DELEGATE(FOnOpenComboBoxMenu)
DECLARE_DELEGATE_OneParam(FOnSliderValueChange, float)

UCLASS()
class FIGHTTHELANLORD_API UGameSettingsOptionWidget : public UWidgetBase
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;
	virtual void NativePreConstruct() override;
	virtual void NativeDestruct() override;
	virtual void NativeOnInitialized() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;
public:
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UTextBlockWidget> TextBlock;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UImage> BackGroundImage;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UCheckBoxWidget> CheckBox;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<USliderWidget> Slider;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UComboBoxWidget> ComboBox;
	FOnComboBoxSelectionChange OnComboBoxSelectionChange;
	FOnOpenComboBoxMenu OnOpenComboBoxMenu;
	FOnSliderValueChange OnSliderValueChange;
private:

public:
	UFUNCTION()
	float GetSliderValue();
	UFUNCTION()
	int32 GetSliderCurrentPercent();
	UFUNCTION()
	void SetSliderCurrentPercent(int32 NewPercent);
	UFUNCTION()
	void SetSliderBackGroundImageVisibility(const ESlateVisibility& NewVisibility);
	UFUNCTION()
	void SetSliderHandleSize(const FVector2D& NewSize);
	UFUNCTION()
	void SetSliderTextBlockRelativePosition(const FVector2D& NewSize);
	
	UFUNCTION()
	void SetSliderStepSize(float NewSize);
	UFUNCTION()
	void SetSliderValue(float NewValue);
	UFUNCTION()
	void SetSliderMaxValue(float NewValue);
	UFUNCTION()
	void SetSliderMinValue(float NewValue);
	UFUNCTION()
	void SetSliderFontSize(int32 NewSize);
	UFUNCTION()
	void SetSliderFontColor(const FColor& NewColor);
	UFUNCTION()
	void SetSliderRelativePosition(const FVector2D& NewPosition);
	UFUNCTION()
	void SetSliderSize(const FVector2D& NewSize);
	UFUNCTION()
	void SetSliderBarThickness(float NewThickness);
	UFUNCTION()
	void SetSliderBackGroundImage(UTexture2D* NewImage);
	UFUNCTION()
	void SetSliderBarImage(UTexture2D* NewImage);
	UFUNCTION()
	void SetSliderHandleImage(UTexture2D* NewImage);
	UFUNCTION()
	void SetSliderTextBlockVisibility(const ESlateVisibility& NewVisibility);
	UFUNCTION()
	void SetSliderText(const FString& NewText);
	UFUNCTION()
	void SetSliderBackGroundImageColor(const FColor& NewColor);
	UFUNCTION()
	void SetSliderBarColor(const FColor& NewColor);
	UFUNCTION()
	void SetSliderHandleColor(const FColor& NewColor);
	UFUNCTION()
	void SetComboBoxSize(const FVector2D& NewSize);
	UFUNCTION()
	void SetComboBoxRelativePosition(const FVector2D& NewPosition);
	UFUNCTION()
	void SetComboBoxFontInformation(const FSlateFontInfo& ButtonFontInformation, const FSlateFontInfo& ItemFontInformation);
	UFUNCTION()
	void SetComboBoxFontColor(const FColor& ButtonFontColor, const FColor& ItemFontColor);
	UFUNCTION()
	void SetComboBoxFontSize(int32 ButtonFontSize, int32 ItemFontSize);
	UFUNCTION()
	void ShowComboBoxMenuScrollBar();
	UFUNCTION()
	void HideComboBoxMenuScrollBar();
	UFUNCTION()
	void SetComboBoxMenuAnimationPlayRate(float NewPlayRate);
	UFUNCTION()
	void SetComboBoxMenuRelativePosition(const FVector2D& NewPosition);
	UFUNCTION()
	void OpenComboBoxMenu(const FVector2D& Size, const FAnchorData& AnchorData);
	UFUNCTION()
	void CloseComboBoxMenu();
	UFUNCTION()
	void SetComboBoxMenuSize(const FVector2D& NewSize);
	UFUNCTION()
	void SetComboBoxItemSize(const FVector2D& NewSize);
	UFUNCTION()
	UComboBoxMenuWidget* GetComboBoxMenu();
	UFUNCTION()
	void SetComboBoxDownArrowImageColor(const FColor& NewColor);
	UFUNCTION()
	void SetComboBoxDownArrowSize(const FVector2D& NewSize);
	UFUNCTION()
	void SetComboBoxDownArrowRelativePosition(const FVector2D& NewPosition);
	UFUNCTION()
	void SetComboBoxMenuBackGroundImageColor(const FColor& NewColor);
	UFUNCTION()
	void SetComboBoxItemBackGroundImageColor(const FColor& NewColor);
	UFUNCTION()
	void SetComboBoxButtonBackGroundImageColor(const FColor& NewColor);
	UFUNCTION()
	void SetComboBoxButtonTextRelativePosition(const FVector2D& NewPosition);
	UFUNCTION()
	void SetComboBoxItemBackGroundImage(UTexture2D* NewImage);
	UFUNCTION()
	void SetComboBoxDownArrowImage(UTexture2D* NewImage);
	UFUNCTION()
	void SetComboBoxMenuBackGroundImage(UTexture2D* NewImage);
	UFUNCTION()
	void SetComboBoxButtonBackGroundImage(UTexture2D* NewImage);
	UFUNCTION()
	void SetComboBoxButtonText(const FString& Target);
	UFUNCTION()
	void AddOptionToComboBox(const FString& Target, const FMargin& ItemPadding);
	UFUNCTION()
	void SetBackGroundImage(UTexture2D* NewImage);
	UFUNCTION()
	void SetBackGroundImageColor(const FColor& NewColor);
	UFUNCTION()
	void SetBackGroundImageVisibility(const ESlateVisibility& NewVisibility);
	UFUNCTION()
	void SetComboBoxItemBackGroundImageVisibility(const ESlateVisibility& NewVisibility);
	void SetText(const FString& NewText);
	void SetText(int32 Number);
	void SetText(const FText& NewText);
	UFUNCTION()
	void SetTextRelativePosition(const FVector2D& OffsetPosition);
	UFUNCTION()
	void SetFontSize(int32 NewSize);
	UFUNCTION()
	void SetFontColor(const FColor& NewColor);
	UFUNCTION()
	void SetFontInformation(const FSlateFontInfo& NewFont);
	UFUNCTION()
	void SetOptionType(EGameSettingsOptionType NewType);
	
private:
	UFUNCTION()
	void OnComboBoxMenuOpen();
	UFUNCTION()
	void OnComboBoxSelectionUpdate(FString SelectedItem, ESelectInfo::Type SelectionInfo);
	UFUNCTION()
	void OnCheckBoxStateChange(bool IsCheck);
	UFUNCTION()
	void OnSliderValueUpdate(float Value);


};


