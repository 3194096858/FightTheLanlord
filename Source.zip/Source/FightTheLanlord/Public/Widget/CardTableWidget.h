﻿
#pragma once

#include "CoreMinimal.h"
#include "Widget/WidgetBase.h"
#include "CardTableWidget.generated.h"


class UCardWidget;
class UOverlay;



UCLASS()
class FIGHTTHELANLORD_API UCardTableWidget : public UWidgetBase
{
	GENERATED_BODY()


protected:
	virtual void NativeOnInitialized() override;
	virtual void NativeConstruct() override;
	virtual void NativePreConstruct() override;
	virtual void NativeDestruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

public:
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UOverlay> Overlay;

private:

public:
	UFUNCTION()
	void AddCard(const TArray<FCardInformation>& CardArray);
	UFUNCTION()
	void RemoveCard(UCardWidget* Card);
	UFUNCTION()
	void Clear();
	UFUNCTION()
	TArray<UCardWidget*> GetAllCard();
	UFUNCTION()
	void UpdateCardRelativeTransform();
protected:
	virtual void OnLocalClientGameStateCompleteInitialize() override;
	virtual void OnServerGameStateCompleteInitialize() override;
	virtual void OnLocalClientPlayerControllerCompleteInitialize() override;


private:
	UFUNCTION()
	void AddWidgetToOverlay(UWidgetBase* Widget);
	UFUNCTION()
	void OnCardTableWidgetOpen();
	UFUNCTION()
	void OnCardTableWidgetClose();
	UFUNCTION()
	void OnGameOver(bool IsLanlordWin);



};
