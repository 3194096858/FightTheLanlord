﻿
#pragma once


#include "Struct/CardInformation.h"
#include "CoreMinimal.h"
#include "Widget/WidgetBase.h"
#include "CardWidget.generated.h"


class UImage;
class USizeBox;
class UTexture2D;
class UTextBlockWidget;
class UButton;
class UWidgetAnimation;


DECLARE_DELEGATE(FOnClick);
DECLARE_DELEGATE(FOnPress);
DECLARE_DELEGATE(FOnRelease);

UCLASS()
class FIGHTTHELANLORD_API UCardWidget : public UWidgetBase
{
	GENERATED_BODY()

public:
	virtual void NativeOnInitialized() override;
	virtual void NativeConstruct() override;
	virtual void NativePreConstruct() override;
	virtual void NativeDestruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;
	virtual void NativeTick(const FGeometry& MyGeometry, float InDeltaTime) override;

public:
	
private:
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UButton> Button;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UImage> Image;
	FOnClick OnClick;
	FOnPress OnPress;
	FOnRelease OnRelease;
	bool IsSelected = false;

public:
	UFUNCTION()
	void SetIsSelected(bool NewValue);
	UFUNCTION()
	bool GetIsSelected();
	UFUNCTION()
	void SetImage(UTexture2D* NewImage);
	UFUNCTION()
	FCardInformation GetCardInformation();
	UFUNCTION()
	void SetCardInformation(FCardInformation NewInformation);

	UFUNCTION()
	void MoveTo(const FVector2D& StartPositio,const FVector2D& EndPosition,float Speed);
protected:
	virtual void OnLocalClientGameStateCompleteInitialize() override;
	virtual void OnServerGameStateCompleteInitialize() override;
	virtual void OnLocalClientPlayerControllerCompleteInitialize() override;

private:
	UFUNCTION()
	void OnClickCard();
	UFUNCTION()
	void OnPressCard();
	UFUNCTION()
	void OnReleaseCard();
	UFUNCTION()
	void OnGameOver(bool IsLanlordWin);

};












