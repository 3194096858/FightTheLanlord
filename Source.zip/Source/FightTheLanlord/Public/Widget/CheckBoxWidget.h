﻿
#pragma once

#include "CoreMinimal.h"
#include "Widget/WidgetBase.h"
#include "CheckBoxWidget.generated.h"


class UComboBoxString;
class USliderWidget;
class UCheckBox;
class UImage;
class USizeBox;
class UTexture2D;
class UTextBlockWidget;
class UButton;
class UWidgetAnimation;

DECLARE_DELEGATE_OneParam(FOnStateChange,bool)

UCLASS()
class FIGHTTHELANLORD_API UCheckBoxWidget : public UWidgetBase
{
	GENERATED_BODY()
public:
	virtual void NativeConstruct() override;
	virtual void NativePreConstruct() override;
	virtual void NativeDestruct() override;
	virtual void NativeOnInitialized() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;
public:
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UCheckBox> CheckBox;
	

	FOnStateChange OnStateChange;

private:
	FCheckBoxStyle Style;


public:
	
	UFUNCTION()
	void SetStyle(const FSlateBrush& Uncheck, const FSlateBrush& Check);



private:
	UFUNCTION()
	void OnCheckStateChange(bool IsCheck);





};
