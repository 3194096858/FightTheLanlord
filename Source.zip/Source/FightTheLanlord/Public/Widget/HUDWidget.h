﻿
#pragma once

#include "CoreMinimal.h"
#include "Widget/WidgetBase.h"
#include "HUDWidget.generated.h"


class UCanvasPanel;





UCLASS()
class FIGHTTHELANLORD_API UHUDWidget : public UWidgetBase
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;
	virtual void NativePreConstruct() override;
	virtual void NativeDestruct() override;
private:
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UCanvasPanel> CanvasPanel;

public:

	UFUNCTION()
	void AddWidgetToCanvasPanel(UWidgetBase* Widget, const FVector2D& Size, const FAnchorData& AnchorData);
	UFUNCTION()
	void RemoveWidgetFromCanvasPanel(UWidgetBase* Widget);




};
