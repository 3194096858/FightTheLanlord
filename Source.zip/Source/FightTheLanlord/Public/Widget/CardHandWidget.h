﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Widget/WidgetBase.h"
#include "CardHandWidget.generated.h"

class UCardWidget;
class UOverlay;

UCLASS()
class FIGHTTHELANLORD_API UCardHandWidget : public UWidgetBase
{
	GENERATED_BODY()
	

protected:
	virtual void NativeOnInitialized() override;
	virtual void NativeConstruct() override;
	virtual void NativePreConstruct() override;
	virtual void NativeDestruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

public:
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UOverlay> Overlay;

private:
	FTimerHandle DealCardTimerHandle;
public:
	UFUNCTION()
	void Clear();
	UFUNCTION()
	void ShowCard();
	UFUNCTION()
	void PlayDealCardAnimation();
	UFUNCTION()
	void AddCard(UCardWidget* Card);
	UFUNCTION()
	void RemoveCard(UCardWidget* Card);
	UFUNCTION()
	TArray<UCardWidget*> GetAllCard();
	UFUNCTION()
	void UpdateCardRelativeTransform();
	UFUNCTION()
	void SortByValue();
protected:
	virtual void OnLocalClientGameStateCompleteInitialize() override;
	virtual void OnServerGameStateCompleteInitialize() override;
	virtual void OnLocalClientPlayerControllerCompleteInitialize() override;

private:
	UFUNCTION()
	void OnLocalPlayerPlayCardSucceed();
	UFUNCTION()
	void OnDealCardComplete();







};
