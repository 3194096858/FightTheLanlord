﻿
#pragma once

#include "Struct/WidgetAsset.h"

#include "Struct/WidgetData.h"

#include "Components/CanvasPanelSlot.h"
#include "Struct/GameProperty.h"

#include "CoreMinimal.h"
#include "Widget/WidgetBase.h"
#include "ResourcePanel.generated.h"





class UImage;
class USizeBox;
class UTexture2D;
class UTextBlockWidget;
class UButtonWidget;
class UWidgetAnimation;

UCLASS()
class FIGHTTHELANLORD_API UResourcePanel : public UWidgetBase
{
	GENERATED_BODY()
public:
	virtual void NativeConstruct() override;
	virtual void NativePreConstruct() override;
	virtual void NativeDestruct() override;
	virtual void NativeOnInitialized() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

public:
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UImage> BeanIcon;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UTextBlockWidget> BeanTextBlock;
	
private:


public:
	UFUNCTION()
	void SetBeanIcon(UTexture2D* NewImage);
	UFUNCTION()
	void SetBeanIconColor(const FColor& NewColor);
	UFUNCTION()
	void SetBeanIconSize(const FVector2D& NewSize);
	UFUNCTION()
	void SetBeanIconRelativePosition(const FVector2D& NewPosition);
	UFUNCTION()
	void SetBeanTextBlockText(const FString& NewText);
	UFUNCTION()
	void SetBeanTextBlockFontColor(const FColor& NewColor);
	UFUNCTION()
	void SetBeanTextBlockFontSize(int32 NewSize);
	UFUNCTION()
	void SetBeanTextBlockTextRelativePosition(const FVector2D& NewPosition);
	UFUNCTION()
	void SetBeanTextBlockBackGroundImage(UTexture2D* NewImage);
	UFUNCTION()
	void SetBeanTextBlockBackGroundImageColor(const FColor& NewColor);
	

};
