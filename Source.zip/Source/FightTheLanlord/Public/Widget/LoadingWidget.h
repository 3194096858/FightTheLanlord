﻿
#pragma once

#include "CoreMinimal.h"
#include "Widget/WidgetBase.h"
#include "LoadingWidget.generated.h"


class Uimage;
class UCircularThrobber;

UCLASS()
class FIGHTTHELANLORD_API ULoadingWidget : public UWidgetBase
{
	GENERATED_BODY()

protected:
	virtual void NativeOnInitialized() override;
	virtual void NativeConstruct() override;
	virtual void NativePreConstruct() override;
	virtual void NativeDestruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

public:
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UImage> BackGroundImage;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UCircularThrobber> LoadingIcon;

private:

public:
	
	UFUNCTION()
	void PlayLoadingAnimation(bool IsForward = true);


};
