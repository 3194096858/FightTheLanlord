﻿
#pragma once

#include "CoreMinimal.h"
#include "Widget/WidgetBase.h"
#include "PlayerWidget.generated.h"



class UImage;
class USizeBox;
class UTexture2D;
class UTextBlockWidget;
class UButton;
class UWidgetAnimation;



UCLASS()
class FIGHTTHELANLORD_API UPlayerWidget : public UWidgetBase
{
	GENERATED_BODY()

public:
	virtual void NativeOnInitialized() override;
	virtual void NativeConstruct() override;
	virtual void NativePreConstruct() override;
	virtual void NativeDestruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;
public:

private:
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UTextBlockWidget> NameTextBlock;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UTextBlockWidget> CardNumberTextBlock;


public:
	UFUNCTION()
	FString GetPlayerName();
	UFUNCTION()
	void SetPlayerID(int32 NewID);
    UFUNCTION()
	void SetCardNumber(int32 NewValue);
	UFUNCTION()
	void SetCardNumberTextBlockVisibility(ESlateVisibility NewVisibility);
	UFUNCTION()
	void SetCardNumberTextBlockRelativePosition(const FVector2D& NewPosition);
	UFUNCTION()
	void InitializeNameTextBlock(FTextBlockWidgetData Data, FTextBlockWidgetAsset Asset);
	UFUNCTION()
	void InitializeCardNumberTextBlock(FTextBlockWidgetData Data, FTextBlockWidgetAsset Asset);

private:

	

};
