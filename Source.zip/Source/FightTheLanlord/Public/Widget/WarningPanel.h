﻿
#pragma once

#include "CoreMinimal.h"
#include "Widget/WidgetBase.h"
#include "WarningPanel.generated.h"


class UTextBlockWidget;
class USizeBox;
class UImage;
class UButtonWidget;
class UResourcePanel;


UCLASS()
class FIGHTTHELANLORD_API UWarningPanel : public UWidgetBase
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;
	virtual void NativePreConstruct() override;
	virtual void NativeDestruct() override;
	virtual void NativeOnInitialized() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

public:
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UButtonWidget> ConfirmButton;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UButtonWidget> CancelButton;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UTextBlockWidget> TextBlock;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UImage> BackGroundImage;
private:
	uint32 QuitSessionTimerID;
	FTimerHandle QuitSessionTimerHandle;
public:
	UFUNCTION()
	void SetDescription(const FString& NewDescription);






private:
	UFUNCTION()
	void InitializeConfirmButton();
	UFUNCTION()
	void OnClickConfirmButton();
	UFUNCTION()
	void InitializeCancelButton();
	UFUNCTION()
	void OnClickCancelButton();
	UFUNCTION()
	void OnWarningPanelOpen(const FString& WarningName);
	UFUNCTION()
	void OnWarningPanelClose();
	UFUNCTION()
	void QuitSession();


};
