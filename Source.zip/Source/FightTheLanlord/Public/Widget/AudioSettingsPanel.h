﻿
#pragma once

#include "CoreMinimal.h"
#include "Widget/WidgetBase.h"
#include "AudioSettingsPanel.generated.h"


class UScrollBox;
class USlider;
class UCheckBox;
class UImage;
class USizeBox;
class UTexture2D;
class UTextBlockWidget;
class UButton;
class UWidgetAnimation;
class UGameSettingsOptionWidget;


UCLASS()
class FIGHTTHELANLORD_API UAudioSettingsPanel : public UWidgetBase
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;
	virtual void NativePreConstruct() override;
	virtual void NativeDestruct() override;
	virtual void NativeOnInitialized() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;
public:
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UScrollBox> ScrollBox;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UGameSettingsOptionWidget> BGMOptionWidget;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UGameSettingsOptionWidget> SFXOptionWidget;
	

public:

private:
	UFUNCTION()
	void InitializeBGMOptionWidget();
	UFUNCTION()
	void InitializeSFXOptionWidget();
	UFUNCTION()
	void OnBGMVolumeChange(float Value);
	UFUNCTION()
	void OnSFXVolumeChange(float Value);

};
