﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Widget/WidgetBase.h"
#include "ComboBoxItemWidget.generated.h"


class UScrollBox;
class UComboBoxString;
class USliderWidget;
class UCheckBox;
class UImage;
class USizeBox;
class UTexture2D;
class UTextBlockWidget;
class UButtonWidget;
class UWidgetAnimation;

DECLARE_DELEGATE_TwoParams(FOnSelectionChange, FString, ESelectInfo::Type)


UCLASS()
class FIGHTTHELANLORD_API UComboBoxItemWidget : public UWidgetBase
{
	GENERATED_BODY()
public:
	virtual void NativeOnInitialized() override;
	virtual void NativeConstruct() override;
	virtual void NativePreConstruct() override;
	virtual void NativeDestruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;
public:
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UButtonWidget> Button;
	FOnSelectionChange OnSelectionChange;
private:

public:
	UFUNCTION()
	void SetIconVisibility(const ESlateVisibility& NewVisibility);
	UFUNCTION()
	void SetBackGroundImageVisibility(const ESlateVisibility& NewVisibility);
	UFUNCTION()
	void SetTextBlockVisibility(const ESlateVisibility& NewVisibility);
	void SetText(const FText& NewText);
	UFUNCTION()
	void SetIconOffsetPosition(const FVector2D& OffsetPosition);
	UFUNCTION()
	void SetTextOffsetPosition(const FVector2D& OffsetPosition);
	UFUNCTION()
	void SetIconImage(UTexture2D* NewIcon);
	UFUNCTION()
	void SetBackGroundImage(UTexture2D* NewBackGround);
	UFUNCTION()
	void SetBackGroundImageColor(const FColor& NewColor);
	UFUNCTION()
	void SetIconColor(const FColor& NewColor);
	void SetIconSize(const FVector2D& NewSize);
	UFUNCTION()
	void SetFontSize(int32 NewSize);
	UFUNCTION()
	void SetFontColor(const FColor& NewColor);
	UFUNCTION()
	void SetFontInformation(const FSlateFontInfo& NewFont);
private:
	UFUNCTION()
	void OnClickButton();

};
