﻿#pragma once

#include "CoreMinimal.h"
#include "Widget/WidgetBase.h"
#include "EditableTextBoxWidget.generated.h"



class UEditableTextBox;
class UImage;
class USizeBox;
class UTexture2D;
class UTextBlockWidget;
class UButton;
class UWidgetAnimation;

DECLARE_DELEGATE_OneParam(FOnTextChange ,const FText&);
DECLARE_DELEGATE_TwoParams(FOnTextCommit, const FText&, ETextCommit::Type);

UCLASS()
class FIGHTTHELANLORD_API UEditableTextBoxWidget : public UWidgetBase
{
	GENERATED_BODY()
public:
	virtual void NativeConstruct() override;
	virtual void NativePreConstruct() override;
	virtual void NativeDestruct() override;
	virtual void NativeOnInitialized() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;
public:
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UEditableTextBox> EditableTextBox;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UImage> BackGroundImage;

private:
	FOnTextCommit OnTextCommit;
	//FEditableTextBoxStyle Style;

public:
	UFUNCTION()
	void SetHintText(const FString& NewText);
	UFUNCTION()
	FString GetHintText();
	UFUNCTION()
	void SetBackGroundImageSlateBrush(const FSlateBrush& NewSlateBrush);
	UFUNCTION()
	void SetBackGroundImageVisibility(const ESlateVisibility& NewVisibility);
	UFUNCTION()
	void SetTextBlockVisibility(const ESlateVisibility& NewVisibility);
	void SetText(const FText& NewText);
	void SetText(const FString& NewText);
	UFUNCTION()
	void SetTextRelativePosition(const FVector2D& OffsetPosition);
	UFUNCTION()
	void SetBackGroundImage(UTexture2D* NewBackGround);
	UFUNCTION()
	void SetBackGroundImageColor(const FColor& NewColor);
	UFUNCTION()
	void SetFontSize(int32 NewSize);
	UFUNCTION()
	void SetFontColor(const FColor& NewColor);
	UFUNCTION()
	void SetFontInformation(const FSlateFontInfo& NewFont);
	void GetText(FText& Result);
	void GetText(FString& Result);
	void GetText(int32& Result);




private:
	UFUNCTION()
	void OnTextSubmit(const FText& Text, ETextCommit::Type CommitMethod);









	
};
