﻿

#pragma once

#include "CoreMinimal.h"
#include "Widget/WidgetBase.h"
#include "DisplaySettingsPanel.generated.h"


class UScrollBox;
class USlider;
class UCheckBox;
class UImage;
class USizeBox;
class UTexture2D;
class UTextBlockWidget;
class UButton;
class UWidgetAnimation;

class UGameSettingsOptionWidget;

UCLASS()
class FIGHTTHELANLORD_API UDisplaySettingsPanel : public UWidgetBase
{
	GENERATED_BODY()
public:
	virtual void NativeConstruct() override;
	virtual void NativePreConstruct() override;
	virtual void NativeDestruct() override;
	virtual void NativeOnInitialized() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;
public:
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UScrollBox> ScrollBox;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UGameSettingsOptionWidget> ScreenResolutionOptionWidget;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UGameSettingsOptionWidget> FPSLimitOptionWidget;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UGameSettingsOptionWidget> LanguageOptionWidget;

	
public:


private:
	UFUNCTION()
	void InitializeScreenResolutionOptionWidget();
	UFUNCTION()
	void InitializeFPSLimitOptionWidget();
	UFUNCTION()
	void InitializeScreenLanguageOptionWidget();
	UFUNCTION()
	void OnScreenResolutionChange(FString SelectedItem, ESelectInfo::Type SelectionInfo);
	UFUNCTION()
	void OnFPSLimitChange(FString SelectedItem, ESelectInfo::Type SelectionInfo);
	UFUNCTION()
	void OnLanguageChange(FString SelectedItem, ESelectInfo::Type SelectionInfo);
	UFUNCTION()
	void OnOpenScreenResolutionComboBoxMenu();



};
