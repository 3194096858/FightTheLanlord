﻿
#pragma once

#include "CoreMinimal.h"
#include "Widget/WidgetBase.h"
#include "PlayerPanel.generated.h"


class UImage;
class USizeBox;
class UTexture2D;
class UTextBlockWidget;
class UButton;
class UWidgetAnimation;
class UPlayerWidget;

UCLASS()
class FIGHTTHELANLORD_API UPlayerPanel : public UWidgetBase
{
	GENERATED_BODY()

public:
	virtual void NativeOnInitialized() override;
	virtual void NativeConstruct() override;
	virtual void NativePreConstruct() override;
	virtual void NativeDestruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;
public:
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UPlayerWidget> LocalPlayer;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UPlayerWidget> LeftPlayer;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UPlayerWidget> RightPlayer;


private:


public:
	UFUNCTION()
	void InitializeLocalPlayerWidget();
	UFUNCTION()
	void InitializeLeftPlayerWidget();
	UFUNCTION()
	void InitializeRightPlayerWidget();
	UFUNCTION()
	void SetLocalPlayerID(int32 NewID);
	UFUNCTION()
	void SetLocalPlayerCardNumber(int32 NewValue);
	UFUNCTION()
	void SetPlayerCardNumber(int32 PlayerID,int32 NewValue);
	UFUNCTION()
	void SetLeftPlayerID(int32 NewID);
	UFUNCTION()
	void SetLeftPlayerCardNumber(int32 NewValue);
	UFUNCTION()
	void SetRightPlayerID(int32 NewID);
	UFUNCTION()
	void SetRightPlayerCardNumber(int32 NewValue);
	UFUNCTION()
	void InitializePlayerID(int32 LocalPlayerID);
protected:
	virtual void OnLocalClientPlayerControllerCompleteInitialize() override;
	virtual void OnLocalClientPlayerStateCompleteInitialize() override;
	virtual void OnLocalClientGameStateCompleteInitialize() override;

private:
	UFUNCTION()
	void OnPlayerPanelOpen();
	UFUNCTION()
	void OnPlayerPanelClose();
	UFUNCTION()
	void OnDealCardComplete();

	UFUNCTION()
	void OnGameOver(bool IsLanlordWin);



};
