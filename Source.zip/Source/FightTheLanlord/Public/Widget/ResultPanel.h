﻿
#pragma once

#include "CoreMinimal.h"
#include "Widget/WidgetBase.h"
#include "ResultPanel.generated.h"




class UImage;
class USizeBox;
class UTexture2D;
class UTextBlockWidget;
class UButton;
class UWidgetAnimation;
class UButtonWidget;


UCLASS()
class FIGHTTHELANLORD_API UResultPanel : public UWidgetBase
{
	GENERATED_BODY()

public:
	virtual void NativeOnInitialized() override;
	virtual void NativeConstruct() override;
	virtual void NativePreConstruct() override;
	virtual void NativeDestruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;
public:


private:
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UImage> BackGroundImage;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UTextBlockWidget> GameOverTextBlock;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UTextBlockWidget> GameResultTextBlock;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UButtonWidget> ReturnButton;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UButtonWidget> QuitButton;
	FTimerHandle QuitSessionTimerHandle;

public:


private:
	UFUNCTION()
	void QuitSession();
	UFUNCTION()
	void SetGameResultTextBlockText(const FString& NewText);
	UFUNCTION()
	void OnResultPanelOpen();
	UFUNCTION()
	void OnResultPanelClose();

	UFUNCTION()
	void OnClickReturnButton();
	UFUNCTION()
	void OnClickQuitButton();
	UFUNCTION()
	void InitializeReturnButton();
	UFUNCTION()
	void InitializeQuitButton();
	UFUNCTION()
	void OnGameOver(bool IsLanlordWin);
	UFUNCTION()
	void InitializeGameOverTextBlock();
	UFUNCTION()
	void InitializeGameResultTextBlock();
	




};
