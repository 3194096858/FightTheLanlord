﻿
#pragma once

#include "CoreMinimal.h"
#include "Widget/WidgetBase.h"
#include "GameMainPage.generated.h"



class USizeBox;
class UImage;
class UButtonWidget;
class UResourcePanel;


UCLASS()
class FIGHTTHELANLORD_API UGameMainPage : public UWidgetBase
{
	GENERATED_BODY()
public:
	virtual void NativeConstruct() override;
	virtual void NativePreConstruct() override;
	virtual void NativeDestruct() override;
	virtual void NativeOnInitialized() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

public:
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UButtonWidget> SettingsButton;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UButtonWidget> SessionButton;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UButtonWidget> QuitGameButton;
	
private:


public:
	
private:
	UFUNCTION()
	void InitializeGameSettingsButton();
	UFUNCTION()
	void InitializeSessionButton();
	UFUNCTION()
	void InitializeQuitGameButton();
	UFUNCTION()
	void OnGameMainPageOpen();
	UFUNCTION()
	void OnGameMainPageClose();
	UFUNCTION()
	void OnClickSettingsButton();
	UFUNCTION()
	void OnClickSessionButton();

	UFUNCTION()
	void OnClickQuitGameButton();









};












