// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Widget/WidgetBase.h"
#include "ProgressBarWidget.generated.h"

/**
 * 
 */
UCLASS()
class FIGHTTHELANLORD_API UProgressBarWidget : public UWidgetBase
{
	GENERATED_BODY()
	
};
