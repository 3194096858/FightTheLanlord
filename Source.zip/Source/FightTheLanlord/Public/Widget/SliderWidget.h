﻿
#pragma once


#include "Struct/GameProperty.h"

#include "CoreMinimal.h"
#include "Widget/WidgetBase.h"
#include "SliderWidget.generated.h"




class USlider;
class UImage;
class USizeBox;
class UTexture2D;
class UTextBlockWidget;
class UButton;
class UWidgetAnimation;


DECLARE_DELEGATE_OneParam(FOnValueChange,float)





UCLASS()
class FIGHTTHELANLORD_API USliderWidget : public UWidgetBase
{
	GENERATED_BODY()

public:
	virtual void NativeOnInitialized() override;
	virtual void NativeConstruct() override;
	virtual void NativePreConstruct() override;
	virtual void NativeDestruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;
public:
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UImage> BackGroundImage;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<USlider> Slider;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UTextBlockWidget> TextBlock;
	
	FOnValueChange OnValueChange;
private:

public:
	UFUNCTION()
	int32 GetCurrentPercent();
	UFUNCTION()
	void SetCurrentPercent(int32 NewPercent);
	UFUNCTION()
	void SetStepSize(float NewSize);
	UFUNCTION()
	void SetBackGroundImage(UTexture2D* NewImage);
	UFUNCTION()
	void SetBarImage(UTexture2D* NewImage);
	UFUNCTION()
	void SetHandleImage(UTexture2D* NewImage);
	UFUNCTION()
	void SetHandleSize(const FVector2D& NewSize);
	UFUNCTION()
	void SetTextBlockVisibility(const ESlateVisibility& NewVisibility);
	UFUNCTION()
	void SetTextBlockRelativePosition(const FVector2D& NewSize);
	
	void SetText(const FString& NewText);
	UFUNCTION()
	void SetBackGroundImageColor(const FColor& NewColor);
	UFUNCTION()
	void SetBackGroundImageVisibility(const ESlateVisibility& NewVisibility);
	UFUNCTION()
	void SetBarColor(const FColor& NewColor);
	UFUNCTION()
	void SetHandleColor(const FColor& NewColor);
	UFUNCTION()
	void SetFontSize(int32 NewSize);
	UFUNCTION()
	void SetFontColor(const FColor& NewColor);
	UFUNCTION()
	void SetFontInformation(const FSlateFontInfo& NewFont);
	UFUNCTION()
	void SetBarThickness(float NewThickness);
	UFUNCTION()
	void SetValue(float NewValue);
	UFUNCTION()
	void SetMaxValue(float NewValue);
	UFUNCTION()
	void SetMinValue(float NewValue);
	UFUNCTION()
	float GetValue();
private:
	UFUNCTION()
	void OnValueUpdate(float Value);


};




