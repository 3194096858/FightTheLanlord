﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Widget/WidgetBase.h"
#include "MessagePanel.generated.h"

class USizeBox;
class UImage;
class UButtonWidget;
class UButton;
class UTextBlockWidget;
class UEditableTextBoxWidget;
class UScrollBox;
class UMessagePanel;

UCLASS()
class FIGHTTHELANLORD_API UMessagePanel : public UWidgetBase
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;
	virtual void NativePreConstruct() override;
	virtual void NativeDestruct() override;
	virtual void NativeOnInitialized() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;
public:

private:
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UEditableTextBoxWidget> EditableTextBox;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UImage> BackGroundImage;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UButtonWidget> SendingButton;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UScrollBox> ScrollBox;


public:
	UFUNCTION()
	void Clear();
	UFUNCTION()
	void AddMessage(UMessageWidget* MessageWidget);
	UFUNCTION()
	void RemoveMessage(UMessageWidget* MessageWidget);
	
private:
	UFUNCTION()
	void InitializeSendingButton();
	UFUNCTION()
	void OnClickSendingButton();
	UFUNCTION()
	void OnMessagePanelOpen();
	UFUNCTION()
	void OnMessagePanelClose();
	UFUNCTION()
	void OnGameOver(bool IsLanlordWin);

};
