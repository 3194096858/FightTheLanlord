﻿
#pragma once

#include "CoreMinimal.h"
#include "Widget/WidgetBase.h"
#include "BackGroundWidget.generated.h"



class UImage;
class UCanvasPanel;

class USizeBox;
class UImage;
class UButton;





UCLASS()
class FIGHTTHELANLORD_API UBackGroundWidget : public UWidgetBase
{
	GENERATED_BODY()
protected:
	virtual void NativeConstruct() override;
	virtual void NativePreConstruct() override;
	virtual void NativeDestruct() override;
public:
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UCanvasPanel> CanvasPanel;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UImage> BackGroundImage;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UButton> Button;
private:
public:
	UFUNCTION()
	void HideBackGroundImage();
	UFUNCTION()
	void ShowBackGroundImage();
	UFUNCTION()
	void SetBackGroundImage(UTexture2D* Texture);
	UFUNCTION()
	void AddWidgetToCanvasPanel(UWidgetBase* Widget, const FVector2D& Size, const FAnchorData& AnchorData);
	UFUNCTION()
	void RemoveWidgetFromCanvasPanel(UWidgetBase* Widget);
	UFUNCTION()
	void OnClickButton();




};
