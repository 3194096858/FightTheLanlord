﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Widget/WidgetBase.h"
#include "GameLobbyPanel.generated.h"

class USizeBox;
class UImage;
class UButtonWidget;
class UTextBlockWidget;
class UButtonWidget;


UCLASS()
class FIGHTTHELANLORD_API UGameLobbyPanel : public UWidgetBase
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;
	virtual void NativePreConstruct() override;
	virtual void NativeDestruct() override;
	virtual void NativeOnInitialized() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;


public:
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UTextBlockWidget> TextBlock;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UButtonWidget> QuitButton;
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UButtonWidget> StartFightingButton;


private:


public:
	UFUNCTION()
	void SetText(const FString& NewText);
	UFUNCTION()
	void SetCurrentPlayerNumber(int32 Number);

	UFUNCTION()
	void ShowStartFightingButton();
	UFUNCTION()
	void HideStartFightingButton();

private:
	UFUNCTION()
	void OnClickQuitButton();
	UFUNCTION()
	void OnClickStartFightingButton();
	UFUNCTION()
	void InitializeReturnButton();
	UFUNCTION()
	void InitializeStartFightingButton();
	UFUNCTION()
	void InitializeTextBlock();
	UFUNCTION()
	void OnGameLobbyPanelOpen();
	UFUNCTION()
	void OnGameLobbyPanelClose();
	UFUNCTION()
	void OnGameStart();

	UFUNCTION()
	void OnGameOver(bool IsLanlordWin);

};
