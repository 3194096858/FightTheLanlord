﻿#pragma once


#include "GameInstance/FTL_GameInstance.h"

#include "Manager/DelegateManager.h"
#include "Manager/FTL_AssetManager.h"

#include "CoreMinimal.h"
#include "Manager/ManagerBase.h"
#include "ObjectPoolManager.generated.h"

class UFTL_GameInstance;

UCLASS()
class FIGHTTHELANLORD_API UObjectPoolManager : public UManagerBase
{
	GENERATED_BODY()
	
public:

private:
	TMap<FString, TSet<AActor*>> ObjectPoolMap;

public:
	void ReturnObject(UFTL_GameInstance* GameInstance, const FString& PoolName,AActor* Object);

	template<class T>
	void GetObject(UFTL_GameInstance* GameInstance, const FString& PoolName, const FTransform& ObjectTransform)
	{
		AActor* Object = nullptr;
		TSet<AActor*> Pool;
		UClass* ObjectClass = T::StaticClass();
		if (GameInstance == nullptr)
		{
			return;
		}
		if (this->ObjectPoolMap.Find(PoolName) != nullptr)
		{
			Pool = *this->ObjectPoolMap.Find(PoolName);
		}
		if (Pool.Num() == 0)
		{
			Object = GetWorld()->SpawnActor<T>(ObjectClass, ObjectTransform.GetLocation(), ObjectTransform.Rotator());
			if (Object != nullptr)
			{
				Object->SetActorScale3D(ObjectTransform.GetScale3D());
			}
		///	GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, FString::Printf(TEXT("ObjectPoolManager:  Spawn Actor !!!!!")));

		}
		else
		{
			for (auto& Element : Pool)
			{
				if (Element != nullptr)
				{
					Object = Element;
					Object->SetActorTransform(ObjectTransform);
					Pool.Remove(Object);
					//GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, FString::Printf(TEXT("ObjectPoolManager:  GetActorFromPool   !!!!!")));

					break;
				}

			}

		}
		if (Object != nullptr)
		{
			GameInstance->GetDelegateManager()->OnObjectBeginPlay.Broadcast(Object);
			//GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, FString::Printf(TEXT("ObjectPoolManager:  Actor BeginPlay   !!!!!")));

		}

	}





};
