﻿
#pragma once
#include "Struct/LevelSwitchSettingsData.h"

#include "CoreMinimal.h"
#include "Manager/ManagerBase.h"
#include "LevelManager.generated.h"

class UFTL_GameInstance;


UCLASS()
class FIGHTTHELANLORD_API ULevelManager : public UManagerBase
{
	GENERATED_BODY()
	

public:
	ULevelManager();

private:
	FLevelSwitchSettingsData SettingsData;
public:
	void SetLevelSwitchSettings(const FString& LevelName,bool IsServer);
	void SetLevelSwitchSettings(const FString& HostIP);
	void SetLevelSwitchSettings(const FLevelSwitchSettingsData& NewData);
	UFUNCTION()
	void SwitchLevel(UFTL_GameInstance* GameInstance);
	UFUNCTION()
	void ResetLevelSwitchSettings();
	

};
