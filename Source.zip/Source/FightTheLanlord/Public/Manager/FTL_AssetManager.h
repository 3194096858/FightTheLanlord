﻿
#pragma once
#include "Enum/HandType.h"
#include "Struct/HandTypeInformation.h"
#include "Struct/WidgetAsset.h"
#include "CoreMinimal.h"
#include "Engine/AssetManager.h"
#include "FTL_AssetManager.generated.h"


class USoundMix;
class WidgetBase;
class UBehaviorTreeComponent;
class UBehaviorTree;
class AAIPlayer;
class AAIController;

//***牌库**//
USTRUCT(BlueprintType)
struct FCardLibraryAsset
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere)
	TObjectPtr<UTexture2D> CardBackImage;
	UPROPERTY(EditAnywhere)
	TObjectPtr<UDataTable> CardInformationTable;

};


UCLASS(Blueprintable)
class FIGHTTHELANLORD_API UFTL_AssetManager : public UAssetManager
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, Category = "UI")
	FWidgetAsset WidgetAsset;
private:
	UPROPERTY(EditAnywhere, Category = "Default")
	FCardLibraryAsset CardLibraryAsset;
	UPROPERTY(EditAnywhere, Category = "Default")
	TObjectPtr<UDataTable> HandTypeInformationTable;
	UPROPERTY(EditAnywhere, Category = "Audio")
	TMap<FString, USoundBase*> BGMMap;
	UPROPERTY(EditAnywhere, Category = "Audio")
	TMap<FString, USoundBase*> SFXMap;
	UPROPERTY(EditAnywhere, Category = "Audio")
	TObjectPtr<USoundMix> SoundMix;
	UPROPERTY(EditAnywhere, Category = "Audio")
	TObjectPtr<USoundClass> BGMSoundClass;
	UPROPERTY(EditAnywhere, Category = "Audio")
	TObjectPtr<USoundClass> SFXSoundClass;
	UPROPERTY(EditAnywhere, Category = "AI")
	TObjectPtr<UBehaviorTree> AIPlayerBehaviorTree;
	
public:
	UFUNCTION()
	UBehaviorTree* GetAIPlayerBehaviorTree();
	UFUNCTION()
	UClass* GetWidgetClass(const FString& WidgetName);
	UFUNCTION()
	TArray<FString> GetAllWidgetName();
	UFUNCTION()
	UDataTable* GetCardInformationTable();
	UFUNCTION()
	UTexture2D* GetCardImage(const FName& Name, ECardSuit Suit);
	UFUNCTION()
	USoundBase* GetHandTypeSFX(EHandType HandType,int32 Value);
	UFUNCTION()
	USoundBase* GetBGM(const FString& BGMName);
	UFUNCTION()
	USoundBase* GetSFX(const FString& SFXName);
	UFUNCTION()
	TArray<FString> GetAllBGMName();
	UFUNCTION()
	TArray<FString> GetAllSFXName();
	UFUNCTION()
	USoundMix* GetSoundMix();
	UFUNCTION()
	USoundClass* GetBGMSoundClass();
	UFUNCTION()
	USoundClass* GetSFXSoundClass();
	

};
