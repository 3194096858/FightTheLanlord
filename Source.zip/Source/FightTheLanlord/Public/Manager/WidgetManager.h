﻿
#pragma once
#include "Struct/WidgetAsset.h"
#include "Struct/WidgetData.h"
#include "Struct/CardInformation.h"

#include "Blueprint/UserWidget.h"
#include "Kismet/GameplayStatics.h"
#include "Enum/WidgetRenderingLevel.h"

#include "Components/CanvasPanelSlot.h"

#include "CoreMinimal.h"
#include "Manager/ManagerBase.h"
#include "WidgetManager.generated.h"

class UCardTableWidget;
class UOperationPanel;
class UPlayerWidget;
class UPlayerPanel;
class USessionWidget;
class UEditableTextBoxWidget;
class UGameSessionPanel;
class UButtonWidget;
class UGameSettingsOptionWidget;
class UFTL_GameInstance;
class UWidgetBase;
class UStartMenu;
class UBackGroundWidget;
class UHUDWidget;
class UUserTipWidget;
class UTextBlockWidget;
class UWidgetAnimation;
class UCardWidget;
class APlayerControllerBase;
class UGameMainPage;
class UGameSettingsPanel;
class UComboBoxMenuWidget;
class UWarningPanel;
class UResourcePanel;
class UGameLobbyPanel;
class UResultPanel;
class UHoleCardPanel;
class UTipWidgetBase;
class UMessageWidget;
class UMessagePanel;


UCLASS()
class FIGHTTHELANLORD_API UWidgetManager : public UManagerBase
{
	GENERATED_BODY()
public:
	UWidgetManager();
private:
	TMap<EWidgetRenderingLevel,TArray<UWidgetBase*>> ActiveWidgetMap;
	UPROPERTY()
	TMap<FName, FString> WarningPanelDecriptionMap;
	UPROPERTY()
	TArray<USessionWidget*> SessionWidgetArray;
	TMap<UCardWidget*,FCardInformation> ActiveCardInformationMap;
	UPROPERTY()
	TArray<UCardWidget*> CardWidgetArray;
	UPROPERTY()
	TArray<UMessageWidget*> MessageWidgetArray;
	UPROPERTY()
	TMap<FString, UWidgetBase*> WidgetMap;
	UPROPERTY()
	TArray<UTipWidgetBase*> TipWidgetArray;
public:
	UFUNCTION()
	void AddMessage(UMessageWidget* MessageWidget, int32 PlayerID, const FString& Message);
	UFUNCTION()
	UTipWidgetBase* GetTipWidget(UFTL_GameInstance* GameInstance);
	UFUNCTION()
	void ReturnTipWidget(UTipWidgetBase* TipWidget);
	UFUNCTION()
	void AddTipWidgetToViewport(UTipWidgetBase* TipWidget);
	UFUNCTION()
	void AddCardToHoleCardPanel(const TArray<FCardInformation>& CardArray);
	UFUNCTION()
	void UpdatePlayerCardNumber(int32 PlayerID,int32 NewValue);
	UFUNCTION()
	void AddCardToCardTable(const TArray<FCardInformation>& CardArray);
	UFUNCTION()
	void ClearCardTable();
	UFUNCTION()
	TArray<FCardInformation> GetAllSelectedCardInformationFromCardHand();
	UFUNCTION()
	TArray<UCardWidget*> GetAllSelectedCardWidgetFromCardHand();
	UFUNCTION()
	void PlayDealCardAnimation();
	UFUNCTION()
	void SetCountdownTimerText(int32 CurrentSecond);
	UFUNCTION()
	void ShowCountdownTimer();
	UFUNCTION()
	void HideCountdownTimer();
	UFUNCTION()
	void SetActiveCardInformation(UCardWidget* Widget,const FCardInformation& Information);
	UFUNCTION()
	TArray<FCardInformation> GetAllActiveCardInformation();
	UFUNCTION()
	FCardInformation GetActiveCardInformation(UCardWidget* ActiveCard);
	UFUNCTION()
	TArray<UCardWidget*> GetAllCardFromCardHand();
	UFUNCTION()
	void AddCardToCardHand(const FCardInformation& Information, UCardWidget* Widget);
	UFUNCTION()
	void RemoveCardFromCardHand(UCardWidget* Card);
	UFUNCTION()
	void RemoveAllCardFromCardHand();
	UFUNCTION()
	UCardWidget* GetCardWidget(UFTL_GameInstance* GameInstance);
	UFUNCTION()
	void ReturnCardWidget(UCardWidget* CardWidget);
	UFUNCTION()
	void DestroyAllCardWidget();
	UFUNCTION()
	void InitializPlayerID(int32 LocalPlayerID);
	UFUNCTION()
	void InitializeGameScreen();
	UFUNCTION()
	void PlayLoadingAnimation(bool IsForward = true);
	UFUNCTION()
	void OpenMessagePanel(const FVector2D& Size, const FAnchorData& AnchorData);
	UFUNCTION()
	void CloseMessagePanel();
	UFUNCTION()
	void OpenResultPanel(const FVector2D& Size, const FAnchorData& AnchorData);
	UFUNCTION()
	void CloseResultPanel();
	UFUNCTION()
	void OpenHoleCardPanel(const FVector2D& Size, const FAnchorData& AnchorData);
	UFUNCTION()
	void CloseHoleCardPanel();
	UFUNCTION()
	void OpenCardTableWidget(const FVector2D& Size, const FAnchorData& AnchorData);
	UFUNCTION()
	void CloseCardTableWidget();
	UFUNCTION()
	void OpenOperationPanel(const FVector2D& Size, const FAnchorData& AnchorData);
	UFUNCTION()
	void CloseOperationPanel();
	UFUNCTION()
	void OpenPlayerPanel(const FVector2D& Size, const FAnchorData& AnchorData);
	UFUNCTION()
	void ClosePlayerPanel();
	UFUNCTION()
	void SetGameLobbyPlayerNumber(int32 CurrentNumber);
	UFUNCTION()
	UMessageWidget* GetMessageWidget(UFTL_GameInstance* GameInstance);
	UFUNCTION()
	void ReturnMessageWidget(UMessageWidget* MessageWidget);
	UFUNCTION()
	USessionWidget* GetSessionWidget(UFTL_GameInstance* GameInstance);
	UFUNCTION()
	void ReturnSessionWidget(USessionWidget* SessionWidget);
	UFUNCTION()
	void DestroyAllSessionWidget();
	UFUNCTION()
	void InitializeEditableTextBox(UEditableTextBoxWidget* EditableTextBox, FEditableTextBoxWidgetData Data, FEditableTextBoxWidgetAsset Asset);
	UFUNCTION()
	void InitializeGameSettingsOption(UGameSettingsOptionWidget* GameSettingsOptionWidget, FGameSettingsOptionWidgetData Data, FGameSettingsOptionWidgetAsset Asset);
	UFUNCTION()
	void InitializeComboBox(UComboBoxWidget* ComboBox, FComboBoxWidgetData Data, FComboBoxWidgetAsset Asset);
	UFUNCTION()
	void InitializeTextBlock(UTextBlockWidget* TextBlock, FTextBlockWidgetData Data, FTextBlockWidgetAsset Asset);
	UFUNCTION()
	void InitializeButton(UButtonWidget* Button ,FButtonWidgetData Data, FButtonWidgetAsset Asset);
	UFUNCTION()
	void OpenGameSessionPanel(const FVector2D& Size, const FAnchorData& AnchorData);
	UFUNCTION()
	void CloseGameSessionPanel();
	UFUNCTION()
	FName GetWarningName(const FString& Description);
	UFUNCTION()
	void OpenGameLobbyPanel(const FVector2D& Size, const FAnchorData& AnchorData);
	UFUNCTION()
	void CloseGameLobbyPanel();
	UFUNCTION()
	void OpenComboBoxMenu(UComboBoxMenuWidget* Menu,const FVector2D& Size, const FAnchorData& AnchorData);
	UFUNCTION()
	void CloseComboBoxMenu(UComboBoxMenuWidget* Menu);
	UFUNCTION()
	void OpenWarningPanel(const FVector2D& Size, const FAnchorData& AnchorData, const FName& WarningName);
	UFUNCTION()
	void CloseWarningPanel();
	UFUNCTION()
	void OpenResourcePanel(const FVector2D& Size, const FAnchorData& AnchorData);
	UFUNCTION()
	void CloseResourcePanel();
	UFUNCTION()
	void OpenGameSettingsPanel(const FVector2D& Size, const FAnchorData& AnchorData);
	UFUNCTION()
	void CloseGameSettingsPanel(UFTL_GameInstance* GameInstance);
	UFUNCTION()
	void OpenGameMainPage(const FVector2D& Size, const FAnchorData& AnchorData);
	UFUNCTION()
	void CloseGameMainPage();
	UFUNCTION()
	void UpdateBackGroundImage(UFTL_GameInstance* GameInstance,const FName& BackGroundName);
	UFUNCTION()
	void InitializeWidget(UFTL_GameInstance* GameInstance);
	UFUNCTION()
	void AddWidgetToViewport(EWidgetRenderingLevel RenderingLevel,UWidgetBase* Widget, const FVector2D& Size, const FAnchorData& AnchorData);
	UFUNCTION()
	void OpenStartMenu(const FVector2D& Size, const FAnchorData& AnchorData);
	UFUNCTION()
	void CloseStartMenu();
	UFUNCTION()
	TArray<UWidgetBase*> GetAllActiveWidgetFromViewport(EWidgetRenderingLevel RenderingLevel);
	UFUNCTION()
	void RemoveWidgetFromViewport(EWidgetRenderingLevel RenderingLevel,UWidgetBase* Widget);
	UFUNCTION()
	void RemoveTopWidgetFromViewport(EWidgetRenderingLevel RenderingLevel);
	UFUNCTION()
	void RemoveAllWidgetFromViewport(EWidgetRenderingLevel RenderingLevel);
	template<typename T>
	T* SpawnWidget(UClass* WidgetClass)
	{
		T* Widget = nullptr;
		if (WidgetClass == nullptr)
		{
			Widget = CreateWidget<T>(UGameplayStatics::GetPlayerController(this, 0));
		}
		else
		{
			Widget = CreateWidget<T>(UGameplayStatics::GetPlayerController(this, 0), WidgetClass);

		}
		return Widget;
	};
private:
	UFUNCTION()
	void OnWidgetAddToHUD(TArray<UWidgetBase*> ActiveWidgetArray);
	UFUNCTION()
	void OnWidgetRemoveFromHUD(TArray<UWidgetBase*> ActiveWidgetArray);
	UFUNCTION()
	UWidgetBase* GetWidget(const FString& WidgetName);
	UFUNCTION()
	UBackGroundWidget* GetBackGroundWidget();
	UFUNCTION()
	UHUDWidget* GetHUDWidget();
	UFUNCTION()
	UUserTipWidget* GetUserTipWidget();
	UFUNCTION()
	UHoleCardPanel* GetHoleCardPanel();
	UFUNCTION()
	UPlayerPanel* GetPlayerPanel();
	UFUNCTION()
	UOperationPanel* GetOperationPanel();
	UFUNCTION()
	UGameSessionPanel* GetGameSessionPanel();
	UFUNCTION()
	UGameSettingsPanel* GetGameSettingPanel();
	UFUNCTION()
	UStartMenu* GetStartMenu();
	UFUNCTION()
	UGameMainPage* GetGameMainPage();
	UFUNCTION()
	UResultPanel* GetResultPanel();
	UFUNCTION()
	UGameLobbyPanel* GetGameLobbyPanel();
	UFUNCTION()
	UCardTableWidget* GetCardTableWidget();
	UFUNCTION()
	UMessagePanel* GetMessagePanel();
};


















