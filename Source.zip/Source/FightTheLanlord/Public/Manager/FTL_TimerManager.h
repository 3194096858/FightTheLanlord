﻿
#pragma once

#include "CoreMinimal.h"
#include "Manager/ManagerBase.h"
#include "FTL_TimerManager.generated.h"




UCLASS()
class FIGHTTHELANLORD_API UFTL_TimerManager : public UManagerBase
{
	GENERATED_BODY()

public:


private:
	TMap<uint32, FTimerHandle> TimerHandleMap;

public:
	UFUNCTION()
	FTimerHandle GetTimerHandle(uint32 ID, bool& IsExists);
	UFUNCTION()
	void ClearTimer(uint32 ID);
	UFUNCTION()
	void ClearAllTimer();
	UFUNCTION()
	void ClearAllTimerForObject(UObject* Object);
	UFUNCTION()
	void PauseAllTimer();
	UFUNCTION()
	void UnpauseAllTimer();
	UFUNCTION()
	void PauseTimer(uint32 ID);
	UFUNCTION()
	void UnpauseTimer(uint32 ID);
	UFUNCTION()
	bool CheckTimerIsPause(uint32 ID);
	UFUNCTION()
	bool CheckTimerIsExists(uint32 ID);
	UFUNCTION()
	float GetTimerRemainingTime(uint32 ID);
	UFUNCTION()
	int32 GetRandomID();
	template<typename T>
	void SetTimer(T* Object, uint32 ID, typename FTimerDelegate::TMethodPtr<T> Function, float PlayRate = 1.0f, bool IsLoop = false, float FirstDelay = -1.0f)
	{
		if (this->TimerHandleMap.Find(ID) != nullptr)
		{
			return;
		}
		FTimerDelegate Delegate = FTimerDelegate::CreateUObject(Object, Function);
		FTimerHandle TimerHandle;
		GetWorld()->GetTimerManager().SetTimer(TimerHandle, Delegate, PlayRate, IsLoop, FirstDelay);
		this->TimerHandleMap.Add(ID, TimerHandle);
	};

};
