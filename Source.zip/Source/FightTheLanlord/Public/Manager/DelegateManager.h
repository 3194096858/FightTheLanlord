﻿
#pragma once

#include "CoreMinimal.h"
#include "Manager/ManagerBase.h"
#include "DelegateManager.generated.h"



/// ****唯一绑定委托******
DECLARE_MULTICAST_DELEGATE(FOnGameMainPageOpen);
DECLARE_MULTICAST_DELEGATE(FOnGameMainPageClose);
DECLARE_MULTICAST_DELEGATE(FOnGameSettingsPanelOpen);
DECLARE_MULTICAST_DELEGATE(FOnGameSettingsPanelClose);
DECLARE_MULTICAST_DELEGATE(FOnGameSessionPanelOpen);
DECLARE_MULTICAST_DELEGATE(FOnGameSessionPanelClose);
DECLARE_MULTICAST_DELEGATE(FOnGameLobbyPanelOpen);
DECLARE_MULTICAST_DELEGATE(FOnGameLobbyPanelClose);
DECLARE_MULTICAST_DELEGATE(FOnStartMenuOpen);
DECLARE_MULTICAST_DELEGATE(FOnStartMenuClose);
DECLARE_MULTICAST_DELEGATE_OneParam(FOnWarningPanelOpen,const FString&);
DECLARE_MULTICAST_DELEGATE(FOnWarningPanelClose);
DECLARE_MULTICAST_DELEGATE(FOnPlayerPanelOpen);
DECLARE_MULTICAST_DELEGATE(FOnPlayerPanelClose);
DECLARE_MULTICAST_DELEGATE(FOnOperationPanelOpen);
DECLARE_MULTICAST_DELEGATE(FOnOperationPanelClose);
DECLARE_MULTICAST_DELEGATE(FOnMessagePanelOpen);
DECLARE_MULTICAST_DELEGATE(FOnMessagePanelClose);
DECLARE_MULTICAST_DELEGATE(FOnResultPanelOpen);
DECLARE_MULTICAST_DELEGATE(FOnResultPanelClose);
DECLARE_MULTICAST_DELEGATE(FOnHoleCardPanelOpen);
DECLARE_MULTICAST_DELEGATE(FOnHoleCardPanelClose);
DECLARE_MULTICAST_DELEGATE(FOnCardTableWidgetOpen);
DECLARE_MULTICAST_DELEGATE(FOnCardTableWidgetClose);
DECLARE_MULTICAST_DELEGATE(FOnLocalClientGameStateCompleteInitialize);
DECLARE_MULTICAST_DELEGATE(FOnLocalClientPlayerStateCompleteInitialize);
DECLARE_MULTICAST_DELEGATE(FOnServerGameStateCompleteInitialize);
DECLARE_MULTICAST_DELEGATE(FOnLocalClientPlayerControllerCompleteInitialize);
DECLARE_MULTICAST_DELEGATE(FOnGameStart);
DECLARE_MULTICAST_DELEGATE_OneParam(FOnGameOver,bool);
DECLARE_MULTICAST_DELEGATE(FOnLocalPlayerPlayCardSucceed);

/// ****唯一调用委托******
DECLARE_MULTICAST_DELEGATE_OneParam(FOnObjectBeginPlay, AActor*);
DECLARE_MULTICAST_DELEGATE_OneParam(FOnObjectEndPlay, AActor*);
DECLARE_MULTICAST_DELEGATE(FOnDealCardComplete);
DECLARE_MULTICAST_DELEGATE(FOnGameQuit);
DECLARE_MULTICAST_DELEGATE(FOnLocalClientSwitchLevel);
DECLARE_MULTICAST_DELEGATE_OneParam(FOnLocalClientSwitchLevelComplete, const FString& );
DECLARE_MULTICAST_DELEGATE_OneParam(FOnPlayLoadingAnimationComplete,bool);
DECLARE_MULTICAST_DELEGATE_OneParam(FOnCreateAIPlayer, int32);




UCLASS()
class FIGHTTHELANLORD_API UDelegateManager : public UManagerBase
{
	GENERATED_BODY()
	
public:
	FOnObjectBeginPlay OnObjectBeginPlay;
	FOnObjectEndPlay OnObjectEndPlay;
	FOnGameMainPageOpen OnGameMainPageOpen;
	FOnGameMainPageClose OnGameMainPageClose;
	FOnGameSettingsPanelOpen OnGameSettingsPanelOpen;
	FOnGameSettingsPanelClose OnGameSettingsPanelClose;
	FOnGameSessionPanelOpen OnGameSessionPanelOpen;
	FOnGameSessionPanelClose OnGameSessionPanelClose;
	FOnGameLobbyPanelOpen OnGameLobbyPanelOpen;
	FOnGameLobbyPanelClose OnGameLobbyPanelClose;
	FOnStartMenuOpen OnStartMenuOpen;
	FOnStartMenuClose OnStartMenuClose;
	FOnWarningPanelOpen OnWarningPanelOpen;
	FOnWarningPanelClose OnWarningPanelClose;
	FOnPlayerPanelOpen OnPlayerPanelOpen;
	FOnPlayerPanelClose OnPlayerPanelClose;
	FOnOperationPanelOpen OnOperationPanelOpen;
	FOnOperationPanelClose OnOperationPanelClose;
	FOnCardTableWidgetOpen OnCardTableWidgetOpen;
	FOnCardTableWidgetClose OnCardTableWidgetClose;
	FOnResultPanelOpen OnResultPanelOpen;
	FOnResultPanelClose OnResultPanelClose;
	FOnHoleCardPanelOpen OnHoleCardPanelOpen;
	FOnHoleCardPanelClose OnHoleCardPanelClose;
	FOnMessagePanelOpen OnMessagePanelOpen;
	FOnMessagePanelClose OnMessagePanelClose;
	FOnGameQuit OnGameQuit;
	FOnGameStart OnGameStart;
	FOnGameOver OnGameOver;
	FOnLocalClientGameStateCompleteInitialize OnLocalClientGameStateCompleteInitialize;
	FOnLocalClientPlayerStateCompleteInitialize OnLocalClientPlayerStateCompleteInitialize;
	FOnServerGameStateCompleteInitialize OnServerGameStateCompleteInitialize;
	FOnLocalClientPlayerControllerCompleteInitialize OnLocalClientPlayerControllerCompleteInitialize;
	FOnLocalClientSwitchLevel OnLocalClientSwitchLevel;
	FOnLocalClientSwitchLevelComplete OnLocalClientSwitchLevelComplete;
	FOnPlayLoadingAnimationComplete OnPlayLoadingAnimationComplete;
	FOnLocalPlayerPlayCardSucceed OnLocalPlayerPlayCardSucceed;
	FOnDealCardComplete OnDealCardComplete;
	FOnCreateAIPlayer OnCreateAIPlayer;

};
