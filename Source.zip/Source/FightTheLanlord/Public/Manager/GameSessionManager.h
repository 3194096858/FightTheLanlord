﻿
#pragma once
#include "OnlineSessionSettings.h"
#include "OnlineSubsystem.h"
#include "Interfaces/OnlineSessionInterface.h"


#include "CoreMinimal.h"
#include "Manager/ManagerBase.h"
#include "GameSessionManager.generated.h"


class USessionWidget;
class UFTL_GameInstance;
namespace NS_SessionDelegate
{
	DECLARE_MULTICAST_DELEGATE(FOnCreateSession);
	DECLARE_MULTICAST_DELEGATE(FOnDestroySession);
	DECLARE_MULTICAST_DELEGATE(FOnJoinSession);
	DECLARE_MULTICAST_DELEGATE(FOnSearchSession);
	DECLARE_MULTICAST_DELEGATE_OneParam(FOnCreateSessionComplete, const FName&);
	DECLARE_MULTICAST_DELEGATE_OneParam(FOnDestroySessionComplete, const FName&);
	DECLARE_MULTICAST_DELEGATE_OneParam(FOnJoinSessionComplete, const FName&);
	DECLARE_MULTICAST_DELEGATE_OneParam(FOnSearchSessionComplete, TSharedPtr<FOnlineSessionSearch>);
	DECLARE_MULTICAST_DELEGATE_OneParam(FOnQuitSessionComplete, const FName&);
	DECLARE_MULTICAST_DELEGATE(FOnSessionConnectFailure);



};

UCLASS()
class FIGHTTHELANLORD_API UGameSessionManager : public UManagerBase
{
	GENERATED_BODY()
public:
	UGameSessionManager();
public:
	NS_SessionDelegate::FOnSearchSession OnSearchSession;
	NS_SessionDelegate::FOnCreateSession OnCreateSession;
	NS_SessionDelegate::FOnJoinSession OnJoinSession;
	NS_SessionDelegate::FOnDestroySession OnDestroySession;
	NS_SessionDelegate::FOnSearchSessionComplete OnSearchSessionComplete;
	NS_SessionDelegate::FOnCreateSessionComplete OnCreateSessionComplete;
	NS_SessionDelegate::FOnJoinSessionComplete OnJoinSessionComplete;
	NS_SessionDelegate::FOnDestroySessionComplete OnDestroySessionComplete;
	NS_SessionDelegate::FOnQuitSessionComplete OnQuitSessionComplete;
	NS_SessionDelegate::FOnSessionConnectFailure OnSessionConnectFailure;

private:
	IOnlineSubsystem* OnlineSubsystem = nullptr;
	TSharedPtr<FOnlineSessionSearch> SessionSearchSettings = nullptr;
	FDelegateHandle CreateSessionHandle;
	FDelegateHandle JoinSessionHandle;
	FDelegateHandle SearchSessionHandle;
	FDelegateHandle DestroySessionHandle;
	FDelegateHandle SessionConnectFailureHandle;

	TMap<FString,FNamedOnlineSession*> LocalSessionMap;
	TMap<FString,FOnlineSessionSearchResult*> RemoteSessionMap;
	bool IsQuit = false;
	FString CurrentSessionName = TEXT("None");
	FString SelectedSessionName = TEXT("None");
	TArray<FString> JoinedSessionIDArray;

public:
	UFUNCTION()
	bool CheckIsLocalSession(const FString& SessionName);
	UFUNCTION()
	void SetSelectedSessionName(const FString& NewSession);
	UFUNCTION()
	void SetCurrentSessionName(const FString& NewSession);
	UFUNCTION()
	FString GetSelectedSessionName();
	UFUNCTION()
	FString GetCurrentSessionName();
	UFUNCTION()
	void CreateSession();
	UFUNCTION()
	void SearchSession();
	void JoinSession(const FString& SessionName,const FOnlineSessionSearchResult& SearchResult);
	UFUNCTION()
	void JoinSelectedSession();
	UFUNCTION()
	void DestroySession(const FString& SessionName);
	UFUNCTION()
	void DestroySelectedSession();
	UFUNCTION()
	void QuitSession(const FString& SessionName);
	UFUNCTION()
	void QuitCurrentSession();
	UFUNCTION()
	void GetHostIPAndPort(const FName& SessionName, FString& IP, FString& Port);
	FNamedOnlineSession* GetLocalSession(const FString& SessionName);
	TArray<FNamedOnlineSession*> GetAllLocalSession();
	////TArray<FOnlineSession*> GetAllRemoteSession();
	FString GetLocalSessionName(FNamedOnlineSession* Session);
	FString GetRemoteSessionName(FOnlineSessionSearchResult* SearchResult);
	FOnlineSessionSearchResult* GetRemoteSession(const FString& SessionName);



private:
	IOnlineSubsystem* GetOnlineSubsystem();
	UFUNCTION()
	void OnCreateSessionFinish(FName SessionName,bool bWasSuccessful);
	
	void OnJoinSessionFinish(FName SessionName, EOnJoinSessionCompleteResult::Type Result);
	UFUNCTION()
	void OnSearchSessionFinish(bool bWasSuccessful);
	
	UFUNCTION()
	void OnDestroySessionFinish(FName SessionName, bool bWasSuccessful);

	void OnSessionConnectInterrupt(const FUniqueNetId& NetId, ESessionFailure::Type FailureType);
};
