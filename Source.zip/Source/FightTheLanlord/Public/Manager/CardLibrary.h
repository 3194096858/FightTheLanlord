﻿
#pragma once

#include "Enum/CardSuit.h"
#include "Struct/CardInformation.h"
#include "CoreMinimal.h"
#include "Manager/ManagerBase.h"
#include "CardLibrary.generated.h"


class UFTL_GameInstance;
class AFTL_GameModeBase;
class UWidgetBase;
class UStartMenu;
class UBackGroundWidget;
class UHUDWidget;
class UUserTipWidget;
class UTextBlockWidget;
class UWidgetAnimation;
class UCardWidget;


UCLASS()
class FIGHTTHELANLORD_API UCardLibrary : public UManagerBase
{
	GENERATED_BODY()
public:
	

private:
	TArray<FCardInformation*> CardArray;
	TArray<FCardInformation*> ActiveCardArray;


public:
	UFUNCTION()
	void Initialize(UFTL_GameInstance* GameInstance);
	UFUNCTION()
	FCardInformation GetRandomCard();
	UFUNCTION()
	FCardInformation GetCardByIndex(int32 CardIndex);
	
private:
	







};
