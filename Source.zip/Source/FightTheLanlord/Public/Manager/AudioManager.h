﻿
#pragma once

#include "CoreMinimal.h"
#include "Manager/ManagerBase.h"
#include "AudioManager.generated.h"


class UAudioComponent;

class AFTL_GameModeBase;

class UFTL_GameInstance;





UCLASS()
class FIGHTTHELANLORD_API UAudioManager : public UManagerBase
{
	GENERATED_BODY()
	
public:
	UAudioManager();


private:
    /*UPROPERTY()
	TObjectPtr<UAudioComponent> AudioComponent111;*/

	UPROPERTY()
	TMap<FString, UAudioComponent*> BGMAudioComponentMap;


public:
	UFUNCTION()
	UAudioComponent* GetBGMAudioComponent(const FString& BGMName);
	UFUNCTION()
	void Initialize(UFTL_GameInstance* GameInstance);
	UFUNCTION()
	void PlayBGM(const FString& BGMName);
	UFUNCTION()
	void PauseAllBGM();
	UFUNCTION()
	void PauseBGM(const FString& BGMName);
	UFUNCTION()
	void UnpauseBGM(const FString& BGMName);
	UFUNCTION()
	void SetBGMVolume(USoundMix* SoundMix, USoundClass* BGMSoundClass,float NewVolume);
	UFUNCTION()
	void SetSFXVolume(USoundMix* SoundMix, USoundClass* SFXSoundClass, float NewVolume);
    UFUNCTION()
    void PlaySFX(USoundBase* SFX);
 


};
