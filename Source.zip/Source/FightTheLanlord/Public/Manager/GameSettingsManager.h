﻿
#pragma once





#include "CoreMinimal.h"
#include "Manager/ManagerBase.h"
#include "GameSettingsManager.generated.h"



class UGameUserSettings;



UCLASS()
class FIGHTTHELANLORD_API UGameSettingsManager : public UManagerBase
{
	GENERATED_BODY()
public:
	UGameSettingsManager();
public:

private:
	UPROPERTY()
	TObjectPtr<UGameUserSettings> UserSettings;
	UPROPERTY()
	TMap<FString, FIntPoint> ResolutionMap;

public:
	void GetAllResolution(TArray<FIntPoint>& ResolutionArray);
	void GetAllResolution(TArray<FString>& ResolutionArray);
	void SetScreenResolution(const FIntPoint& NewResolution);
	void SetScreenResolution(const FString& NewResolution);
	void GetScreenResolution(FIntPoint& CurrentResolution);
	void GetScreenResolution(FString& CurrentResolution);


	UFUNCTION()
	void SetWindowMode(const EWindowMode::Type& NewMode);
	EWindowMode::Type GetWindowMode();
	bool CheckResolutionIsExist(const FIntPoint& Resolution);
	bool CheckResolutionIsExist(const FString& Resolution);

private:
	UGameUserSettings* GetGameUserSettings();


















};
