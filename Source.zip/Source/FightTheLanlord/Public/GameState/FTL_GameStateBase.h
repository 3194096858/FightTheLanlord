﻿

#include "Struct/GameSettingsData.h"

#include "Struct/WidgetData.h"
#include "Struct/GameProperty.h"
#include "Components/CanvasPanelSlot.h"
#include "Enum/GameSettingsOptionType.h"



#include "CoreMinimal.h"
#include "GameFramework/GameStateBase.h"
#include "FTL_GameStateBase.generated.h"


class APlayerState;

//***牌库数据****//
USTRUCT(BlueprintType)
struct FCardLibraryData
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, SaveGame)
	uint32 Size = 54;
	UPROPERTY(EditAnywhere, SaveGame)
	FVector2D Position = FVector2D(0.0f);


};




//***游戏默认数据*****///
USTRUCT(BlueprintType)
struct FGameDefaultData
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, SaveGame)
	FGameSettingsData GameSettings;
	UPROPERTY(EditAnywhere, SaveGame)
	FWidgetData Widget;
	UPROPERTY(EditAnywhere, SaveGame)
	FCardLibraryData CardLibrary;



};

UCLASS()
class FIGHTTHELANLORD_API AFTL_GameStateBase : public AGameStateBase
{
	GENERATED_BODY()

public:
	AFTL_GameStateBase();
protected:
	virtual void BeginPlay() override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps)const override;
	virtual void OnRep_ReplicatedHasBegunPlay() override;


public:
	UPROPERTY(EditAnywhere, SaveGame)
	FGameDefaultData GameDefaultData;

	UPROPERTY(EditAnywhere, SaveGame)
	FGameSettingsData PlayerSettingsData;

private:
	
public:












};
