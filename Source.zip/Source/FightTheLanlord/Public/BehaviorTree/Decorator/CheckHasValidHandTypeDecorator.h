﻿
#pragma once

#include "CoreMinimal.h"
#include "BehaviorTree/BTDecorator.h"
#include "CheckHasValidHandTypeDecorator.generated.h"



UCLASS()
class FIGHTTHELANLORD_API UCheckHasValidHandTypeDecorator : public UBTDecorator
{
	GENERATED_BODY()
private:

	virtual bool CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const override;

};
