﻿
#pragma once

#include "CoreMinimal.h"
#include "BehaviorTree/BTDecorator.h"
#include "CheckIsMyTrunDecorator.generated.h"

UCLASS()
class FIGHTTHELANLORD_API UCheckIsMyTrunDecorator : public UBTDecorator
{
	GENERATED_BODY()
private:

	 virtual bool CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const override;

};
