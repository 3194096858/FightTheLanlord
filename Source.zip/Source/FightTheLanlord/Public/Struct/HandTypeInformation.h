﻿#pragma once

#include "Enum/Handtype.h"


#include "CoreMinimal.h"
#include "HandTypeInformation.generated.h"

USTRUCT(BlueprintType)

struct FHandTypeInformation: public FTableRowBase
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, SaveGame)
    EHandType HandType = EHandType::None;
    UPROPERTY(EditAnywhere, SaveGame)
    int32 Value = -1;
    UPROPERTY(EditAnywhere, SaveGame)
    int32 Number = -1;
    UPROPERTY(EditAnywhere)
    USoundBase* SFX;

    FHandTypeInformation(): HandType(EHandType::None),Value(-1),Number(-1),SFX(nullptr)
    {
       
    }

};











