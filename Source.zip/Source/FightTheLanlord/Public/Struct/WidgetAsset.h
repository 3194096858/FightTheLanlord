﻿#pragma once



#include "CoreMinimal.h"

#include "WidgetAsset.generated.h"



//***控件基类**//
USTRUCT(BlueprintType)
struct FWidgetBaseAsset
{
	GENERATED_BODY()


};

//***文本框控件**//
USTRUCT(BlueprintType)
struct FImageWidgetAsset : public FWidgetBaseAsset
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere)
	TObjectPtr<UTexture2D> Image;


};

//***文本框控件**//
USTRUCT(BlueprintType)
struct FTextBlockWidgetAsset : public FWidgetBaseAsset
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere)
	FImageWidgetAsset BackGroundImage;

};



//***按钮控件**//
USTRUCT(BlueprintType)
struct FButtonWidgetAsset : public FWidgetBaseAsset
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere)
	FImageWidgetAsset Icon;

	UPROPERTY(EditAnywhere)
	FImageWidgetAsset BackGroundImage;



};

//***可编辑文本框控件**//
USTRUCT(BlueprintType)
struct FEditableTextBoxWidgetAsset : public FWidgetBaseAsset
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere, SaveGame)
	FImageWidgetAsset BackGroundImage;


};

//***进度条控件**//
USTRUCT(BlueprintType)
struct FProgressBarWidgetAsset : public FWidgetBaseAsset
{
	GENERATED_BODY()

};

//***勾选框控件**//
USTRUCT(BlueprintType)
struct FCheckBoxWidgetAsset : public FWidgetBaseAsset
{
	GENERATED_BODY()
	
};

//***滑条控件**//
USTRUCT(BlueprintType)
struct FSliderWidgetAsset : public FWidgetBaseAsset
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere, SaveGame)
	FImageWidgetAsset BackGroundImage;
	UPROPERTY(EditAnywhere, SaveGame)
	FTextBlockWidgetAsset TextBlock;
	UPROPERTY(EditAnywhere, SaveGame)
	FImageWidgetAsset BarImage;
	UPROPERTY(EditAnywhere, SaveGame)
	FImageWidgetAsset HandleImage;
};

//***组合框控件**//
USTRUCT(BlueprintType)
struct FComboBoxWidgetAsset : public FWidgetBaseAsset
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere)
	FButtonWidgetAsset Button;

	UPROPERTY(EditAnywhere)
	FImageWidgetAsset Menu;

	UPROPERTY(EditAnywhere)
	FButtonWidgetAsset ItemButton;





};

//***消息面板***//
USTRUCT(BlueprintType)
struct FMessagePanelAsset : public FWidgetBaseAsset
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere, SaveGame)
	FEditableTextBoxWidgetAsset EditableTextBox;
	UPROPERTY(EditAnywhere, SaveGame)
	FImageWidgetAsset BackGroundImage;
	UPROPERTY(EditAnywhere, SaveGame)
	FButtonWidgetAsset SendingButton;
};


//***会话控件**//
USTRUCT(BlueprintType)
struct FSessionWidgetAsset : public FWidgetBaseAsset
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere)
	FButtonWidgetAsset JoinButton;
	UPROPERTY(EditAnywhere)
	FButtonWidgetAsset DeleteButton;
	UPROPERTY(EditAnywhere)
	FImageWidgetAsset Icon;
	UPROPERTY(EditAnywhere)
	FImageWidgetAsset BackGroundImage;



};
//***游戏设置选项控件**//
USTRUCT(BlueprintType)
struct FGameSettingsOptionWidgetAsset : public FWidgetBaseAsset
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere)
	FImageWidgetAsset TextBlock;
	UPROPERTY(EditAnywhere)
	FImageWidgetAsset BackGroundImage;
	UPROPERTY(EditAnywhere)
	FCheckBoxWidgetAsset CheckBox;
	UPROPERTY(EditAnywhere)
	FComboBoxWidgetAsset ComboBox;
	UPROPERTY(EditAnywhere)
	FSliderWidgetAsset Slider;

};

//***玩家控件***//
USTRUCT(BlueprintType)
struct FPlayerWidgetAsset : public FWidgetBaseAsset
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere)
	FTextBlockWidgetAsset NameTextBlock;
	UPROPERTY(EditAnywhere)
	FTextBlockWidgetAsset CardNumberTextBlock;


};

//***手牌控件***//
USTRUCT(BlueprintType)
struct FCardHandWidgetAsset : public FWidgetBaseAsset
{
	GENERATED_BODY()


};

//***倒计时定时器控件***//
USTRUCT(BlueprintType)
struct FCountdownTimerWidgetAsset : public FWidgetBaseAsset
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere)
	FTextBlockWidgetAsset TextBlock;
	

};

//***操作面板***//
USTRUCT(BlueprintType)
struct FOperationPanelAsset : public FWidgetBaseAsset
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere, SaveGame)
	FButtonWidgetAsset PlayCardButton;
	UPROPERTY(EditAnywhere, SaveGame)
	FButtonWidgetAsset PassButton;
	UPROPERTY(EditAnywhere, SaveGame)
	FButtonWidgetAsset MessageButton;
	UPROPERTY(EditAnywhere, SaveGame)
	FCountdownTimerWidgetAsset CountdownTimer;
	UPROPERTY(EditAnywhere, SaveGame)
	FCardHandWidgetAsset CardHand;
};

//***底牌面板***//
USTRUCT(BlueprintType)
struct FHoleCardPanelAsset : public FWidgetBaseAsset
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere, SaveGame)
	FImageWidgetAsset BackGroundImage;

};

//***结算面板***//
USTRUCT(BlueprintType)
struct FResultPanelAsset : public FWidgetBaseAsset
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere, SaveGame)
	FTextBlockWidgetAsset GameOverTextBlock;
	UPROPERTY(EditAnywhere, SaveGame)
	FTextBlockWidgetAsset GameResultTextBlock;
	UPROPERTY(EditAnywhere, SaveGame)
	FButtonWidgetAsset ReturnButton;
	UPROPERTY(EditAnywhere, SaveGame)
	FButtonWidgetAsset QuitButton;
	UPROPERTY(EditAnywhere, SaveGame)
	FImageWidgetAsset BackGroundImage;

};


//***玩家面板***//
USTRUCT(BlueprintType)
struct FPlayerPanelAsset : public FWidgetBaseAsset
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere)
	FPlayerWidgetAsset LocalPlayer;
	UPROPERTY(EditAnywhere)
	FPlayerWidgetAsset LeftPlayer;
	UPROPERTY(EditAnywhere)
	FPlayerWidgetAsset RightPlayer;
	
};

//***显示设置面板**//
USTRUCT(BlueprintType)
struct FDisplaySettingsPanelAsset : public FWidgetBaseAsset
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere)
	FGameSettingsOptionWidgetAsset ScreenResolution;
	UPROPERTY(EditAnywhere)
	FGameSettingsOptionWidgetAsset FPSLimit;
	UPROPERTY(EditAnywhere)
	FGameSettingsOptionWidgetAsset Language;

};

//***音频设置面板**//
USTRUCT(BlueprintType)
struct FAudioSettingsPanelAsset : public FWidgetBaseAsset
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere)
	FGameSettingsOptionWidgetAsset BGM;
	UPROPERTY(EditAnywhere)
	FGameSettingsOptionWidgetAsset SFX;

};


//***游戏设置面板**//
USTRUCT(BlueprintType)
struct FGameSettingsPanelAsset : public FWidgetBaseAsset
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere)
	FDisplaySettingsPanelAsset Display;
	UPROPERTY(EditAnywhere)
	FAudioSettingsPanelAsset Audio;
	UPROPERTY(EditAnywhere)
	FButtonWidgetAsset ReturnButton;
	UPROPERTY(EditAnywhere)
	FButtonWidgetAsset ResetButton;
	UPROPERTY(EditAnywhere)
	FButtonWidgetAsset AudioButton;
	UPROPERTY(EditAnywhere)
	FButtonWidgetAsset DisplayButton;
	UPROPERTY(EditAnywhere)
	FButtonWidgetAsset OperationButton;
	UPROPERTY(EditAnywhere)
	FImageWidgetAsset BackGroundImage;


};


//***游戏会话面板**//
USTRUCT(BlueprintType)
struct FGameSessionPanelAsset : public FWidgetBaseAsset
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere)
	FButtonWidgetAsset CreateButton;
	UPROPERTY(EditAnywhere)
	FButtonWidgetAsset SearchButton;
	UPROPERTY(EditAnywhere)
	FEditableTextBoxWidgetAsset EditableTextBox;
	UPROPERTY(EditAnywhere)
	FImageWidgetAsset BackGroundImage;


};


//***游戏大厅面板**//
USTRUCT(BlueprintType)
struct FGameLobbyPanelAsset : public FWidgetBaseAsset
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere)
	FButtonWidgetAsset QuitButton;
	UPROPERTY(EditAnywhere)
	FButtonWidgetAsset StartFightingButton;
	UPROPERTY(EditAnywhere)
	FTextBlockWidgetAsset TextBlock;


};

//***资源面板**//
USTRUCT(BlueprintType)
struct FResourcePanelAsset : public FWidgetBaseAsset
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere)
	FTextBlockWidgetAsset BeanTextBlock;
	UPROPERTY(EditAnywhere)
	FImageWidgetAsset BeanIcon;


};


//***警告面板**//
USTRUCT(BlueprintType)
struct FWarningPanelAsset : public FWidgetBaseAsset
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere)
	FButtonWidgetAsset ConfirmButton;
	UPROPERTY(EditAnywhere, SaveGame)
	FButtonWidgetAsset CancelButton;
	UPROPERTY(EditAnywhere)
	FImageWidgetAsset BackGroundImage;


};


//***开始菜单**//
USTRUCT(BlueprintType)
struct FStartMenuAsset : public FWidgetBaseAsset
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere)
	TObjectPtr<UTexture2D> GameTitleImage;

	UPROPERTY(EditAnywhere)
	FButtonWidgetAsset StartGameButton;


};


//***游戏主页**//
USTRUCT(BlueprintType)
struct FGameMainPageAsset : public FWidgetBaseAsset
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere)
	FButtonWidgetAsset SettingsButton;
	UPROPERTY(EditAnywhere)
	FButtonWidgetAsset SessionButton;
	UPROPERTY(EditAnywhere)
	FButtonWidgetAsset QuitGameButton;

};



//***背景控件**//
USTRUCT(BlueprintType)
struct FBackGroundWidgetAsset : public FWidgetBaseAsset
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere)
	TMap<FName, UTexture2D*> BackGroundImageMap;




};

//***HUD控件**//
USTRUCT(BlueprintType)
struct FHUDWidgetAsset : public FWidgetBaseAsset
{
	GENERATED_BODY()
	

};

//***用户提示控件**//
USTRUCT(BlueprintType)
struct FUserTipWidgetAsset : public FWidgetBaseAsset
{
	GENERATED_BODY()
	

};


//***控件资产**//
USTRUCT(BlueprintType)
struct FWidgetAsset
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere)
	TMap<FString, UClass*> WidgetClassMap;
	UPROPERTY(EditAnywhere)
	FBackGroundWidgetAsset BackGroundWidget;
	UPROPERTY(EditAnywhere)
	FUserTipWidgetAsset UserTipWidget;
	UPROPERTY(EditAnywhere)
	FStartMenuAsset StartMenu;
	UPROPERTY(EditAnywhere)
	FGameMainPageAsset GameMainPage;
	UPROPERTY(EditAnywhere)
	FGameSettingsPanelAsset GameSettingsPanel;
	UPROPERTY(EditAnywhere)
	FGameSessionPanelAsset GameSessionPanel;
	UPROPERTY(EditAnywhere)
	FGameLobbyPanelAsset GameLobbyPanel;
	UPROPERTY(EditAnywhere)
	FWarningPanelAsset WarningPanel;
	UPROPERTY(EditAnywhere)
	FResourcePanelAsset ResourcePanel;
	UPROPERTY(EditAnywhere)
	FSessionWidgetAsset SessionWidget;
	UPROPERTY(EditAnywhere)
	FPlayerPanelAsset PlayerPanel;
	UPROPERTY(EditAnywhere)
	FOperationPanelAsset OperationPanel;
	UPROPERTY(EditAnywhere)
	FHoleCardPanelAsset HoleCardPanel;
	UPROPERTY(EditAnywhere)
	FResultPanelAsset ResultPanel;
	UPROPERTY(EditAnywhere)
	FMessagePanelAsset MessagePanel;
	UPROPERTY(EditAnywhere)
	TObjectPtr<UObject> Font;
	
};






