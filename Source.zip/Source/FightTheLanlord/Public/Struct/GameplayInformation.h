﻿#pragma once

#include "CoreMinimal.h"
#include "GameplayInformation.generated.h"


USTRUCT(BlueprintType)
struct FGameplayInformation 
{
    GENERATED_BODY()
    UPROPERTY(EditAnywhere, SaveGame)
    int32 PlayerNumber = 3;
    UPROPERTY(EditAnywhere, SaveGame)
    int32 TurnDuration = 30;
    UPROPERTY(EditAnywhere, SaveGame)
    int32 MaxTurnNumber = 30;
    UPROPERTY(EditAnywhere, SaveGame)
    int32 AFKLimit = 3;
    UPROPERTY(EditAnywhere, SaveGame)
    int32 PlayerCardNumber = 17;
    UPROPERTY(EditAnywhere, SaveGame)
    int32 HoleCardNumber = 3;
};
