﻿#pragma once

#include "Struct/GameProperty.h"

#include "CoreMinimal.h"
#include "GameSettingsData.generated.h"


//***音频设置数据*****///
USTRUCT(BlueprintType)
struct FAudioSettingsData
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, SaveGame)
	FGameProperty BGMVolume = FGameProperty(5.0f,0.0f,10.0f);
	UPROPERTY(EditAnywhere, SaveGame)
	FGameProperty SFXVolume = FGameProperty(5.0f, 0.0f, 10.0f);


};

//***显示设置数据*****///
USTRUCT(BlueprintType)
struct FDisplaySettingsData
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere, SaveGame)
	FIntPoint ScreenResolution = FIntPoint(1280, 720);
	UPROPERTY(EditAnywhere, SaveGame)
	TEnumAsByte<EWindowMode::Type> WindowMode = EWindowMode::Windowed;

};

//***操作设置数据*****///
USTRUCT(BlueprintType)
struct FOperationSettingsData
{
	GENERATED_BODY()



};

//***游戏设置数据*****///
USTRUCT(BlueprintType)
struct FGameSettingsData
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere, SaveGame)
	FAudioSettingsData Audio;
	UPROPERTY(EditAnywhere, SaveGame)
	FDisplaySettingsData Display;
	UPROPERTY(EditAnywhere, SaveGame)
	FOperationSettingsData Operation;


};


