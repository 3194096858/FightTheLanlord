﻿#pragma once


#include "CoreMinimal.h"
#include "LevelSwitchSettingsData.generated.h"


USTRUCT(BlueprintType)
struct FLevelSwitchSettingsData
{
	GENERATED_BODY()
	UPROPERTY()
	bool IsServer = false;
	UPROPERTY()
	bool IsSwitchByIP = false;
	UPROPERTY()
	FString LevelName = TEXT("None");
	UPROPERTY()
	FString HostIP = TEXT("None");
	
	FLevelSwitchSettingsData() :IsServer(false),IsSwitchByIP(false),LevelName(TEXT("None")),HostIP(TEXT("None"))
	{
	};




};