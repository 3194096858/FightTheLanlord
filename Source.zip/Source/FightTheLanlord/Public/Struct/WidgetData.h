﻿#pragma once

#include "Struct/GameProperty.h"

#include "Enum/GameSettingsOptionType.h"

#include "Components/CanvasPanelSlot.h"

#include "CoreMinimal.h"
#include "WidgetData.generated.h"


//***控件基类****//
USTRUCT(BlueprintType)
struct FWidgetBaseData
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, SaveGame)
	FVector2D Size = FVector2D::ZeroVector;
	UPROPERTY(EditAnywhere, SaveGame)
	FVector2D RelativePosition = FVector2D::ZeroVector;


};


//***图像控件***//
USTRUCT(BlueprintType)
struct FImageWidgetData : public FWidgetBaseData
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, SaveGame)
	FColor Color = FColor::White;
	UPROPERTY(EditAnywhere, SaveGame)
	bool IsShowImage = true;



};

//***文本框控件***//
USTRUCT(BlueprintType)
struct FTextBlockWidgetData : public FWidgetBaseData
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere, SaveGame)
	FText Text = FText::FromString("DefaultText");
	UPROPERTY(EditAnywhere, SaveGame)
	int32 FontSize = 32;
	UPROPERTY(EditAnywhere, SaveGame)
	FColor FontColor = FColor::White;
	UPROPERTY(EditAnywhere, SaveGame)
	bool IsShowText = true;
	UPROPERTY(EditAnywhere, SaveGame)
	FVector2D TextRelativePosition = FVector2D::ZeroVector;
	UPROPERTY(EditAnywhere, SaveGame)
	FImageWidgetData BackGroundImage;

};

//***按钮控件**//
USTRUCT(BlueprintType)
struct FButtonWidgetData : public FWidgetBaseData
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere, SaveGame)
	FTextBlockWidgetData TextBlock;
	UPROPERTY(EditAnywhere, SaveGame)
	FImageWidgetData Icon;
	UPROPERTY(EditAnywhere, SaveGame)
	FImageWidgetData BackGroundImage;


};

//***勾选框控件**//
USTRUCT(BlueprintType)
struct FCheckBoxWidgetData : public FWidgetBaseData
{
	GENERATED_BODY()

};


//***组合框控件**//
USTRUCT(BlueprintType)
struct FComboBoxWidgetData : public FWidgetBaseData
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere, SaveGame)
	FButtonWidgetData Button;
	UPROPERTY(EditAnywhere, SaveGame)
	FImageWidgetData Menu;
	UPROPERTY(EditAnywhere, SaveGame)
	FButtonWidgetData ItemButton;
	UPROPERTY(EditAnywhere, SaveGame)
	FMargin ItemPadding;
	UPROPERTY(EditAnywhere, SaveGame)
	float MenuAnimationPlayRate = 1.0f;


};


//***可编辑文本框控件**//
USTRUCT(BlueprintType)
struct FEditableTextBoxWidgetData : public FWidgetBaseData
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere, SaveGame)
	FImageWidgetData BackGroundImage;
	UPROPERTY(EditAnywhere, SaveGame)
	FTextBlockWidgetData TextBlock;
	UPROPERTY(EditAnywhere, SaveGame)
	FText HintText;


};

//***会话控件**//
USTRUCT(BlueprintType)
struct FSessionWidgetData : public FWidgetBaseData
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere, SaveGame)
	FButtonWidgetData JoinButton;
	UPROPERTY(EditAnywhere, SaveGame)
	FButtonWidgetData DeleteButton;
	UPROPERTY(EditAnywhere, SaveGame)
	FImageWidgetData Icon;
	UPROPERTY(EditAnywhere, SaveGame)
	FTextBlockWidgetData NameTextBlock;
	UPROPERTY(EditAnywhere, SaveGame)
	FImageWidgetData BackGroundImage;




};

//***滑条控件**//
USTRUCT(BlueprintType)
struct FSliderWidgetData : public FWidgetBaseData
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere, SaveGame)
	FImageWidgetData BackGroundImage;
	UPROPERTY(EditAnywhere, SaveGame)
	FTextBlockWidgetData TextBlock;
	UPROPERTY(EditAnywhere, SaveGame)
	FImageWidgetData BarImage;
	UPROPERTY(EditAnywhere, SaveGame)
	FImageWidgetData HandleImage;
	UPROPERTY(EditAnywhere, SaveGame)
	float BarThickness = 1.0f;
	UPROPERTY(EditAnywhere, SaveGame)
	float StepSize = 1.0f;



};

//***消息控件***//
USTRUCT(BlueprintType)
struct FMessageWidgetData : public FWidgetBaseData
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere, SaveGame)
	FTextBlockWidgetData TextBlock;




};

//***消息面板***//
USTRUCT(BlueprintType)
struct FMessagePanelData : public FWidgetBaseData
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere, SaveGame)
	FEditableTextBoxWidgetData EditableTextBox;
	UPROPERTY(EditAnywhere, SaveGame)
	FImageWidgetData BackGroundImage;
	UPROPERTY(EditAnywhere, SaveGame)
	FButtonWidgetData SendingButton;
};

//***玩家控件***//
USTRUCT(BlueprintType)
struct FPlayerWidgetData : public FWidgetBaseData
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere, SaveGame)
	FTextBlockWidgetData NameTextBlock;
	UPROPERTY(EditAnywhere, SaveGame)
	FTextBlockWidgetData CardNumberTextBlock;


};


//***手牌控件***//
USTRUCT(BlueprintType)
struct FCardHandWidgetData : public FWidgetBaseData
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere, SaveGame)
	FVector2D CardSize = FVector2D::ZeroVector;

};
//***倒计时定时器控件***//
USTRUCT(BlueprintType)
struct FCountdownTimerWidgetData : public FWidgetBaseData
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere, SaveGame)
	FTextBlockWidgetData TextBlock;
	

};

//***牌桌控件***//
USTRUCT(BlueprintType)
struct FCardTableWidgetData : public FWidgetBaseData
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere, SaveGame)
	FVector2D CardSize = FVector2D::ZeroVector;


};

//***玩家面板***//
USTRUCT(BlueprintType)
struct FPlayerPanelData : public FWidgetBaseData
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere, SaveGame)
	FPlayerWidgetData LocalPlayer;
    UPROPERTY(EditAnywhere, SaveGame)
	FPlayerWidgetData LeftPlayer;
	UPROPERTY(EditAnywhere, SaveGame)
	FPlayerWidgetData RightPlayer;
};

//***操作面板***//
USTRUCT(BlueprintType)
struct FOperationPanelData : public FWidgetBaseData
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere, SaveGame)
	FButtonWidgetData PlayCardButton;
	UPROPERTY(EditAnywhere, SaveGame)
	FButtonWidgetData PassButton;
	UPROPERTY(EditAnywhere, SaveGame)
	FButtonWidgetData MessageButton;
	UPROPERTY(EditAnywhere, SaveGame)
	FCountdownTimerWidgetData CountdownTimer;
	UPROPERTY(EditAnywhere, SaveGame)
	FCardHandWidgetData CardHand;
};

//***开始菜单***//
USTRUCT(BlueprintType)
struct FStartMenuData : public FWidgetBaseData
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere, SaveGame)
	FColor GameTitleImageColor = FColor::White;
	UPROPERTY(EditAnywhere, SaveGame)
	FButtonWidgetData StartGameButton;


};

//***底牌面板***//
USTRUCT(BlueprintType)
struct FHoleCardPanelData : public FWidgetBaseData
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere, SaveGame)
	FImageWidgetData BackGroundImage;
	UPROPERTY(EditAnywhere, SaveGame)
	FVector2D CardSize = FVector2D::ZeroVector;

};

//***结算面板***//
USTRUCT(BlueprintType)
struct FResultPanelData : public FWidgetBaseData
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere, SaveGame)
	FTextBlockWidgetData GameOverTextBlock;
	UPROPERTY(EditAnywhere, SaveGame)
	FTextBlockWidgetData GameResultTextBlock;
	UPROPERTY(EditAnywhere, SaveGame)
	FButtonWidgetData ReturnButton;
	UPROPERTY(EditAnywhere, SaveGame)
	FButtonWidgetData QuitButton;
	UPROPERTY(EditAnywhere, SaveGame)
	FImageWidgetData BackGroundImage;

};

//***资源面板***//
USTRUCT(BlueprintType)
struct FResourcePanelData : public FWidgetBaseData
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, SaveGame)
	FTextBlockWidgetData BeanTextBlock;
	UPROPERTY(EditAnywhere, SaveGame)
	FImageWidgetData BeanIcon;

};


//***警告面板***//
USTRUCT(BlueprintType)
struct FWarningPanelData : public FWidgetBaseData
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere, SaveGame)
	FTextBlockWidgetData TextBlock;
	UPROPERTY(EditAnywhere, SaveGame)
	FButtonWidgetData ConfirmButton;
	UPROPERTY(EditAnywhere, SaveGame)
	FButtonWidgetData CancelButton;
	UPROPERTY(EditAnywhere, SaveGame)
	FImageWidgetData BackGroundImage;

};



//***游戏会话面板**//
USTRUCT(BlueprintType)
struct FGameSessionPanelData : public FWidgetBaseData
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere, SaveGame)
	FButtonWidgetData CreateButton;
	UPROPERTY(EditAnywhere, SaveGame)
	FButtonWidgetData SearchButton;
	UPROPERTY(EditAnywhere, SaveGame)
	FEditableTextBoxWidgetData EditableTextBox;
	UPROPERTY(EditAnywhere, SaveGame)
	FImageWidgetData BackGroundImage;
	UPROPERTY(EditAnywhere, SaveGame)
	FMargin SessionPadding = FMargin(0.0f);

};

//***游戏大厅面板**//
USTRUCT(BlueprintType)
struct FGameLobbyPanelData : public FWidgetBaseData
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere, SaveGame)
	FButtonWidgetData QuitButton;
	UPROPERTY(EditAnywhere, SaveGame)
	FButtonWidgetData StartFightingButton;
	UPROPERTY(EditAnywhere, SaveGame)
	FTextBlockWidgetData TextBlock;

};


//***游戏设置选项控件**//
USTRUCT(BlueprintType)
struct FGameSettingsOptionWidgetData : public FWidgetBaseData
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere, SaveGame)
	FTextBlockWidgetData TextBlock;
	UPROPERTY(EditAnywhere, SaveGame)
	FImageWidgetData BackGroundImage;
	UPROPERTY(EditAnywhere, SaveGame)
	EGameSettingsOptionType OptionType;
	UPROPERTY(EditAnywhere, SaveGame)
	FCheckBoxWidgetData CheckBox;
	UPROPERTY(EditAnywhere, SaveGame)
	FComboBoxWidgetData ComboBox;
	UPROPERTY(EditAnywhere, SaveGame)
	FSliderWidgetData Slider;


};

//***音频设置面板***//
USTRUCT(BlueprintType)
struct FAudioSettingsPanelData : public FWidgetBaseData
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere, SaveGame)
	FGameSettingsOptionWidgetData BGM;
	UPROPERTY(EditAnywhere, SaveGame)
	FGameSettingsOptionWidgetData SFX;


};

//***显示设置面板***//
USTRUCT(BlueprintType)
struct FDisplaySettingsPanelData : public FWidgetBaseData
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere, SaveGame)
	FGameSettingsOptionWidgetData ScreenResolution;
	UPROPERTY(EditAnywhere, SaveGame)
	FGameSettingsOptionWidgetData FPSLimit;
	UPROPERTY(EditAnywhere, SaveGame)
	FGameSettingsOptionWidgetData Language;



};

//***操作设置面板***//
USTRUCT(BlueprintType)
struct FOperationSettingsPanelData : public FWidgetBaseData
{
	GENERATED_BODY()

};

//***游戏设置面板***//
USTRUCT(BlueprintType)
struct FGameSettingsPanelData : public FWidgetBaseData
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere, SaveGame)
	FAudioSettingsPanelData  Audio;
	UPROPERTY(EditAnywhere, SaveGame)
	FOperationSettingsPanelData Operation;
	UPROPERTY(EditAnywhere, SaveGame)
	FDisplaySettingsPanelData Display;
	UPROPERTY(EditAnywhere, SaveGame)
	FButtonWidgetData ReturnButton;
	UPROPERTY(EditAnywhere, SaveGame)
	FButtonWidgetData ResetButton;
	UPROPERTY(EditAnywhere, SaveGame)
	FButtonWidgetData AudioButton;
	UPROPERTY(EditAnywhere, SaveGame)
	FButtonWidgetData DisplayButton;
	UPROPERTY(EditAnywhere, SaveGame)
	FButtonWidgetData OperationButton;
	UPROPERTY(EditAnywhere, SaveGame)
	FImageWidgetData BackGroundImage;

};




//***游戏主页数据****///
USTRUCT(BlueprintType)
struct FGameMainPageData : public FWidgetBaseData
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, SaveGame)
	FButtonWidgetData SettingsButton;
	UPROPERTY(EditAnywhere, SaveGame)
	FButtonWidgetData SessionButton;
	UPROPERTY(EditAnywhere, SaveGame)
	FButtonWidgetData QuitGameButton;
	
};


//***HUD控件**//
USTRUCT(BlueprintType)
struct FHUDWidgetData : public FWidgetBaseData
{
	GENERATED_BODY()


};

//***用户提示控件**//
USTRUCT(BlueprintType)
struct FUserTipWidgetData : public FWidgetBaseData
{
	GENERATED_BODY()
	

};


//***控件数据****///
USTRUCT(BlueprintType)
struct FWidgetData
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere, SaveGame)
	FUserTipWidgetData UserTipWidget;
	UPROPERTY(EditAnywhere, SaveGame)
	FStartMenuData StartMenu;
	UPROPERTY(EditAnywhere, SaveGame)
	FGameMainPageData GameMainPage;
	UPROPERTY(EditAnywhere, SaveGame)
	FGameSettingsPanelData GameSettingsPanel;
	UPROPERTY(EditAnywhere, SaveGame)
	FWarningPanelData WarningPanel;
	UPROPERTY(EditAnywhere, SaveGame)
	FResourcePanelData ResourcePanel;
	UPROPERTY(EditAnywhere, SaveGame)
	FGameSessionPanelData GameSessionPanel;
	UPROPERTY(EditAnywhere, SaveGame)
	FSessionWidgetData SessionWidget;
	UPROPERTY(EditAnywhere, SaveGame)
	FGameLobbyPanelData GameLobbyPanel;
	UPROPERTY(EditAnywhere, SaveGame)
	FPlayerPanelData PlayerPanel;
	UPROPERTY(EditAnywhere, SaveGame)
	FOperationPanelData OperationPanel;
	UPROPERTY(EditAnywhere, SaveGame)
	FCardTableWidgetData CardTableWidget;
	UPROPERTY(EditAnywhere, SaveGame)
	FResultPanelData ResultPanel;
	UPROPERTY(EditAnywhere, SaveGame)
	FHoleCardPanelData HoleCardPanel;
	UPROPERTY(EditAnywhere, SaveGame)
	FMessageWidgetData MessageWidget;
	UPROPERTY(EditAnywhere, SaveGame)
	FMessagePanelData MessagePanel;
	UPROPERTY(EditAnywhere, SaveGame)
	FAnchorData AnchorData = FAnchorData(0.5f);
	UPROPERTY(EditAnywhere, SaveGame)
	float ButtonAnimationPlayRate = 1.0f;
	UPROPERTY(EditAnywhere, SaveGame)
	float ComboBoxAnimationPlayRate = 1.0f;
	UPROPERTY(EditAnywhere, SaveGame)
	float CheckBoxAnimationPlayRate = 1.0f;
	UPROPERTY(EditAnywhere, SaveGame)
	float StartMenuAnimationPlayRate = 1.0f;
	UPROPERTY(EditAnywhere, SaveGame)
	float GameMainPageAnimationPlayRate = 1.0f;
	UPROPERTY(EditAnywhere, SaveGame)
	float GameSettingsPanelAnimationPlayRate = 1.0f;
	UPROPERTY(EditAnywhere, SaveGame)
	float ResourcePanelAnimationPlayRate = 1.0f;
	UPROPERTY(EditAnywhere, SaveGame)
	float WarningPanelAnimationPlayRate = 1.0f;
	UPROPERTY(EditAnywhere, SaveGame)
	float GameSessionPanelAnimationPlayRate = 1.0f;
	UPROPERTY(EditAnywhere, SaveGame)
	float GameLobbyPanelAnimationPlayRate = 1.0f;
	UPROPERTY(EditAnywhere, SaveGame)
	float PlayerPanelAnimationPlayRate = 1.0f;
	UPROPERTY(EditAnywhere, SaveGame)
	float OperationPanelAnimationPlayRate = 1.0f;
	UPROPERTY(EditAnywhere, SaveGame)
	float HoleCardPanelAnimationPlayRate = 1.0f;
	UPROPERTY(EditAnywhere, SaveGame)
	float MessagePanelAnimationPlayRate = 1.0f;
};





