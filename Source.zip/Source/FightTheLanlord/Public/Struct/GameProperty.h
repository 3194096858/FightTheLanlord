﻿#pragma once


#include "CoreMinimal.h"
#include "GameProperty.generated.h"



USTRUCT(BlueprintType)
struct FGameProperty
{
	GENERATED_BODY()
private:
	UPROPERTY(EditAnywhere,SaveGame)
	float Current = 0.0f;
	UPROPERTY(EditAnywhere, SaveGame)
	float Min = 0.0f;
	UPROPERTY(EditAnywhere, SaveGame)
	float Max = 0.0f;

public:
	FGameProperty() : Current(0.0f), Min(0.0f), Max(1.0f)
	{
	};
	FGameProperty(float NewMin, float NewMax) : Min(NewMin), Max(NewMax)
	{
	};
	FGameProperty(float NewCurrent, float NewMin, float NewMax) :Current(NewCurrent), Min(NewMin), Max(NewMax)
	{
	};
	void UpdateCurrent(float Value)
	{
		if (this->Current >= this->Max || this->Current <= this->Min)
		{
			return;
		}
		this->Current += Value;
		this->Current = FMath::Clamp(this->Current, this->Min, this->Max);
	};
	void SetCurrent(float NewCurrent)
	{
		this->Current = NewCurrent;
		this->Current = FMath::Clamp(this->Current, this->Min, this->Max);
	};
	float GetCurrent()
	{
		if (this->Current > this->Max || this->Current < this->Min)
		{
			this->Current = FMath::Clamp(this->Current, this->Min, this->Max);
		}
		return this->Current;
	};
	float GetCurrentByPercent(float Percent)
	{
		return this->Max * Percent;
	};
	void SetRange(float NewMin, float NewMax)
	{
		this->Min = NewMin;
		this->Max = NewMax;
	};
	void SetMin(float NewMin)
	{
		this->Min = NewMin;
	};
	float GetMin()
	{
		return this->Min;
	}
	void SetMax(float NewMax)
	{
		this->Max = NewMax;
	};
	float GetMax()
	{
		return this->Max;
	};
	float GetPercent()
	{
		return this->Current / this->Max;
	};
	void ResetToZero()
	{
		this->Current = 0.0f;
	};
	void ResetToMin()
	{
		this->Current = this->Min;
	};
	bool GetIsEqualMin()
	{
		return this->Current == this->Min;
	};
	bool GetIsEqualMax()
	{
		return this->Current == this->Max;
	};










};



