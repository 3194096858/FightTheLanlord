﻿#pragma once

#include "Enum/CardSuit.h"


#include "CoreMinimal.h"
#include "CardInformation.generated.h"

class UTexture2D;

USTRUCT(BlueprintType)
struct FCardInformation : public FTableRowBase
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, SaveGame)
    FName Name = TEXT("");
    UPROPERTY(EditAnywhere, SaveGame)
    ECardSuit Suit = ECardSuit::None;
    UPROPERTY(EditAnywhere, SaveGame)
    int32 Value = -1;
    UPROPERTY(EditAnywhere)
    UTexture2D* Image = nullptr;

    FCardInformation():Name(TEXT("")),Suit(ECardSuit::None),Value(-1),Image(nullptr)
    {
       
    }

};
