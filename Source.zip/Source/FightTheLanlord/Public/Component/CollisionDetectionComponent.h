// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Component/ComponentBase.h"
#include "CollisionDetectionComponent.generated.h"

/**
 * 
 */
UCLASS()
class FIGHTTHELANLORD_API UCollisionDetectionComponent : public UComponentBase
{
	GENERATED_BODY()
	
};
