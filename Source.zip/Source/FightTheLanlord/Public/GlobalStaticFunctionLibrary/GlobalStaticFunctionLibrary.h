﻿
#pragma once
#include "Enum/CardSuit.h"
#include "Enum/HandType.h"

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "GlobalStaticFunctionLibrary.generated.h"




UCLASS()
class FIGHTTHELANLORD_API UGlobalStaticFunctionLibrary : public UObject
{
	GENERATED_BODY()
	
private:
	inline static TMap<FName,ECardSuit> CardSuitMap;
	inline static TMap<FName, EHandType> HandTypeMap;

public:
	
	static FName GetNameByEnum(ECardSuit Suit);
	static FName GetNameByEnum(EHandType HandType);



	
};
