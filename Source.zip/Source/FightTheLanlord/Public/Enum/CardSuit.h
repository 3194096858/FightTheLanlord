﻿#pragma once

#include "CoreMinimal.h"
#include "CardSuit.generated.h"

UENUM(BlueprintType)
enum class ECardSuit : uint8
{
	None,
	Heart,
	Spade,
	Clud,
	Diamond
};