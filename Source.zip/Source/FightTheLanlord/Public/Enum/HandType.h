﻿#pragma once


#include "CoreMinimal.h"
#include "HandType.generated.h"

UENUM(BlueprintType)
enum class EHandType : uint8
{
	None,
	Single,
	Pair,
	Triple,
	TripletWithKicker,
	SingleStraight,
	PairStraight,
	Airplane,
	AirplaneWithWing,
	FourWithTwo,
	Bomb,
    JokerBomb
};


