﻿#pragma once

#include "CoreMinimal.h"
#include "GameSettingsOptionType.generated.h"



UENUM()
enum class EGameSettingsOptionType :uint8
{
	None,
	CheckBox,
	Slider,
	ComboBox
};











