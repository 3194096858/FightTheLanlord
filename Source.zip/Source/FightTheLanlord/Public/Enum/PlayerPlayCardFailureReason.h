﻿#pragma once

#include "CoreMinimal.h"
#include "PlayerPlayCardFailureReason.generated.h"

UENUM(BlueprintType)
enum class EPlayerPlayCardFailureReason : uint8
{
	None,
	NoSelectedCard,
	NotYourTurn,
	IllegalHandType,
	SmallHandType,
	DefferentHandType
};