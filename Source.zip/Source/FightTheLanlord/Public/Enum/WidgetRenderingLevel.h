﻿#pragma once

#include "CoreMinimal.h"
#include "WidgetRenderingLevel.generated.h"



UENUM(BlueprintType)
enum class EWidgetRenderingLevel : uint8
{
    BackGround,
    HUD,
    UserTip
};
















