﻿
#pragma once

#include "Struct/CardInformation.h"
#include "Struct/GameProperty.h"

#include "CoreMinimal.h"
#include "GameFramework/PlayerState.h"
#include "FTL_PlayerStateBase.generated.h"







UCLASS()
class FIGHTTHELANLORD_API AFTL_PlayerStateBase : public APlayerState
{
	GENERATED_BODY()
public:
    AFTL_PlayerStateBase();

protected:
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps)const override;


public:

private:
	UPROPERTY()
	FGameProperty Bean = FGameProperty(0.0f,0.0f,9999.0f);
	UPROPERTY()
	TArray<FCardInformation> CardArray;
	UPROPERTY(Replicated)
	TArray<FCardInformation> SelectedCardArray;
	UPROPERTY(Replicated)
	int32 ID = -1;


public:
	UFUNCTION()
	float GetBean();

	UFUNCTION()
	int32 GetID();
	UFUNCTION()
	void SetID(int32 NewID);

	UFUNCTION()
	void SetCardHand(const TArray<FCardInformation>& NewArray);
	UFUNCTION()
	void SetAllSelectedCard(const TArray<FCardInformation>& NewArray);
	UFUNCTION()
	TArray<FCardInformation> GetAllSelectedCardFormCardHand();

};
