// Copyright Epic Games, Inc. All Rights Reserved.

#include "FightTheLanlord.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, FightTheLanlord, "FightTheLanlord" );
