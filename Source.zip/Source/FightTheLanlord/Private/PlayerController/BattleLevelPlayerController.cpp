﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "PlayerController/BattleLevelPlayerController.h"

#include "GameState/FTL_GameStateBase.h"
#include "PlayerState/FTL_PlayerStateBase.h"
#include "GameMode/BattleGameMode.h"
#include "GameInstance/FTL_GameInstance.h"
#include "Manager/WidgetManager.h"
#include "Manager/FTL_AssetManager.h"
#include "Manager/GameSettingsManager.h"
#include "Manager/DelegateManager.h"
#include "Manager/GameSessionManager.h"
#include "Manager/CardLibrary.h"
#include "Widget/CardWidget.h"
#include "Kismet/GameplayStatics.h"
#include "GlobalStaticFunctionLibrary/GlobalStaticFunctionLibrary.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Manager/AudioManager.h"
#include "Widget/MessageWidget.h"

#include "Manager/FTL_TimerManager.h"

ABattleLevelPlayerController::ABattleLevelPlayerController()
{

}


void ABattleLevelPlayerController::BeginPlay()
{
	Super::BeginPlay();


}


void ABattleLevelPlayerController::EndPlay(EEndPlayReason::Type EndPlayResason)
{
	Super::EndPlay(EndPlayResason);


}


void ABattleLevelPlayerController::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}


void ABattleLevelPlayerController::Client_BeginPlay_Implementation()
{
	Super::Client_BeginPlay_Implementation();
	FString CurrentLevel = UGameplayStatics::GetCurrentLevelName(this);
	GetGameInstance()->GetDelegateManager()->OnLocalClientPlayerControllerCompleteInitialize.Broadcast();
	GetGameInstance()->GetDelegateManager()->OnLocalClientSwitchLevelComplete.Broadcast(CurrentLevel);
	GetGameInstance()->GetDelegateManager()->OnDealCardComplete.AddUObject(this, &ABattleLevelPlayerController::OnDealCardComplete);
	GetGameInstance()->GetAudioManager()->PlayBGM(TEXT("Battle"));

	


}

void ABattleLevelPlayerController::Client_EndPlay_Implementation()
{
	Super::Client_EndPlay_Implementation();



}



void ABattleLevelPlayerController::Client_SendMessage_Implementation(int32 PlayerID,const FString& Message)
{
	UMessageWidget* Widget = GetGameInstance()->GetWidgetManager()->GetMessageWidget(GetGameInstance());

	GetGameInstance()->GetWidgetManager()->AddMessage(Widget,PlayerID,Message);

}


void ABattleLevelPlayerController::Server_SendMessage_Implementation(int32 PlayerID,const FString& Message)
{
	ABattleGameMode* GameMode = Cast<ABattleGameMode>(UGameplayStatics::GetGameMode(this));
	GameMode->OnPlayerSendMessage(PlayerID,Message);


}



void ABattleLevelPlayerController::Client_UpdatePlayerCardNumber_Implementation(int32 PlayerID, int32 NewValue)
{
	GetGameInstance()->GetWidgetManager()->UpdatePlayerCardNumber(PlayerID,NewValue);


}


void ABattleLevelPlayerController::Client_AddCardToPlayerCardHand_Implementation(const TArray<FCardInformation>& CardArray)
{
	UCardWidget* Widget = nullptr;
	UTexture2D* Image = nullptr;
	for (auto& Element : CardArray)
	{
		Widget = GetGameInstance()->GetWidgetManager()->GetCardWidget(GetGameInstance());
		if (Widget!=nullptr)
		{

			Image = GetGameInstance()->GetAssetManager()->GetCardImage(Element.Name,Element.Suit);
			Widget->SetImage(Image);
			GetGameInstance()->GetWidgetManager()->AddCardToCardHand(Element, Widget);
			
		}
		
		
	}

	/*for (auto& Element : CardArray)
	{
		FName Name = UGlobalStaticFunctionLibrary::GetNameByEnum(Element.Suit);
		UE_LOG(LogTemp, Warning, TEXT("PlayerController11111111: CardName = %s, CardSuit = %s  "), *Element.Name.ToString(), *Name.ToString());

	}
	for (auto& Element : GetGameInstance()->GetWidgetManager()->GetAllActiveCardInformation())
	{
		FName Name = UGlobalStaticFunctionLibrary::GetNameByEnum(Element.Suit);
		UE_LOG(LogTemp, Warning, TEXT("PlayerController22222222222222:  CardName = %s, CardSuit = %s  "), *Element.Name.ToString(), *Name.ToString());

	}*/
}

void ABattleLevelPlayerController::Client_PlayCard_Implementation()
{
	AFTL_PlayerStateBase* State = Cast<AFTL_PlayerStateBase>(this->PlayerState);
	TArray<FCardInformation> Array = State->GetAllSelectedCardFormCardHand();
	Server_PlayCard(GetPlayerID(),Array);


}


void ABattleLevelPlayerController::Server_PlayCard_Implementation(int32 PlayerID, const TArray<FCardInformation>& CardArray)
{
	ABattleGameMode* GameMode= Cast<ABattleGameMode>(UGameplayStatics::GetGameMode(this));
	GameMode->OnPlayerPlayCard(PlayerID,CardArray);
	


}

void ABattleLevelPlayerController::Client_Pass_Implementation()
{
	Server_Pass(GetPlayerID());

}

void ABattleLevelPlayerController::Server_Pass_Implementation(int32 PlayerID)
{
	ABattleGameMode* GameMode = Cast<ABattleGameMode>(UGameplayStatics::GetGameMode(this));
	if (GameMode == nullptr)
	{
		return;
	}
	GameMode->OnPlayerPass(PlayerID);



}


void ABattleLevelPlayerController::Client_InitializeHoleCard_Implementation(const TArray<FCardInformation>& CardArray)
{
	GetGameInstance()->GetWidgetManager()->AddCardToHoleCardPanel(CardArray);
	GetGameInstance()->GetDelegateManager()->OnHoleCardPanelOpen.Broadcast();

	
}

void ABattleLevelPlayerController::Client_AddClientGUIDToServer_Implementation()
{
	//Server_AddClientGUIDToServer(GetPlayerID(),GetGameInstance()->ClientGUID);
}

void ABattleLevelPlayerController::Server_AddClientGUIDToServer_Implementation(int32 PlayerID, const FString& GUID)
{
	//ABattleGameMode* GameMode = Cast<ABattleGameMode>(UGameplayStatics::GetGameMode(this));
	//if (GameMode == nullptr)
	//{
	//	return;
	//}
	//bool IsExist = GameMode->CheckClientGUIDIsExist(GUID);
	//////Client_OnServerCheckClientGUIDComplete(IsExist);
	//IsExist == false ? GameMode->AddClientGUID(PlayerID, GUID) : void();


}



void ABattleLevelPlayerController::Client_CheckClientGUIDIsExistInServer_Implementation()
{
///	Server_CheckClientGUIDIsExistInServer(GetGameInstance()->ClientGUID);
}

void ABattleLevelPlayerController::Server_CheckClientGUIDIsExistInServer_Implementation(const FString& GUID)
{
	/*ABattleGameMode* GameMode = Cast<ABattleGameMode>(UGameplayStatics::GetGameMode(this));
	if (GameMode == nullptr)
	{
		return;
	}
	bool IsExist = GameMode->CheckClientGUIDIsExist(GUID);*/

}

void ABattleLevelPlayerController::Client_OnPlayerPlayCardSucceed_Implementation(int32 PlayerID,const TArray<FCardInformation>& CardArray)
{
	GetGameInstance()->GetWidgetManager()->ClearCardTable();
	GetGameInstance()->GetWidgetManager()->AddCardToCardTable(CardArray);
	Server_PlaySFX(CardArray);
	if (GetPlayerID() == PlayerID)
	{
		for (auto& Element : GetGameInstance()->GetWidgetManager()->GetAllSelectedCardWidgetFromCardHand())
		{
			GetGameInstance()->GetWidgetManager()->RemoveCardFromCardHand(Element);
		}
		GetGameInstance()->GetDelegateManager()->OnLocalPlayerPlayCardSucceed.Broadcast();
		
	}
	////GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, FString::Printf(TEXT(" Play Card Succeed:  Card Number= %d  !!!!!"), GetGameInstance()->GetWidgetManager()->GetAllActiveCardInformation().Num()));

}

void ABattleLevelPlayerController::Client_OnPlayCardFailed_Implementation(const EPlayerPlayCardFailureReason& FailureReason)
{
	switch (FailureReason)
	{
		case EPlayerPlayCardFailureReason::IllegalHandType:
			GEngine->AddOnScreenDebugMessage(-1,11.0f,FColor::Blue,FString::Printf(TEXT("PlayCardFailed: PlayerID= %d , Reason =  IllegalHandType !!!!!"),GetPlayerID()));

			break;
		case EPlayerPlayCardFailureReason::NoSelectedCard:
			GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, FString::Printf(TEXT("PlayCardFailed: PlayerID= %d , Reason =  NoSelectedCard !!!!!"), GetPlayerID()));

			break;
		case EPlayerPlayCardFailureReason::NotYourTurn:
			GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, FString::Printf(TEXT("PlayCardFailed: PlayerID= %d , Reason =  NotYourTurn !!!!!"), GetPlayerID()));

			break;
		case EPlayerPlayCardFailureReason::SmallHandType:
			GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, FString::Printf(TEXT("PlayCardFailed: PlayerID= %d , Reason =  SmallHandType !!!!!"), GetPlayerID()));

			break;
		case EPlayerPlayCardFailureReason::DefferentHandType:
			GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, FString::Printf(TEXT("PlayCardFailed: PlayerID= %d , Reason =  DefferentHandType !!!!!"), GetPlayerID()));
			break;
	}

}

void ABattleLevelPlayerController::Client_OnPlayerPass_Implementation(int32 PlayerID)
{
	USoundBase* ClickSFX = GetGameInstance()->GetAssetManager()->GetSFX(TEXT("PassButtonClick"));
	if (ClickSFX != nullptr)
	{
		GetGameInstance()->GetAudioManager()->PlaySFX(ClickSFX);
	}

}
void ABattleLevelPlayerController::Server_PlaySFX_Implementation(const TArray<FCardInformation>& CardArray)
{
	ABattleGameMode* GameMode = Cast<ABattleGameMode>(UGameplayStatics::GetGameMode(this));
	if (GameMode ==nullptr)
	{
		return;
	}
	EHandType HandType = GameMode->CheckIsLegalHandType(CardArray);
	int32 Value = GameMode->GetHandTypeValue(CardArray);
	Client_PlaySFX(HandType,Value);

}

void ABattleLevelPlayerController::Client_PlaySFX_Implementation(EHandType HandType, int32 Value)
{
	USoundBase* SFX = GetGameInstance()->GetAssetManager()->GetHandTypeSFX(HandType,Value);
	GetGameInstance()->GetAudioManager()->PlaySFX(SFX);
}



void ABattleLevelPlayerController::Client_SetCountdownTimerText_Implementation(int32 CurrentSecond)
{
	GetGameInstance()->GetWidgetManager()->SetCountdownTimerText(CurrentSecond);

}

int32 ABattleLevelPlayerController::GetPlayerID()
{
	AFTL_PlayerStateBase* State =Cast<AFTL_PlayerStateBase>(this->PlayerState);
	if (State!=nullptr)
	{
		return State->GetID();
	}
	return -1;
}


void ABattleLevelPlayerController::OnRep_PlayerState()
{
	Super::OnRep_PlayerState();
	
	GetGameInstance()->GetDelegateManager()->OnLocalClientPlayerStateCompleteInitialize.Broadcast();


}


void ABattleLevelPlayerController::Client_OnTurnStart_Implementation(int32 PlayerID)
{
	GetGameInstance()->GetWidgetManager()->ShowCountdownTimer();

}


void ABattleLevelPlayerController::Client_OnTurnEnd_Implementation(int32 PlayerID)
{
	GetGameInstance()->GetWidgetManager()->HideCountdownTimer();



}

void ABattleLevelPlayerController::Server_OnDealCardComplete_Implementation(int32 PlayerID)
{
	ABattleGameMode* GameMode = Cast<ABattleGameMode>(UGameplayStatics::GetGameMode(this));
	GameMode->OnDealCardComplete(PlayerID);


}

void ABattleLevelPlayerController::OnDealCardComplete()
{
	Server_OnDealCardComplete(GetPlayerID());
}

void ABattleLevelPlayerController::Client_OnGameOver_Implementation(int32 LanlordPlayerID, int32 WinnerPlayerID)
{
	bool IsLanlordWin = LanlordPlayerID == WinnerPlayerID ? true : false;
	USoundBase* GameWinSFX = GetGameInstance()->GetAssetManager()->GetSFX(TEXT("GameWin"));
	USoundBase* GameFailureSFX = GetGameInstance()->GetAssetManager()->GetSFX(TEXT("GameFailure"));
	GetGameInstance()->GetAudioManager()->PauseAllBGM();
	if (GameWinSFX == nullptr || GameFailureSFX == nullptr)
	{
		return;
	}
	if (GetPlayerID() == WinnerPlayerID)
	{
		GetGameInstance()->GetAudioManager()->PlaySFX(GameWinSFX);
	}
	else
	{
		GetGameInstance()->GetAudioManager()->PlaySFX(GameFailureSFX);
	}
	GetGameInstance()->GetDelegateManager()->OnGameOver.Broadcast(IsLanlordWin);
}

void ABattleLevelPlayerController::Client_OnServerCheckClientGUIDComplete_Implementation(bool IsExist)
{
	//FString CurrentLevel = UGameplayStatics::GetCurrentLevelName(this);
	//if (IsExist == true)
	//{
	//	Client_QuitSession();
	//	GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, FString::Printf(TEXT(" ClientGUID Is Exist !!!!!")));

	//	/*FTimerHandle TimerHandle;
	//	auto Lambda = [this,CurrentLevel]()
	//		{
	//			Client_QuitSession();
	//			GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, FString::Printf(TEXT(" ClientGUID Is Exist，  CurrentLevel = %s !!!!!"), *CurrentLevel));

	//		};
	//	GetWorld()->GetTimerManager().SetTimer(TimerHandle,Lambda,3.0f,false);*/
	//}
	//else
	//{
	//	GetGameInstance()->GetDelegateManager()->OnLocalClientPlayerControllerCompleteInitialize.Broadcast();
	//	GetGameInstance()->GetDelegateManager()->OnLocalClientSwitchLevelComplete.Broadcast(CurrentLevel);
	//	GetGameInstance()->GetAudioManager()->PlayBGM(TEXT("Battle"));
	//	GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, FString::Printf(TEXT(" ClientGUID Is Not Exist , CurrentLevel = %s!!!!!"),*CurrentLevel));

	//}
}