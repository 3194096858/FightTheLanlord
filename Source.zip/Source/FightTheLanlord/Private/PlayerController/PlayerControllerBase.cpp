﻿

#include "PlayerController/PlayerControllerBase.h"
#include "GameState/FTL_GameStateBase.h"
#include "PlayerState/FTL_PlayerStateBase.h"

#include "GameInstance/FTL_GameInstance.h"
#include "Manager/WidgetManager.h"
#include "Manager/GameSettingsManager.h"
#include "Manager/DelegateManager.h"
#include "Manager/GameSessionManager.h"

#include "Kismet/GameplayStatics.h"
#include "Manager/LevelManager.h"

#include "Kismet/KismetSystemLibrary.h"


APlayerControllerBase::APlayerControllerBase()
{

	bShowMouseCursor = true;

}


void APlayerControllerBase::BeginPlay()
{
	Super::BeginPlay();
	Client_BeginPlay();

	//Super::OnREp_Pla
}


void APlayerControllerBase::EndPlay(EEndPlayReason::Type EndPlayResason)
{
	Super::EndPlay(EndPlayResason);
	Client_EndPlay();


}


void APlayerControllerBase::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}


UFTL_GameInstance* APlayerControllerBase::GetGameInstance()
{

	if (this->GameInstance == nullptr)
	{
		this->GameInstance = Cast<UFTL_GameInstance>(UGameplayStatics::GetGameInstance(GetWorld()));
	}
	return this->GameInstance;
}

void APlayerControllerBase::Client_BeginPlay_Implementation()
{
	

}

void APlayerControllerBase::Client_EndPlay_Implementation()
{



}

void APlayerControllerBase::Client_QuitSession_Implementation()
{
	if (GetGameInstance()->GetGameSessionManager()->GetCurrentSessionName() == TEXT("None"))
	{
		return;
	}
	GetGameInstance()->GetGameSessionManager()->QuitCurrentSession();



}

void APlayerControllerBase::Client_OnLocalClientSwitchLevel_Implementation()
{
	GetGameInstance()->GetDelegateManager()->OnLocalClientSwitchLevel.Broadcast();

}

