﻿#include "PlayerController/MainLevelPlayerController.h"

#include "GameState/FTL_GameStateBase.h"
#include "PlayerState/FTL_PlayerStateBase.h"

#include "GameInstance/FTL_GameInstance.h"
#include "Manager/WidgetManager.h"
#include "Manager/GameSettingsManager.h"
#include "Manager/DelegateManager.h"
#include "Manager/GameSessionManager.h"
#include "Manager/AudioManager.h"

#include "Kismet/GameplayStatics.h"
#include "Manager/CardLibrary.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Manager/FTL_AssetManager.h"


AMainLevelPlayerController::AMainLevelPlayerController()
{


}


void AMainLevelPlayerController::BeginPlay()
{
	Super::BeginPlay();


}


void AMainLevelPlayerController::EndPlay(EEndPlayReason::Type EndPlayResason)
{
	Super::EndPlay(EndPlayResason);


}


void AMainLevelPlayerController::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}


void AMainLevelPlayerController::Client_BeginPlay_Implementation()
{
	Super::Client_BeginPlay_Implementation();

	FString CurrentLevel = UGameplayStatics::GetCurrentLevelName(this);
	static bool IsInitialize = false;
	if (IsInitialize == false)
	{
		GetGameInstance()->GetAudioManager()->Initialize(GetGameInstance());
		GetGameInstance()->GetWidgetManager()->InitializeWidget(GetGameInstance());
		InitializeScreen();
		IsInitialize = true;
	}
	if (CurrentLevel == TEXT("MainLevel"))
	{
		GetGameInstance()->GetDelegateManager()->OnStartMenuOpen.Broadcast();
		GetGameInstance()->GetAudioManager()->PlayBGM(TEXT("StartMenu"));

	}



}

void AMainLevelPlayerController::Client_EndPlay_Implementation()
{
	Super::Client_EndPlay_Implementation();


	///GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, FString::Printf(TEXT("Client: EndPlay !!!!!!!!")));


}




void AMainLevelPlayerController::InitializeScreen()
{
	FIntPoint Resolution = GetGameInstance()->GetGameState()->GameDefaultData.GameSettings.Display.ScreenResolution;
	EWindowMode::Type WindowMode = GetGameInstance()->GetGameState()->GameDefaultData.GameSettings.Display.WindowMode;
	GetGameInstance()->GetGameSettingsManager()->SetWindowMode(WindowMode);
	GetGameInstance()->GetGameSettingsManager()->SetScreenResolution(Resolution);

}


