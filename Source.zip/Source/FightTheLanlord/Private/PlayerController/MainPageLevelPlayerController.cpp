﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "PlayerController/MainPageLevelPlayerController.h"


#include "GameState/FTL_GameStateBase.h"
#include "PlayerState/FTL_PlayerStateBase.h"

#include "GameInstance/FTL_GameInstance.h"
#include "Manager/WidgetManager.h"
#include "Manager/GameSettingsManager.h"
#include "Manager/DelegateManager.h"
#include "Manager/GameSessionManager.h"
#include "Manager/AudioManager.h"

#include "Kismet/GameplayStatics.h"

#include "Kismet/KismetSystemLibrary.h"


AMainPageLevelPlayerController::AMainPageLevelPlayerController()
{


}


void AMainPageLevelPlayerController::BeginPlay()
{
	Super::BeginPlay();


}


void AMainPageLevelPlayerController::EndPlay(EEndPlayReason::Type EndPlayResason)
{
	Super::EndPlay(EndPlayResason);


}


void AMainPageLevelPlayerController::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}


void AMainPageLevelPlayerController::Client_BeginPlay_Implementation()
{
	Super::Client_BeginPlay_Implementation();
	FString CurrentLevel = UGameplayStatics::GetCurrentLevelName(this);
	this->QuitGameHandle = GetGameInstance()->GetDelegateManager()->OnGameQuit.AddUObject(this, &AMainPageLevelPlayerController::OnGameQuit);
	if (CurrentLevel == TEXT("GameMainPageLevel"))
	{
		GetGameInstance()->GetWidgetManager()->RemoveAllWidgetFromViewport(EWidgetRenderingLevel::HUD);
		GetGameInstance()->GetWidgetManager()->RemoveAllWidgetFromViewport(EWidgetRenderingLevel::UserTip);
		GetGameInstance()->GetWidgetManager()->RemoveAllCardFromCardHand();
		GetGameInstance()->GetDelegateManager()->OnLocalClientSwitchLevelComplete.Broadcast(CurrentLevel);
		GetGameInstance()->GetAudioManager()->PlayBGM(TEXT("GameMainPage"));

	}



}

void AMainPageLevelPlayerController::Client_EndPlay_Implementation()
{
	Super::Client_EndPlay_Implementation();
	GetGameInstance()->GetDelegateManager()->OnGameQuit.Remove(this->QuitGameHandle);
	this->QuitGameHandle.Reset();


}





void AMainPageLevelPlayerController::OnGameQuit()
{

	UKismetSystemLibrary::QuitGame(this, this, EQuitPreference::Quit, false);


}

