﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "PlayerController/GameLobbyLevelPlayerController.h"


#include "GameState/FTL_GameStateBase.h"
#include "PlayerState/FTL_PlayerStateBase.h"

#include "GameInstance/FTL_GameInstance.h"
#include "Manager/WidgetManager.h"
#include "Manager/GameSettingsManager.h"
#include "Manager/DelegateManager.h"
#include "Manager/GameSessionManager.h"

#include "Kismet/GameplayStatics.h"

#include "Kismet/KismetSystemLibrary.h"


AGameLobbyLevelPlayerController::AGameLobbyLevelPlayerController()
{


}


void AGameLobbyLevelPlayerController::BeginPlay()
{
	Super::BeginPlay();


}


void AGameLobbyLevelPlayerController::EndPlay(EEndPlayReason::Type EndPlayResason)
{
	Super::EndPlay(EndPlayResason);


}


void AGameLobbyLevelPlayerController::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}


void AGameLobbyLevelPlayerController::Client_BeginPlay_Implementation()
{
	Super::Client_BeginPlay_Implementation();
	FString CurrentLevel = UGameplayStatics::GetCurrentLevelName(this);
	if (CurrentLevel == TEXT("GameLobbyLevel"))
	{
		GetGameInstance()->GetDelegateManager()->OnLocalClientSwitchLevelComplete.Broadcast(CurrentLevel);
	}


}

void AGameLobbyLevelPlayerController::Client_EndPlay_Implementation()
{
	Super::Client_EndPlay_Implementation();
	///GetGameInstance()->GetDelegateManager()->OnGameStart.Remove(this->StartGameHandle);
	////this->StartGameHandle.Reset();



}




void AGameLobbyLevelPlayerController::Client_SetGameLobbyPanelPlayerNumber_Implementation(int32 CurrentNumber)
{
	GetGameInstance()->GetWidgetManager()->SetGameLobbyPlayerNumber(CurrentNumber);

}



void AGameLobbyLevelPlayerController::Client_OnGameStart_Implementation()
{
	GetGameInstance()->GetDelegateManager()->OnGameStart.Broadcast();

}