﻿

#include "AIController/FTL_AIController.h"

#include "GameInstance/FTL_GameInstance.h"
#include "kismet/GameplayStatics.h"
#include "GameMode/BattleGameMode.h"
#include "Manager/DelegateManager.h"
#include "Manager/ObjectPoolManager.h"

#include "Manager/FTL_AssetManager.h"

#include "BehaviorTree/BehaviorTreeComponent.h"

#include "BehaviorTree/BehaviorTree.h"






AFTL_AIController::AFTL_AIController()
{
	this->BehaviorTreeComponent = CreateDefaultSubobject<UBehaviorTreeComponent>(TEXT("BehaviorTreeComponent"));
	this->BrainComponent = this->BehaviorTreeComponent;

}


void AFTL_AIController::BeginPlay()
{
	Super::BeginPlay();
	GetGameInstance()->GetDelegateManager()->OnObjectBeginPlay.AddUObject(this, &AFTL_AIController::OnObjectBeginPlay);
	GetGameInstance()->GetDelegateManager()->OnObjectEndPlay.AddUObject(this, &AFTL_AIController::OnObjectEndPlay);
	GetGameInstance()->GetDelegateManager()->OnGameOver.AddUObject(this, &AFTL_AIController::OnGameOver);
}


void AFTL_AIController::EndPlay(EEndPlayReason::Type EndPlayResason)
{
	Super::EndPlay(EndPlayResason);


}


void AFTL_AIController::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	///Super::OnPossess();
}

ABattleGameMode* AFTL_AIController::GetGameMode()
{
	if (this->GameMode ==nullptr)
	{
		this->GameMode = Cast<ABattleGameMode>(UGameplayStatics::GetGameMode(this));
	}
	return this->GameMode;
}


void AFTL_AIController::SetPlayerCardHand(const TArray<FCardInformation>& NewArray)
{
	this->CardArray = NewArray;

}


bool AFTL_AIController::CheckHasValidHandType()
{
	FCardInformation SelectedCard;
	FTurnHandTypeInformation Information = GetGameMode()->GetLastTurnHandTypeInformation();
	int32 CardNumber = this->CardArray.Num();
	SelectedCard.Value = -1;
	if (Information.Information.HandType != EHandType::Single)
	{
		this->SelectedCardArray.Empty();
		return false;
	}
	if (Information.PlayerID == -1)
	{
		SelectedCard = this->CardArray[FMath::RandRange(0, CardNumber - 1)];
		this->SelectedCardArray.Add(SelectedCard);
		return true;
	}
	if (Information.PlayerID == this->PlayerID)
	{
		SelectedCard = this->CardArray[FMath::RandRange(0, CardNumber - 1)];
		this->SelectedCardArray.Add(SelectedCard);
		return true;
	}
	SelectedCard = this->CardArray[FMath::RandRange(0, CardNumber - 1)];
	if (SelectedCard.Value > Information.Information.Value)
	{
		this->SelectedCardArray.Add(SelectedCard);

		return true;
	}

	this->SelectedCardArray.Empty();
	return false;
}


void AFTL_AIController::PlayCard()
{
	GetGameMode()->OnAIPlayerPlayCard(this->PlayerID, this->SelectedCardArray);
	RemoveCardFormCardHand(this->SelectedCardArray);
	this->SelectedCardArray.Empty();
	GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, FString::Printf(TEXT("  AIPlayer: Play Card , Number = %d !!!!!"),this->CardArray.Num()));
}


void AFTL_AIController::Pass()
{
	GetGameMode()->OnPlayerPass(this->PlayerID);
	GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, FString::Printf(TEXT("  AIPlayer: Pass !!!!!")));

}


void AFTL_AIController::SetPlayerID(int32 NewID)
{
	this->PlayerID = NewID;
}
int32 AFTL_AIController::GetPlayerID()
{
	return this->PlayerID;
}

void AFTL_AIController::RemoveAllSelectedCard()
{
	this->SelectedCardArray.Empty();

}

void AFTL_AIController::RemoveCardFormCardHand(const TArray<FCardInformation>& Array)
{
	for (auto& Element : Array)
	{
		for (int32 i = 0; i < this->CardArray.Num(); i++)
		{
			if (Element.Name == this->CardArray[i].Name && Element.Suit == this->CardArray[i].Suit)
			{
				this->CardArray.RemoveAt(i);
			}
		}
	}
}




TArray<FHandTypeInformation> AFTL_AIController::GetAllPossibleHandTypeInformation()
{
	TArray<FHandTypeInformation> Array;

	/*int32 CardNumber = this->CardArray.Num();
	TArray<int32> Value1Array;
	TArray<int32> Value2Array;
	TArray<int32> Value3Array;
	int32 Value1 = CardNumber != 0 ? this->CardArray[FMath::RandRange(0, CardNumber - 1)].Value : -1;
	int32 Value2 = Value1;
	int32 Value3 = Value2;
	int32 RedJokerValue = 15;
	int32 BlackJokerValue = 14;
	int32 t = 0;
	TArray<FHandTypeInformation> Array;
	FHandTypeInformation HandTypeInformation;
	FTurnHandTypeInformation Information = GetGameMode()->GetLastTurnHandTypeInformation();
	if (CardNumber == 1)
	{
		HandTypeInformation.HandType = EHandType::Single;
		HandTypeInformation.Number = 1;
		HandTypeInformation.Value = this->CardArray[0].Value;
		Array.Add(HandTypeInformation);
		return Array;
	}
	if (CardNumber == 2)
	{
		if (this->CardArray[0].Value == this->CardArray[1].Value)
		{
			HandTypeInformation.HandType = EHandType::Pair;
			HandTypeInformation.Number = 2;
			HandTypeInformation.Value = this->CardArray[0].Value;
			Array.Add(HandTypeInformation);
			return Array;
		}
		if (this->CardArray[0].Value >= BlackJokerValue && this->CardArray[1].Value >= BlackJokerValue)
		{
			HandTypeInformation.HandType = EHandType::JokerBomb;
			HandTypeInformation.Number = 2;
			HandTypeInformation.Value = RedJokerValue;
			Array.Add(HandTypeInformation);
			return Array;
		}
		HandTypeInformation.HandType = EHandType::Single;
		HandTypeInformation.Number = 1;
		for (int32 i = 0; i < CardNumber; i++)
		{
			HandTypeInformation.Value = this->CardArray[i].Value;
			Array.Add(HandTypeInformation);

		}
		return Array;
	}
	if (CardNumber == 3)
	{
		if (this->CardArray[0].Value == this->CardArray[1].Value&& this->CardArray[1].Value == this->CardArray[2].Value)
		{
			HandTypeInformation.HandType = EHandType::Triple;
			HandTypeInformation.Number = 3;
			HandTypeInformation.Value = this->CardArray[0].Value;
			Array.Add(HandTypeInformation);
			return Array;
		}
		while (Value2 == Value1 && t < 100)
		{
			t++;
			Value2 = this->CardArray[FMath::RandRange(0, CardNumber - 1)].Value;
		}

		t = 0;
		while ((Value3 == Value1 || Value3 == Value2) && t < 100)
		{
			t++;
			Value3 = CardArray[FMath::RandRange(0, CardNumber - 1)].Value;
		}
		if (Value3 == Value2)
		{
			for (auto& Element : this->CardArray)
			{
				if (Element.Value == Value1)
				{
					Value1Array.Add(Element.Value);
				}
				if (Element.Value == Value2)
				{
					Value2Array.Add(Element.Value);
				}
			}
			for (int32 i = 0; i < CardNumber -1 ; i++)
			{
					HandTypeInformation.HandType =Value1Array.Num() ==1?EHandType::Single: EHandType::Pair;
					HandTypeInformation.Number = Value1Array.Num();
					HandTypeInformation.Value = Value1Array[0];
					Array.Add(HandTypeInformation);
					HandTypeInformation.HandType = Value2Array.Num() == 1 ? EHandType::Single : EHandType::Pair;
					HandTypeInformation.Number = Value2Array.Num();
					HandTypeInformation.Value = Value2Array[0];
					Array.Add(HandTypeInformation);
			}
			return Array;
		}
		for (auto& Element : this->CardArray)
		{
			if (Element.Value == Value1)
			{
				Value1Array.Add(Element.Value);
			}
			if (Element.Value == Value2)
			{
				Value2Array.Add(Element.Value);
			}
			if (Element.Value == Value3)
			{
				Value3Array.Add(Element.Value);
			}
		}
		HandTypeInformation.HandType = EHandType::Single;
		HandTypeInformation.Number = 1;
		for (int32 i = 0; i < CardNumber; i++)
		{
			HandTypeInformation.Value = this->CardArray[i].Value;
			Array.Add(HandTypeInformation);
		}


	}
	if (CardNumber == 4)
	{
		if (this->CardArray[0].Value == this->CardArray[1].Value && this->CardArray[0].Value == this->CardArray[2].Value&& this->CardArray[0].Value == this->CardArray[3].Value)
		{
			HandTypeInformation.HandType = EHandType::Bomb;
			HandTypeInformation.Number = 4;
			HandTypeInformation.Value = this->CardArray[0].Value;
			Array.Add(HandTypeInformation);
			return Array;
		}
	}*/

	return Array;
}




TArray<FHandTypeInformation> AFTL_AIController::GetAllAirplaneHandTypeInformation()
{
	TArray<FHandTypeInformation> Array;
	return Array;

}

TArray<FHandTypeInformation> AFTL_AIController::GetAllBombHandTypeInformation()
{
	int32 CardNumber = this->CardArray.Num();
	TArray<int32> Value1Array;
	TArray<int32> Value2Array;
	TArray<int32> Value3Array;
	int32 Value1 = CardNumber != 0 ? this->CardArray[FMath::RandRange(0, CardNumber - 1)].Value : -1;
	int32 Value2 = Value1;
	int32 Value3 = Value2;
	int32 RedJokerValue = 15;
	int32 BlackJokerValue = 14;
	int32 t = 0;
	TArray<FHandTypeInformation> Array;
	FHandTypeInformation HandTypeInformation;
	FTurnHandTypeInformation Information = GetGameMode()->GetLastTurnHandTypeInformation();


	return Array;


}

TArray<FHandTypeInformation> AFTL_AIController::GetAllTripletWithKickerHandTypeInformation()
{
	TArray<FHandTypeInformation> Array;
	return Array;


}

TArray<FHandTypeInformation> AFTL_AIController::GetAllTripletHandTypeInformation()
{

	TArray<FHandTypeInformation> Array;
	return Array;

}


UFTL_GameInstance* AFTL_AIController::GetGameInstance()
{
	if(this->GameInstance == nullptr)
	{
		this->GameInstance = Cast<UFTL_GameInstance>(UGameplayStatics::GetGameInstance(this));

	}
	return this->GameInstance;
}


void AFTL_AIController::OnPossess(APawn* InPawn)
{
	Super::OnPossess(InPawn);
	UBehaviorTree* BehaviorTree = GetGameInstance()->GetAssetManager()->GetAIPlayerBehaviorTree();
	if (BehaviorTree == nullptr)
	{
		return;
	}
	RunBehaviorTree(BehaviorTree);
	this->BehaviorTreeComponent->PauseLogic(TEXT("PauseLogic"));

}


void AFTL_AIController::OnObjectBeginPlay(AActor* Object)
{
	if (Object != GetPawn())
	{
		return;
	}
	this->BehaviorTreeComponent->ResumeLogic(TEXT("ResumeLogic"));
	////GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, FString::Printf(TEXT(" Resume BehaviorTree !!!!!")));

}

void AFTL_AIController::OnObjectEndPlay(AActor* Object)
{

	if (Object != GetPawn())
	{
		return;
	}
	this->BehaviorTreeComponent->PauseLogic(TEXT("PauseLogic"));

	///GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, FString::Printf(TEXT(" Pause BehaviorTree !!!!!")));

}

void AFTL_AIController::OnGameOver(bool IsLanlordWin)
{


}


