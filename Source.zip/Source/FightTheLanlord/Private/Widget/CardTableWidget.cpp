﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "Widget/CardTableWidget.h"


#include "Components/SizeBox.h"
#include "Components/Image.h"
#include "Components/OverLay.h"

#include "Components/TextBlock.h"
#include "Components/CircularThrobber.h"
#include "Widget/CardWidget.h"
#include "Components/OverlaySlot.h"

#include "Manager/FTL_AssetManager.h"
#include "Struct/GameProperty.h"
#include "Manager/DelegateManager.h"
#include "Manager/AudioManager.h"
#include "Widget/ButtonWidget.h"
#include "Widget/ResourcePanel.h"
#include "Manager/WidgetManager.h"
#include "Struct/CardInformation.h"

#include "Widget/TextBlockWidget.h"
#include "GameInstance/FTL_GameInstance.h"

#include "GameState/FTL_GameStateBase.h"

#include "Manager/FTL_TimerManager.h"




void UCardTableWidget::NativeOnInitialized()
{
	Super::NativeOnInitialized();
	FCardTableWidgetData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.CardTableWidget;
	/////GetGameInstance()->GetDelegateManager()->OnGameStart.AddUObject(this, &UOperationPanel::OnGameStart);
	SetWidgetSize(Data.Size);
	SetRelativePosition(Data.RelativePosition);

	GetGameInstance()->GetDelegateManager()->OnCardTableWidgetOpen.AddUObject(this, &UCardTableWidget::OnCardTableWidgetOpen);
	GetGameInstance()->GetDelegateManager()->OnCardTableWidgetClose.AddUObject(this, &UCardTableWidget::OnCardTableWidgetClose);
	GetGameInstance()->GetDelegateManager()->OnGameOver.AddUObject(this, &UCardTableWidget::OnGameOver);

}


void UCardTableWidget::NativeConstruct()
{
	Super::NativeConstruct();

}


void UCardTableWidget::NativePreConstruct()
{
	Super::NativePreConstruct();

}


void UCardTableWidget::NativeDestruct()
{
	Super::NativeDestruct();


}


void UCardTableWidget::AddWidgetToOverlay(UWidgetBase* Widget)
{
	UPanelSlot* PanelSlot = this->Overlay->AddChild(Widget);
	UOverlaySlot* OverlaySlot = Cast<UOverlaySlot>(PanelSlot);
	if (OverlaySlot == nullptr)
	{
		return;
	}
	OverlaySlot->SetHorizontalAlignment(EHorizontalAlignment::HAlign_Center);
	OverlaySlot->SetVerticalAlignment(EVerticalAlignment::VAlign_Center);


}


void UCardTableWidget::AddCard(const TArray<FCardInformation>& CardArray)
{

	UCardWidget* Widget = nullptr;
	UTexture2D* Image = nullptr;
	for (auto& Element : CardArray)
	{
		Widget = GetGameInstance()->GetWidgetManager()->GetCardWidget(GetGameInstance());
		if (Widget != nullptr && this->Overlay->HasChild(Widget) == false)
		{
			Image = GetGameInstance()->GetAssetManager()->GetCardImage(Element.Name, Element.Suit);
			Widget->SetImage(Image);
			AddWidgetToOverlay(Widget);
		}
	}
	UpdateCardRelativeTransform();

}

void UCardTableWidget::RemoveCard(UCardWidget* Card)
{
	if (this->Overlay->HasChild(Card) == false)
	{
		return;
	}
	GetGameInstance()->GetWidgetManager()->ReturnCardWidget(Card);
	this->Overlay->RemoveChild(Card);

}
void UCardTableWidget::Clear()
{
	for (auto& Element : GetAllCard())
	{
		Element->SetVisibility(ESlateVisibility::Collapsed);
		GetGameInstance()->GetWidgetManager()->ReturnCardWidget(Element);
	}
	this->Overlay->ClearChildren();
}

TArray<UCardWidget*> UCardTableWidget::GetAllCard()
{
	TArray<UCardWidget*> Array;
	UCardWidget* Widget = nullptr;
	for (auto& Element : this->Overlay->GetAllChildren())
	{
		Widget = Cast<UCardWidget>(Element);
		if (Widget != nullptr)
		{
			Array.Add(Widget);
		}
	}
	return Array;
}

void UCardTableWidget::UpdateCardRelativeTransform()
{
	TArray<UCardWidget*> Array = GetAllCard();
	FVector2D Position;
	FVector2D Size = GetGameInstance()->GetGameState()->GameDefaultData.Widget.CardTableWidget.CardSize;
	int32 Index = 0;
	float HoriontalInterval = 25.0f;
	float VerticalInterval = 0.0f;

	for (auto& Element : Array)
	{
		Index++;
		Position.X = HoriontalInterval * Index;
		Element->SetRelativePosition(Position);
		Element->SetWidgetSize(Size);

	}

}



void UCardTableWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	Super::OnAnimationFinished_Implementation(Animation);


}




void UCardTableWidget::OnLocalClientGameStateCompleteInitialize()
{
	Super::OnLocalClientGameStateCompleteInitialize();
	
}


void UCardTableWidget::OnServerGameStateCompleteInitialize()
{
	Super::OnServerGameStateCompleteInitialize();
	

}



void UCardTableWidget::OnLocalClientPlayerControllerCompleteInitialize()
{
	Super::OnLocalClientPlayerControllerCompleteInitialize();
	


}


void UCardTableWidget::OnCardTableWidgetOpen()
{
	FVector2D Size = GetGameInstance()->GetGameState()->GameDefaultData.Widget.CardTableWidget.Size;
	FAnchorData AnchorData = GetGameInstance()->GetGameState()->GameDefaultData.Widget.AnchorData;
	GetGameInstance()->GetWidgetManager()->OpenCardTableWidget(Size, AnchorData);

}

void UCardTableWidget::OnCardTableWidgetClose()
{
	GetGameInstance()->GetWidgetManager()->CloseCardTableWidget();
	Clear();
}



void UCardTableWidget::OnGameOver(bool IsLanlordWin)
{
	OnCardTableWidgetClose();
}


