﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "Widget/SliderWidget.h"


#include "Components/Button.h"
#include "Components/Image.h"
#include "Components/Slider.h"

#include "Components/TextBlock.h"
#include "Widget/TextBlockWidget.h"

#include "GameInstance/FTL_GameInstance.h"
#include "Manager/AudioManager.h"
#include "Manager/FTL_AssetManager.h"
#include "GameState/FTL_GameStateBase.h"




void USliderWidget::NativeOnInitialized()
{
	Super::NativeOnInitialized();
	this->Slider->OnValueChanged.AddDynamic(this,&USliderWidget::OnValueUpdate);
	this->TextBlock->SetBackGroundImageVisibility(ESlateVisibility::Collapsed);

	SetValue(this->Slider->GetMaxValue() * 0.5f);



}

void USliderWidget::NativePreConstruct()
{
	Super::NativePreConstruct();
	
}


void USliderWidget::NativeConstruct()
{
	Super::NativeConstruct();


}


void USliderWidget::NativeDestruct()
{
	Super::NativeDestruct();


}


float USliderWidget::GetValue()
{
	return this->Slider->GetValue();

}

void USliderWidget::SetStepSize(float NewSize)
{
	this->Slider->SetStepSize(NewSize);
}


void USliderWidget::SetValue(float NewValue)
{
	this->Slider->SetValue(NewValue);
}

void USliderWidget::SetMaxValue(float NewValue)
{
	this->Slider->SetMaxValue(NewValue);

}

void USliderWidget::SetMinValue(float NewValue)
{
	this->Slider->SetMinValue(NewValue);

}


void USliderWidget::SetBackGroundImageColor(const FColor& NewColor)
{
	this->BackGroundImage->SetBrushTintColor(NewColor);


}




void USliderWidget::SetBarColor(const FColor& NewColor)
{
	FSliderStyle Style = this->Slider->GetWidgetStyle();
	FSlateBrush BarSlateBrush = Style.NormalBarImage;
	BarSlateBrush.TintColor = NewColor;
	Style.SetNormalBarImage(BarSlateBrush);
	Style.SetHoveredBarImage(BarSlateBrush);
	this->Slider->SetWidgetStyle(Style);

}




void USliderWidget::SetHandleColor(const FColor& NewColor)
{
	FSliderStyle Style = this->Slider->GetWidgetStyle();
	FSlateBrush HandleSlateBrush = Style.NormalThumbImage;
	HandleSlateBrush.TintColor = NewColor;
	Style.SetNormalThumbImage(HandleSlateBrush);
	Style.SetHoveredThumbImage(HandleSlateBrush);
	this->Slider->SetWidgetStyle(Style);

}

void USliderWidget::SetCurrentPercent(int32 NewPercent)
{
	FString NewText = FString::FromInt(NewPercent);

	//FString NewText = FString::FromInt(NewPercent) + TEXT("%");
	this->TextBlock->SetText(NewText);

}


int32 USliderWidget::GetCurrentPercent()
{
	int32 Percent = GetValue() * 100;
	return Percent;
}


void USliderWidget::SetText(const FString& NewText)
{
	this->TextBlock->SetText(NewText);

}

void USliderWidget::SetHandleSize(const FVector2D& NewSize)
{
	FSliderStyle Style = this->Slider->GetWidgetStyle();
	FSlateBrush HandleSlateBrush = Style.NormalThumbImage;
	HandleSlateBrush.ImageSize = NewSize;
	Style.SetNormalThumbImage(HandleSlateBrush);
	Style.SetHoveredThumbImage(HandleSlateBrush);
	this->Slider->SetWidgetStyle(Style);


}

void USliderWidget::SetTextBlockRelativePosition(const FVector2D& NewSize)
{
	this->TextBlock->SetRelativePosition(NewSize);
}


void USliderWidget::SetFontSize(int32 NewSize)
{
	this->TextBlock->SetFontSize(NewSize);

}

void USliderWidget::SetFontColor(const FColor& NewColor)
{
	this->TextBlock->SetColorAndOpacity(NewColor);

}

void USliderWidget::SetFontInformation(const FSlateFontInfo& NewFont)
{
	this->TextBlock->SetFontInformation(NewFont);

}

void USliderWidget::SetBackGroundImage(UTexture2D* NewImage)
{
	this->BackGroundImage->SetBrushFromTexture(NewImage);

}



void USliderWidget::SetBackGroundImageVisibility(const ESlateVisibility& NewVisibility)
{
	this->BackGroundImage->SetVisibility(NewVisibility);
}


void USliderWidget::SetBarImage(UTexture2D* NewImage)
{
	FSliderStyle Style = this->Slider->GetWidgetStyle();
	FSlateBrush BarSlateBrush = Style.NormalBarImage;
	BarSlateBrush.SetResourceObject(NewImage);
	Style.SetNormalBarImage(BarSlateBrush);
	Style.SetHoveredBarImage(BarSlateBrush);
	this->Slider->SetWidgetStyle(Style);

}


void USliderWidget::SetHandleImage(UTexture2D* NewImage)
{
	FSliderStyle Style = this->Slider->GetWidgetStyle();
	FSlateBrush HandleSlateBrush = Style.NormalThumbImage;
	HandleSlateBrush.SetResourceObject(NewImage);
	Style.SetNormalThumbImage(HandleSlateBrush);
	Style.SetHoveredThumbImage(HandleSlateBrush);
	this->Slider->SetWidgetStyle(Style);

}



void USliderWidget::SetTextBlockVisibility(const ESlateVisibility& NewVisibility)
{
	this->TextBlock->SetVisibility(NewVisibility);
}



void USliderWidget::SetBarThickness(float NewThickness)
{
	FSliderStyle Style = this->Slider->GetWidgetStyle();

	Style.SetBarThickness(NewThickness);
	this->Slider->SetWidgetStyle(Style);

}


void USliderWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{



}


void USliderWidget::OnValueUpdate(float Value)
{
	this->OnValueChange.ExecuteIfBound(Value);

}
