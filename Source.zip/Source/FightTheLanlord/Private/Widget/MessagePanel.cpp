﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "Widget/MessagePanel.h"


#include "Components/SizeBox.h"
#include "Components/Image.h"
#include "Components/ScrollBox.h"
#include "Components/ScrollBoxSlot.h"

#include "Manager/FTL_AssetManager.h"
#include "Struct/GameProperty.h"
#include "Manager/DelegateManager.h"
#include "Manager/AudioManager.h"
#include "Widget/ButtonWidget.h"
#include "Widget/TextBlockWidget.h"
#include "Manager/GameSessionManager.h"
#include "Widget/MessageWidget.h"
#include "Widget/EditableTextBoxWidget.h"

#include "Manager/WidgetManager.h"
#include "Manager/LevelManager.h"

#include "GameState/FTL_GameStateBase.h"
#include "GameInstance/FTL_GameInstance.h"
#include "PlayerController/BattleLevelPlayerController.h"




void UMessagePanel::NativeOnInitialized()
{
	Super::NativeOnInitialized();
	FMessagePanelData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.MessagePanel;
	FMessagePanelAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.MessagePanel;
	float PlayRate = GetGameInstance()->GetGameState()->GameDefaultData.Widget.MessagePanelAnimationPlayRate;
	SetAnimationPlayRate(PlayRate);
	SetWidgetSize(Data.Size);
	SetRelativePosition(Data.RelativePosition);
	GetGameInstance()->GetDelegateManager()->OnMessagePanelOpen.AddUObject(this, &UMessagePanel::OnMessagePanelOpen);
	GetGameInstance()->GetDelegateManager()->OnMessagePanelClose.AddUObject(this, &UMessagePanel::OnMessagePanelClose);
	this->BackGroundImage->SetBrushFromTexture(Asset.BackGroundImage.Image);
	this->BackGroundImage->SetBrushTintColor(Data.BackGroundImage.Color);
	GetGameInstance()->GetDelegateManager()->OnGameOver.AddUObject(this, &UMessagePanel::OnGameOver);
	GetGameInstance()->GetWidgetManager()->InitializeEditableTextBox(this->EditableTextBox, Data.EditableTextBox, Asset.EditableTextBox);
	InitializeSendingButton();
	this->SendingButton->OnClick.BindUObject(this, &UMessagePanel::OnClickSendingButton);
	FScrollBoxStyle Style = this->ScrollBox->GetWidgetStyle();
	FSlateBrush ScrollBoxSlateBrush;
	ScrollBoxSlateBrush.SetImageSize(FVector2D(0.0f));
	Style.SetBottomShadowBrush(ScrollBoxSlateBrush);
	Style.SetTopShadowBrush(ScrollBoxSlateBrush);
	this->ScrollBox->SetWidgetStyle(Style);
	this->ScrollBox->SetScrollBarVisibility(ESlateVisibility::Collapsed);
}





void UMessagePanel::NativePreConstruct()
{
	Super::NativePreConstruct();


}


void UMessagePanel::NativeConstruct()
{
	Super::NativeConstruct();


}


void UMessagePanel::NativeDestruct()
{
	Super::NativeDestruct();


}


void UMessagePanel::InitializeSendingButton()
{
	FButtonWidgetData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.MessagePanel.SendingButton;
	FButtonWidgetAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.MessagePanel.SendingButton;
	GetGameInstance()->GetWidgetManager()->InitializeButton(this->SendingButton, Data, Asset);

}


void UMessagePanel::AddMessage(UMessageWidget* MessageWidget)
{
	if (MessageWidget == nullptr)
	{
		return;
	}
	if (this->ScrollBox->HasChild(MessageWidget) == true)
	{
		return;
	}
	this->ScrollBox->AddChild(MessageWidget);
	
}

void UMessagePanel::RemoveMessage(UMessageWidget* MessageWidget)
{
	if (this->ScrollBox->HasChild(MessageWidget) == false)
	{
		return;
	}
	MessageWidget->SetVisibility(ESlateVisibility::Collapsed);
	GetGameInstance()->GetWidgetManager()->ReturnMessageWidget(MessageWidget);
	this->ScrollBox->RemoveChild(MessageWidget);

}

void UMessagePanel::Clear()
{
	for (auto& Element : this->ScrollBox->GetAllChildren())
	{
		UMessageWidget* Widget = Cast<UMessageWidget>(Element);
		Element->SetVisibility(ESlateVisibility::Collapsed);
		GetGameInstance()->GetWidgetManager()->ReturnMessageWidget(Widget);
	}
	this->ScrollBox->ClearChildren();
}

void UMessagePanel::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	Super::OnAnimationFinished_Implementation(Animation);


}

void UMessagePanel::OnMessagePanelOpen()
{
	FVector2D Size = GetGameInstance()->GetGameState()->GameDefaultData.Widget.MessagePanel.Size;
	FAnchorData AnchorData = GetGameInstance()->GetGameState()->GameDefaultData.Widget.AnchorData;
	GetGameInstance()->GetWidgetManager()->OpenMessagePanel(Size, AnchorData);

}


void UMessagePanel::OnMessagePanelClose()
{
	GetGameInstance()->GetWidgetManager()->CloseMessagePanel();

}




void UMessagePanel::OnGameOver(bool IsLanlordWin)
{
	OnMessagePanelClose();
	Clear();

}

void UMessagePanel::OnClickSendingButton()
{
	ABattleLevelPlayerController* Controller = Cast<ABattleLevelPlayerController>(GetOwningPlayer());
	FString Message = TEXT("");
	this->EditableTextBox->GetText(Message);
	if (Message != TEXT(""))
	{
		Controller->Server_SendMessage(Controller->GetPlayerID(),Message);
	}
	else
	{
		GEngine->AddOnScreenDebugMessage(-1,11.0f,FColor::Blue,TEXT(" 消息为空！！！"));
	}
	this->EditableTextBox->SetText(TEXT(""));

}

