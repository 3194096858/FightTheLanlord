﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "Widget/DisplaySettingsPanel.h"


#include "Components/SizeBox.h"
#include "Components/Image.h"

#include "Manager/FTL_AssetManager.h"
#include "Struct/GameProperty.h"
#include "Manager/DelegateManager.h"
#include "Manager/AudioManager.h"
#include "Widget/ButtonWidget.h"
#include "Widget/TextBlockWidget.h"
#include "Widget/GameSettingsOptionWidget.h"
#include "Manager/GameSettingsManager.h"
#include "Widget/ComboBoxWidget.h"
#include "Manager/WidgetManager.h"
#include "Widget/ComboBoxMenuWidget.h"

#include "GameState/FTL_GameStateBase.h"
#include "GameInstance/FTL_GameInstance.h"
#include "Components/Button.h"

#include "Components/TextBlock.h"

#include "Struct/WidgetAsset.h"

#include "Struct/WidgetData.h"

#include "Components/CanvasPanelSlot.h"



void UDisplaySettingsPanel::NativeOnInitialized()
{
	Super::NativeOnInitialized();
	InitializeScreenResolutionOptionWidget();
	this->ScreenResolutionOptionWidget->OnComboBoxSelectionChange.BindUObject(this, &UDisplaySettingsPanel::OnScreenResolutionChange);
	this->ScreenResolutionOptionWidget->OnOpenComboBoxMenu.BindUObject(this, &UDisplaySettingsPanel::OnOpenScreenResolutionComboBoxMenu);
	

}





void UDisplaySettingsPanel::NativePreConstruct()
{
	Super::NativePreConstruct();


}


void UDisplaySettingsPanel::NativeConstruct()
{
	Super::NativeConstruct();


}


void UDisplaySettingsPanel::NativeDestruct()
{
	Super::NativeDestruct();
	
}




void UDisplaySettingsPanel::InitializeScreenResolutionOptionWidget()
{
	TArray<FString> ResolutionArray;
	FIntPoint Resolution_Int = FIntPoint();
	FString Resolution_String;
	GetGameInstance()->GetGameSettingsManager()->GetAllResolution(ResolutionArray);
	Resolution_Int= GetGameInstance()->GetGameState()->GameDefaultData.GameSettings.Display.ScreenResolution;
	FGameSettingsOptionWidgetData Data= GetGameInstance()->GetGameState()->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution;
	FGameSettingsOptionWidgetAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.GameSettingsPanel.Display.ScreenResolution;
	Resolution_String = FString::FromInt(Resolution_Int.X) + TEXT(" x ") + FString::FromInt(Resolution_Int.Y);
	for (auto& Element : ResolutionArray)
	{
		this->ScreenResolutionOptionWidget->AddOptionToComboBox(Element,Data.ComboBox.ItemPadding);
	}
	////先 添加选项 再 初始化/////
	GetGameInstance()->GetWidgetManager()->InitializeGameSettingsOption(this->ScreenResolutionOptionWidget, Data, Asset);
	this->ScreenResolutionOptionWidget->SetComboBoxButtonText(Resolution_String);
	this->ScreenResolutionOptionWidget->SetComboBoxMenuAnimationPlayRate(Data.ComboBox.MenuAnimationPlayRate);
	this->ScreenResolutionOptionWidget->SetText(TEXT("屏幕分辨率"));

}



void UDisplaySettingsPanel::InitializeFPSLimitOptionWidget()
{

}

void UDisplaySettingsPanel::InitializeScreenLanguageOptionWidget()
{



}


void UDisplaySettingsPanel::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	if (this->SizeBox->GetRenderOpacity() == 1.0f)
	{
	}
	else
	{

	}


}


void UDisplaySettingsPanel::OnOpenScreenResolutionComboBoxMenu()
{
	
	FVector2D MenuSize= GetGameInstance()->GetGameState()->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.ComboBox.Menu.Size;
	FAnchorData MenuAnchorData= GetGameInstance()->GetGameState()->GameDefaultData.Widget.AnchorData;
	this->ScreenResolutionOptionWidget->OpenComboBoxMenu(MenuSize, MenuAnchorData);


}


void UDisplaySettingsPanel::OnScreenResolutionChange(FString SelectedItem, ESelectInfo::Type SelectionInfo)
{
	FString CurrentResolution = TEXT("");
	EWindowMode::Type CurrentWindowMode;
	CurrentWindowMode = GetGameInstance()->GetGameSettingsManager()->GetWindowMode();
	GetGameInstance()->GetGameSettingsManager()->GetScreenResolution(CurrentResolution);
	GetGameInstance()->GetWidgetManager()->CloseComboBoxMenu(this->ScreenResolutionOptionWidget->GetComboBoxMenu());
	if (SelectedItem == CurrentResolution && CurrentWindowMode != EWindowMode::WindowedFullscreen)
	{
		return;
	}
	if (SelectedItem == TEXT("FullScreen") && CurrentWindowMode != EWindowMode::WindowedFullscreen)
	{
		GetGameInstance()->GetGameSettingsManager()->SetWindowMode(EWindowMode::WindowedFullscreen);
	}
	if(SelectedItem != TEXT("FullScreen"))
	{
		GetGameInstance()->GetGameSettingsManager()->SetWindowMode(EWindowMode::Windowed);
		GetGameInstance()->GetGameSettingsManager()->SetScreenResolution(SelectedItem);
		FIntPoint& Resolution = GetGameInstance()->GetGameState()->PlayerSettingsData.Display.ScreenResolution;
		GetGameInstance()->GetGameSettingsManager()->GetScreenResolution(Resolution);
	}
	this->ScreenResolutionOptionWidget->SetComboBoxButtonText(SelectedItem);


}

void UDisplaySettingsPanel::OnFPSLimitChange(FString SelectedItem, ESelectInfo::Type SelectionInfo)
{

}

void UDisplaySettingsPanel::OnLanguageChange(FString SelectedItem, ESelectInfo::Type SelectionInfo)
{



}









