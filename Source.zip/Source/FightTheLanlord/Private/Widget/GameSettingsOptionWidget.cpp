﻿

#include "Widget/GameSettingsOptionWidget.h"


#include "Components/SizeBox.h"
#include "Components/Image.h"
#include "Components/ComboBoxString.h"
#include "Components/CheckBox.h"
#include "Widget/SliderWidget.h"
#include "Manager/FTL_AssetManager.h"
#include "Struct/GameProperty.h"
#include "Manager/DelegateManager.h"
#include "Manager/AudioManager.h"
#include "Widget/ButtonWidget.h"
#include "Widget/TextBlockWidget.h"
#include "Widget/CheckBoxWidget.h"
#include "Widget/ComboBoxWidget.h"
#include "Manager/GameSettingsManager.h"
#include "Widget/ComboBoxMenuWidget.h"

#include "Manager/WidgetManager.h"

#include "GameState/FTL_GameStateBase.h"
#include "GameInstance/FTL_GameInstance.h"



#include "Components/Button.h"

#include "Components/TextBlock.h"




void UGameSettingsOptionWidget::NativeOnInitialized()
{
	Super::NativeOnInitialized();
	this->TextBlock->SetVisibility(ESlateVisibility::HitTestInvisible);
	this->ComboBox->OnOpenMenu.BindUObject(this, &UGameSettingsOptionWidget::OnComboBoxMenuOpen);
	this->ComboBox->OnSelectionChange.BindUObject(this, &UGameSettingsOptionWidget::OnComboBoxSelectionUpdate);
	this->TextBlock->SetBackGroundImageVisibility(ESlateVisibility::Hidden);
	this->Slider->OnValueChange.BindUObject(this, &UGameSettingsOptionWidget::OnSliderValueUpdate);


}





void UGameSettingsOptionWidget::NativePreConstruct()
{
	Super::NativePreConstruct();


}


void UGameSettingsOptionWidget::NativeConstruct()
{
	Super::NativeConstruct();
	

}


void UGameSettingsOptionWidget::NativeDestruct()
{
	Super::NativeDestruct();


}

void UGameSettingsOptionWidget::SetSliderCurrentPercent(int32 NewPercent)
{
	this->Slider->SetCurrentPercent(NewPercent);

}

int32 UGameSettingsOptionWidget::GetSliderCurrentPercent()
{
	return this->Slider->GetCurrentPercent();
}
void UGameSettingsOptionWidget::SetSliderHandleSize(const FVector2D& NewSize)
{
	
	this->Slider->SetHandleSize(NewSize);


}

void UGameSettingsOptionWidget::SetSliderStepSize(float NewSize)
{
	this->Slider->SetStepSize(NewSize);
}

void UGameSettingsOptionWidget::SetSliderValue(float NewValue)
{
	this->Slider->SetValue(NewValue);
}

float UGameSettingsOptionWidget::GetSliderValue()
{
	return this->Slider->GetValue();
}
void UGameSettingsOptionWidget::SetSliderMaxValue(float NewValue)
{
	this->Slider->SetMaxValue(NewValue);

}

void UGameSettingsOptionWidget::SetSliderMinValue(float NewValue)
{
	this->Slider->SetMinValue(NewValue);

}

void UGameSettingsOptionWidget::SetSliderFontSize(int32 NewSize)
{
	this->Slider->SetFontSize(NewSize);
}

void UGameSettingsOptionWidget::SetSliderFontColor(const FColor& NewColor)
{
	this->Slider->SetFontColor(NewColor);

}

void UGameSettingsOptionWidget::SetSliderBackGroundImage(UTexture2D* NewImage)
{
	this->Slider->SetBackGroundImage(NewImage);
}



void UGameSettingsOptionWidget::SetSliderBackGroundImageVisibility(const ESlateVisibility& NewVisibility)
{
	this->Slider->SetBackGroundImageVisibility(NewVisibility);
}



void UGameSettingsOptionWidget::SetSliderBarImage(UTexture2D* NewImage)
{
	this->Slider->SetBarImage(NewImage);

}
void UGameSettingsOptionWidget::SetSliderHandleImage(UTexture2D* NewImage)
{
	this->Slider->SetHandleImage(NewImage);

}
void UGameSettingsOptionWidget::SetSliderTextBlockVisibility(const ESlateVisibility& NewVisibility)
{
	this->Slider->SetTextBlockVisibility(NewVisibility);

}


void UGameSettingsOptionWidget::SetSliderTextBlockRelativePosition(const FVector2D& NewSize)
{
	this->Slider->SetTextBlockRelativePosition(NewSize);
}

void UGameSettingsOptionWidget::SetSliderText(const FString& NewText)
{
	this->Slider->SetText(NewText);
}
void UGameSettingsOptionWidget::SetSliderBackGroundImageColor(const FColor& NewColor)
{
	this->Slider->SetBackGroundImageColor(NewColor);
}
void UGameSettingsOptionWidget::SetSliderBarColor(const FColor& NewColor)
{
	this->Slider->SetBarColor(NewColor);
}
void UGameSettingsOptionWidget::SetSliderHandleColor(const FColor& NewColor)
{
	this->Slider->SetHandleColor(NewColor);
}
void UGameSettingsOptionWidget::SetSliderBarThickness(float NewThickness)
{
	this->Slider->SetBarThickness(NewThickness);

}

void UGameSettingsOptionWidget::SetSliderSize(const FVector2D& NewSize)
{

	this->Slider->SetWidgetSize(NewSize);

}

void UGameSettingsOptionWidget::SetSliderRelativePosition(const FVector2D& NewPosition)
{

	this->Slider->SetRelativePosition(NewPosition);

}

void UGameSettingsOptionWidget::SetComboBoxMenuRelativePosition(const FVector2D& NewPosition)
{
	this->ComboBox->SetMenuRelativePosition(NewPosition);

}


void UGameSettingsOptionWidget::SetText(const FText& NewText)
{
	this->TextBlock->SetText(NewText);

}

void UGameSettingsOptionWidget::SetFontSize(int32 NewSize)
{

	this->TextBlock->SetFontSize(NewSize);

}

void UGameSettingsOptionWidget::SetFontColor(const FColor& NewColor)
{
	this->TextBlock->SetFontColor(NewColor);

}

void UGameSettingsOptionWidget::SetText(const FString& NewText)
{
	this->TextBlock->SetText(FText::FromString(NewText));

}

void UGameSettingsOptionWidget::SetText(int32 Number)
{
	this->TextBlock->SetText(FText::FromString(FString::FromInt(Number)));
}


void UGameSettingsOptionWidget::SetTextRelativePosition(const FVector2D& NewPosition)
{
	this->TextBlock->SetRenderTranslation(NewPosition);

}


void UGameSettingsOptionWidget::SetOptionType(EGameSettingsOptionType NewType)
{
	if (NewType== EGameSettingsOptionType::None)
	{
		return;
	}
	switch (NewType)
	{

	case EGameSettingsOptionType::CheckBox:
		this->ComboBox->SetVisibility(ESlateVisibility::Collapsed);
		this->Slider->SetVisibility(ESlateVisibility::Collapsed);
		this->CheckBox->SetVisibility(ESlateVisibility::Visible);
		break;
	case EGameSettingsOptionType::ComboBox:
		this->CheckBox->SetVisibility(ESlateVisibility::Collapsed);
		this->Slider->SetVisibility(ESlateVisibility::Collapsed);
		this->ComboBox->SetVisibility(ESlateVisibility::Visible);
		break;
	case EGameSettingsOptionType::Slider:
		this->ComboBox->SetVisibility(ESlateVisibility::Collapsed);
		this->CheckBox->SetVisibility(ESlateVisibility::Collapsed);
		this->Slider->SetVisibility(ESlateVisibility::Visible);
		break;
	}

}

void UGameSettingsOptionWidget::SetFontInformation(const FSlateFontInfo& NewFont)
{
	this->TextBlock->SetFontInformation(NewFont);

}

void UGameSettingsOptionWidget::SetBackGroundImage(UTexture2D* NewImage)
{

	this->BackGroundImage->SetBrushFromTexture(NewImage);

}


void UGameSettingsOptionWidget::SetBackGroundImageVisibility(const ESlateVisibility& NewVisibility)
{
	this->BackGroundImage->SetVisibility(NewVisibility);
}


void UGameSettingsOptionWidget::SetBackGroundImageColor(const FColor& NewColor)
{
	this->BackGroundImage->SetBrushTintColor(NewColor);
}


void UGameSettingsOptionWidget::AddOptionToComboBox(const FString& Target, const FMargin& ItemPadding)
{
	
	this->ComboBox->AddOption(Target,ItemPadding);
	

}

void UGameSettingsOptionWidget::SetComboBoxMenuAnimationPlayRate(float NewPlayRate)
{
	this->ComboBox->SetMenuAnimationPlayRate(NewPlayRate);
}


void UGameSettingsOptionWidget::SetComboBoxMenuSize(const FVector2D& NewSize)
{
	this->ComboBox->SetMenuSize(NewSize);

}

void UGameSettingsOptionWidget::SetComboBoxFontInformation(const FSlateFontInfo& ButtonFontInformation, const FSlateFontInfo& ItemFontInformation)
{
	this->ComboBox->SetItemFontInformation(ItemFontInformation);
	this->ComboBox->SetButtonFontInformation(ButtonFontInformation);

}

void UGameSettingsOptionWidget::SetComboBoxFontSize(int32 ButtonFontSize, int32 ItemFontSize)
{

	this->ComboBox->SetButtonFontSize(ButtonFontSize);
	this->ComboBox->SetItemFontSize(ItemFontSize);

}

void UGameSettingsOptionWidget::SetComboBoxFontColor(const FColor& ButtonFontColor, const FColor& ItemFontColor)
{

	this->ComboBox->SetButtonFontColor(ButtonFontColor);
	this->ComboBox->SetItemFontColor(ItemFontColor);

}


void UGameSettingsOptionWidget::SetComboBoxSize(const FVector2D& NewSize)
{

	this->ComboBox->SetWidgetSize(NewSize);

}

void UGameSettingsOptionWidget::SetComboBoxRelativePosition(const FVector2D& NewPosition)
{

	this->ComboBox->SetRelativePosition(NewPosition);

}
void UGameSettingsOptionWidget::SetComboBoxItemBackGroundImageVisibility(const ESlateVisibility& NewVisibility)
{
	this->ComboBox->SetItemBackGroundImageVisibility(NewVisibility);
}

void UGameSettingsOptionWidget::SetComboBoxItemSize(const FVector2D& NewSize)
{

	this->ComboBox->SetItemSize(NewSize);

}

void UGameSettingsOptionWidget::SetComboBoxButtonText(const FString& Target)
{
	
	this->ComboBox->SetButtonText(Target);
	
}


void UGameSettingsOptionWidget::SetComboBoxDownArrowImage(UTexture2D* NewImage)
{

	this->ComboBox->SetDownArrowImage(NewImage);
}

void UGameSettingsOptionWidget::SetComboBoxMenuBackGroundImage(UTexture2D* NewImage)
{

	this->ComboBox->SetMenuBackGroundImage(NewImage);

}

void UGameSettingsOptionWidget::SetComboBoxMenuBackGroundImageColor(const FColor& NewColor)
{
	this->ComboBox->SetMenuBackGroundImageColor(NewColor);


}


void UGameSettingsOptionWidget::SetComboBoxItemBackGroundImage(UTexture2D* NewImage)
{

	this->ComboBox->SetItemBackGroundImage(NewImage);

}


void UGameSettingsOptionWidget::SetComboBoxButtonBackGroundImage(UTexture2D* NewImage)
{
	this->ComboBox->SetButtonBackGroundImage(NewImage);

}

void UGameSettingsOptionWidget::SetComboBoxButtonTextRelativePosition(const FVector2D& NewPosition)
{
	this->ComboBox->SetButtonTextRelativePosition(NewPosition);

}
void UGameSettingsOptionWidget::SetComboBoxItemBackGroundImageColor(const FColor& NewColor)
{
	this->ComboBox->SetItemBackGroundImageColor(NewColor);

}
void UGameSettingsOptionWidget::SetComboBoxDownArrowImageColor(const FColor& NewColor)
{
	this->ComboBox->SetDownArrowImageColor(NewColor);

}

void UGameSettingsOptionWidget::SetComboBoxDownArrowSize(const FVector2D& NewSize)
{
	this->ComboBox->SetDownArrowSize(NewSize);

}


void UGameSettingsOptionWidget::SetComboBoxDownArrowRelativePosition(const FVector2D& NewPosition)
{
	this->ComboBox->SetDownArrowRelativePosition(NewPosition);

}


void UGameSettingsOptionWidget::SetComboBoxButtonBackGroundImageColor(const FColor& NewColor)
{
	this->ComboBox->SetButtonBackGroundImageColor(NewColor);

}

void UGameSettingsOptionWidget::ShowComboBoxMenuScrollBar()
{
	this->ComboBox->ShowMenuScrollBar();
}


void UGameSettingsOptionWidget::HideComboBoxMenuScrollBar()
{
	this->ComboBox->HideMenuScrollBar();


}

UComboBoxMenuWidget* UGameSettingsOptionWidget::GetComboBoxMenu()
{
	return this->ComboBox->GetMenu();
}



void UGameSettingsOptionWidget::OpenComboBoxMenu(const FVector2D& Size, const FAnchorData& AnchorData)
{
	this->ComboBox->OpenMenu(Size, AnchorData);

}


void UGameSettingsOptionWidget::CloseComboBoxMenu()
{
	this->ComboBox->CloseMenu();


}




void UGameSettingsOptionWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	if (this->SizeBox->GetRenderOpacity() == 1.0f)
	{
	}
	else
	{

	}


}


void UGameSettingsOptionWidget::OnComboBoxMenuOpen()
{
	this->OnOpenComboBoxMenu.ExecuteIfBound();
}


void UGameSettingsOptionWidget::OnComboBoxSelectionUpdate(FString SelectedItem, ESelectInfo::Type SelectionInfo)
{
	
	this->OnComboBoxSelectionChange.ExecuteIfBound(SelectedItem,SelectionInfo);

}

void UGameSettingsOptionWidget::OnSliderValueUpdate(float Value)
{
	this->OnSliderValueChange.ExecuteIfBound(Value);

}


void UGameSettingsOptionWidget::OnCheckBoxStateChange(bool IsCheck)
{


}















