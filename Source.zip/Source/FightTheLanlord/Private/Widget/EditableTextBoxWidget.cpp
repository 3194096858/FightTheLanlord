﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "Widget/EditableTextBoxWidget.h"


#include "Components/SizeBox.h"
#include "Components/Image.h"
#include "Components/EditableTextBox.h"

#include "Manager/FTL_AssetManager.h"
#include "Struct/GameProperty.h"
#include "Manager/DelegateManager.h"
#include "Manager/AudioManager.h"
#include "Widget/ButtonWidget.h"
#include "Widget/TextBlockWidget.h"

#include "Manager/WidgetManager.h"

#include "GameState/FTL_GameStateBase.h"
#include "GameInstance/FTL_GameInstance.h"





void UEditableTextBoxWidget::NativeOnInitialized()
{
	Super::NativeOnInitialized();
	FEditableTextBoxStyle Style;
	FSlateFontInfo Font;
	Font.FontObject = GetGameInstance()->GetAssetManager()->WidgetAsset.Font;
	Style.SetFont(Font);
	Style.BackgroundImageFocused.TintColor = FColor(0.0f);
	Style.BackgroundImageHovered.TintColor = FColor(0.0f);
	Style.BackgroundImageNormal.TintColor = FColor(0.0f);

	this->EditableTextBox->WidgetStyle = Style;
	this->EditableTextBox->OnTextCommitted.AddDynamic(this, &UEditableTextBoxWidget::OnTextSubmit);


}





void UEditableTextBoxWidget::NativePreConstruct()
{
	Super::NativePreConstruct();


}


void UEditableTextBoxWidget::NativeConstruct()
{
	Super::NativeConstruct();
	


}


void UEditableTextBoxWidget::NativeDestruct()
{
	Super::NativeDestruct();


}



void UEditableTextBoxWidget::SetBackGroundImage(UTexture2D* NewBackGround)
{
	//this->EditableTextBox->WidgetStyle.SetBackgroundImageFocused();
	this->BackGroundImage->SetBrushFromTexture(NewBackGround);

}


void UEditableTextBoxWidget::SetBackGroundImageColor(const FColor& NewColor)
{

	this->BackGroundImage->SetBrushTintColor(NewColor);

}




void UEditableTextBoxWidget::SetHintText(const FString& NewText)
{
	this->EditableTextBox->SetHintText(FText::FromString(NewText));

}

FString UEditableTextBoxWidget::GetHintText()
{
	return this->EditableTextBox->GetHintText().ToString();

}


void UEditableTextBoxWidget::SetText(const FText& NewText)
{
	this->EditableTextBox->SetText(NewText);

}

void UEditableTextBoxWidget::SetText(const FString& NewText)
{
	this->EditableTextBox->SetText(FText::FromString(NewText));


}

void UEditableTextBoxWidget::SetFontSize(int32 NewSize)
{
	FEditableTextBoxStyle Style;
	FSlateFontInfo Font;
	Style = this->EditableTextBox->WidgetStyle;
	Font = Style.TextStyle.Font;
	Font.Size = NewSize;
	Style.SetFont(Font);
	this->EditableTextBox->WidgetStyle = Style;
}

void UEditableTextBoxWidget::SetFontColor(const FColor& NewColor)
{
	FEditableTextBoxStyle Style;
	Style = this->EditableTextBox->WidgetStyle;
	Style.TextStyle.SetColorAndOpacity(NewColor);
	this->EditableTextBox->WidgetStyle = Style;

}

void UEditableTextBoxWidget::SetFontInformation(const FSlateFontInfo& NewFont)
{
	FEditableTextBoxStyle Style;
	Style.SetFont(NewFont);
	this->EditableTextBox->WidgetStyle = Style;


}



void UEditableTextBoxWidget::SetBackGroundImageSlateBrush(const FSlateBrush& NewSlateBrush)
{
	this->BackGroundImage->SetBrush(NewSlateBrush);

}



void UEditableTextBoxWidget::SetBackGroundImageVisibility(const ESlateVisibility& NewVisibility)
{
	this->BackGroundImage->SetVisibility(NewVisibility);


}

void UEditableTextBoxWidget::SetTextBlockVisibility(const ESlateVisibility& NewVisibility)
{


}



void UEditableTextBoxWidget::SetTextRelativePosition(const FVector2D& NewPosition)
{

}




void UEditableTextBoxWidget::GetText(FText& Result)
{
	Result = this->EditableTextBox->GetText();

}

void UEditableTextBoxWidget::GetText(FString& Result)
{
	Result = this->EditableTextBox->GetText().ToString();

}

void UEditableTextBoxWidget::GetText(int32& Result)
{

}

void UEditableTextBoxWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	Super::OnAnimationFinished_Implementation(Animation);
	if (this->SizeBox->GetRenderOpacity() == 1.0f)
	{
	}
	else
	{

	}


}


//
//void UStartMenu::OnClickStartGameButton()
//{
//	///PlayAnimation(this->WidgetAnimation,0.0f,1,EUMGSequencePlayMode::Reverse,3.0f);
//	GetGameInstance()->GetWidgetManager()->CloseStartMenu();
//
//
//}


void UEditableTextBoxWidget::OnTextSubmit(const FText& Text, ETextCommit::Type CommitMethod)
{
	this->OnTextCommit.ExecuteIfBound(Text,CommitMethod);

}

