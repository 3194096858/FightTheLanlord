﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "Widget/LoadingWidget.h"


#include "Components/SizeBox.h"
#include "Components/Image.h"
#include "Components/TextBlock.h"
#include "Components/CircularThrobber.h"

#include "Manager/FTL_AssetManager.h"
#include "Struct/GameProperty.h"
#include "Manager/DelegateManager.h"
#include "Manager/AudioManager.h"
#include "Widget/ButtonWidget.h"
#include "Widget/ResourcePanel.h"
#include "Manager/WidgetManager.h"

#include "Widget/TextBlockWidget.h"

#include "GameState/FTL_GameStateBase.h"
#include "GameInstance/FTL_GameInstance.h"
#include "Manager/FTL_TimerManager.h"




void ULoadingWidget::NativeOnInitialized()
{
	Super::NativeOnInitialized();
	this->BackGroundImage->SetBrushTintColor(FColor::Black);
	this->SizeBox->SetRenderOpacity(0.0f);

}


void ULoadingWidget::NativeConstruct()
{
	Super::NativeConstruct();


}


void ULoadingWidget::NativePreConstruct()
{
	Super::NativePreConstruct();

}


void ULoadingWidget::NativeDestruct()
{
	Super::NativeDestruct();


}

void ULoadingWidget::PlayLoadingAnimation(bool IsForward)
{
	if (this->WidgetAnimation ==nullptr)
	{
		return;
	}
	float Speed = 1.0f;
	if (IsForward == true)
	{
		this->SizeBox->SetRenderOpacity(0.0f);
		this->LoadingIcon->SetVisibility(ESlateVisibility::HitTestInvisible);
		PlayAnimation(this->WidgetAnimation,0.0f,1.0f,EUMGSequencePlayMode::Forward,Speed);
	}
	else
	{
		this->SizeBox->SetRenderOpacity(1.0f);
		this->LoadingIcon->SetVisibility(ESlateVisibility::Collapsed);
		PlayAnimation(this->WidgetAnimation, 0.0f, 1.0f, EUMGSequencePlayMode::Reverse, Speed);

	}

}



void ULoadingWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	////Super::OnAnimationFinished_Implementation(Animation);
	if (this->SizeBox->GetRenderOpacity() == 1.0f)
	{
		GetGameInstance()->GetDelegateManager()->OnPlayLoadingAnimationComplete.Broadcast(true);
		//GEngine->AddOnScreenDebugMessage(-1, 11.f, FColor::Red, FString::Printf(TEXT("Play Loading Animation   Forward !!!! ")));

	}
	else
	{
		GetGameInstance()->GetDelegateManager()->OnPlayLoadingAnimationComplete.Broadcast(false);
		///GEngine->AddOnScreenDebugMessage(-1, 11.f, FColor::Red, FString::Printf(TEXT("Play Loading Animation   Backward !!!! ")));

	}


}
