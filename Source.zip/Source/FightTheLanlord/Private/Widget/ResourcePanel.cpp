﻿

#include "Widget/ResourcePanel.h"



#include "Components/Button.h"
#include "Components/Image.h"
#include "GameInstance/FTL_GameInstance.h"

#include "Components/TextBlock.h"
#include "Widget/TextBlockWidget.h"
#include "Manager/WidgetManager.h"
#include "Widget/ButtonWidget.h"

#include "Manager/AudioManager.h"
#include "Manager/FTL_AssetManager.h"
#include "GameState/FTL_GameStateBase.h"



void UResourcePanel::NativeOnInitialized()
{
	Super::NativeOnInitialized();
	float PlayRate  = GetGameInstance()->GetGameState()->GameDefaultData.Widget.ResourcePanelAnimationPlayRate;
	FResourcePanelData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.ResourcePanel;
	FResourcePanelAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.ResourcePanel;
	GetGameInstance()->GetWidgetManager()->InitializeTextBlock(this->BeanTextBlock, Data.BeanTextBlock, Asset.BeanTextBlock);
	SetBeanIcon(Asset.BeanIcon.Image);
	SetBeanIconColor(Data.BeanIcon.Color);
	SetBeanIconRelativePosition(Data.BeanIcon.RelativePosition);
	SetBeanIconSize(Data.BeanIcon.Size);
	SetRelativePosition(Data.RelativePosition);
	SetAnimationPlayRate(PlayRate);


}

void UResourcePanel::NativeConstruct()
{
	Super::NativeConstruct();


}


void UResourcePanel::NativePreConstruct()
{
	Super::NativePreConstruct();
	

}


void UResourcePanel::NativeDestruct()
{
	Super::NativeDestruct();


}



void UResourcePanel::SetBeanIcon(UTexture2D* NewImage)
{
    this->BeanIcon->SetBrushFromTexture(NewImage);


}



void UResourcePanel::SetBeanIconColor(const FColor& NewColor)
{
	
	this->BeanIcon->SetBrushTintColor(NewColor);

}


void UResourcePanel::SetBeanIconSize(const FVector2D& NewSize)
{
	this->BeanIcon->SetBrushSize(NewSize);


}



void UResourcePanel::SetBeanIconRelativePosition(const FVector2D& NewPosition)
{

	this->BeanIcon->SetRenderTranslation(NewPosition);

}

void UResourcePanel::SetBeanTextBlockText(const FString& NewText)
{
	this->BeanTextBlock->SetText(NewText);
}

void UResourcePanel::SetBeanTextBlockFontColor(const FColor& NewColor)
{
	this->BeanTextBlock->SetFontColor(NewColor);

}


void UResourcePanel::SetBeanTextBlockFontSize(int32 NewSize)
{
	this->BeanTextBlock->SetFontSize(NewSize);

}

void UResourcePanel::SetBeanTextBlockTextRelativePosition(const FVector2D& NewPosition)
{
	this->BeanTextBlock->SetRelativePosition(NewPosition);

}


void UResourcePanel::SetBeanTextBlockBackGroundImage(UTexture2D* NewImage)
{
	this->BeanTextBlock->SetBackGroundImage(NewImage);


}


void UResourcePanel::SetBeanTextBlockBackGroundImageColor(const FColor& NewColor)
{
	this->BeanTextBlock->SetBackGroundImageColor(NewColor);


}



void UResourcePanel::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	Super::OnAnimationFinished_Implementation(Animation);



}






