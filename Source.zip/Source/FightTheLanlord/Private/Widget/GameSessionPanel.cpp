﻿#include "Widget/GameSessionPanel.h"


#include "Components/SizeBox.h"
#include "Components/Image.h"
#include "Components/ScrollBox.h"
#include "Components/ScrollBoxSlot.h"

#include "Manager/FTL_AssetManager.h"
#include "Struct/GameProperty.h"
#include "Manager/DelegateManager.h"
#include "Manager/AudioManager.h"
#include "Widget/ButtonWidget.h"
#include "Widget/TextBlockWidget.h"
#include "Manager/GameSessionManager.h"
#include "Widget/SessionWidget.h"
#include "Widget/EditableTextBoxWidget.h"

#include "Manager/WidgetManager.h"
#include "GameState/FTL_GameStateBase.h"
#include "GameInstance/FTL_GameInstance.h"





void UGameSessionPanel::NativeOnInitialized()
{
	Super::NativeOnInitialized();
	float PlayRate  = GetGameInstance()->GetGameState()->GameDefaultData.Widget.GameSessionPanelAnimationPlayRate;
	FGameSessionPanelData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.GameSessionPanel;
	FGameSessionPanelAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.GameSessionPanel;
	this->BackGroundImage->SetBrushFromTexture(Asset.BackGroundImage.Image);
	this->BackGroundImage->SetBrushTintColor(Data.BackGroundImage.Color);
	InitializeCreateButton();
	InitializeSearchButton();
	InitializeEditableTextBox();
	SetWidgetSize(Data.Size);
	SetRelativePosition(Data.RelativePosition);
	SetAnimationPlayRate(PlayRate);
	FScrollBoxStyle Style = this->ScrollBox->GetWidgetStyle();
	FSlateBrush ScrollBoxSlateBrush;
	ScrollBoxSlateBrush.SetImageSize(FVector2D(0.0f));
	Style.SetBottomShadowBrush(ScrollBoxSlateBrush);
	Style.SetTopShadowBrush(ScrollBoxSlateBrush);
	this->ScrollBox->SetWidgetStyle(Style);
	this->ScrollBox->SetScrollBarVisibility(ESlateVisibility::Collapsed);
	this->CreateButton->OnClick.BindUObject(this, &UGameSessionPanel::OnClickCreateButton);
	this->SearchButton->OnClick.BindUObject(this, &UGameSessionPanel::OnClickSearchButton);
	GetGameInstance()->GetGameSessionManager()->OnCreateSession.AddUObject(this,&UGameSessionPanel::OnCreateSession);
	GetGameInstance()->GetGameSessionManager()->OnSearchSession.AddUObject(this, &UGameSessionPanel::OnSearchSession);
	GetGameInstance()->GetGameSessionManager()->OnJoinSessionComplete.AddUObject(this, &UGameSessionPanel::OnJoinSessionComplete);
	GetGameInstance()->GetGameSessionManager()->OnDestroySessionComplete.AddUObject(this, &UGameSessionPanel::OnDestroySessionComplete);
	GetGameInstance()->GetGameSessionManager()->OnCreateSessionComplete.AddUObject(this, &UGameSessionPanel::OnCreateSessionComplete);
	GetGameInstance()->GetGameSessionManager()->OnSearchSessionComplete.AddUObject(this, &UGameSessionPanel::OnSearchSessionComplete);
	GetGameInstance()->GetDelegateManager()->OnGameSessionPanelOpen.AddUObject(this, &UGameSessionPanel::OnGameSessionPanelOpen);
	GetGameInstance()->GetDelegateManager()->OnGameSessionPanelClose.AddUObject(this, &UGameSessionPanel::OnGameSessionPanelClose);

}





void UGameSessionPanel::NativePreConstruct()
{
	Super::NativePreConstruct();


}


void UGameSessionPanel::NativeConstruct()
{
	Super::NativeConstruct();
	


}


void UGameSessionPanel::NativeDestruct()
{
	Super::NativeDestruct();
	RemoveAllInvalidSession();
	ShowAllSession();
	this->EditableTextBox->SetText(TEXT(""));
}


void UGameSessionPanel::InitializeCreateButton()
{
	FButtonWidgetData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.GameSessionPanel.CreateButton;
	FButtonWidgetAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.GameSessionPanel.CreateButton;
	GetGameInstance()->GetWidgetManager()->InitializeButton(this->CreateButton, Data, Asset);
}


void UGameSessionPanel::InitializeSearchButton()
{

	FButtonWidgetData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.GameSessionPanel.SearchButton;
	FButtonWidgetAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.GameSessionPanel.SearchButton;
	GetGameInstance()->GetWidgetManager()->InitializeButton(this->SearchButton, Data, Asset);

}

void UGameSessionPanel::InitializeEditableTextBox()
{
	FEditableTextBoxWidgetData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.GameSessionPanel.EditableTextBox;
	FEditableTextBoxWidgetAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.GameSessionPanel.EditableTextBox;

	GetGameInstance()->GetWidgetManager()->InitializeEditableTextBox(this->EditableTextBox, Data, Asset);

}


TArray<USessionWidget*> UGameSessionPanel::GetAllSession()
{
	TArray<USessionWidget*> SessionArray;

	for (auto& Element : this->ScrollBox->GetAllChildren())
	{
		SessionArray.Add(Cast<USessionWidget>(Element));
	}
	return SessionArray;

}

void UGameSessionPanel::AddSession(USessionWidget* Session)
{
	UPanelSlot* PanelSlot = nullptr;
	UScrollBoxSlot* ScrollBoxSlot = nullptr;
	FMargin SessionPadding = GetGameInstance()->GetGameState()->GameDefaultData.Widget.GameSessionPanel.SessionPadding;
	PanelSlot = this->ScrollBox->AddChild(Session);
	ScrollBoxSlot = Cast<UScrollBoxSlot>(PanelSlot);
	ScrollBoxSlot->SetPadding(SessionPadding);
	if (Session->GetVisibility() != ESlateVisibility::Visible)
	{
		Session->SetVisibility(ESlateVisibility::Visible);
	}


}

void UGameSessionPanel::RemoveSession(USessionWidget* Session)
{
	if (this->ScrollBox->HasChild(Session) == true)
	{
		this->ScrollBox->RemoveChild(Session);
	}




}

bool UGameSessionPanel::GetHasSession(const FString& SessionName)
{
	bool HasSession = false;
	TArray<USessionWidget*> SessionArray = GetAllSession();
	for (auto& Element: SessionArray)
	{
		if (Element->GetSessionName() == SessionName)
		{
			HasSession = true;
			return HasSession;
		}
	}
	return HasSession;

}

USessionWidget* UGameSessionPanel::GetSession(const FString& SessionName)
{
	for (auto& Element : GetAllSession())
	{
		if (Element->GetSessionName() == SessionName)
		{
			return Element;
		
		}

	}
	return nullptr;
}


void UGameSessionPanel::RemoveAllInvalidSession()
{
	for (auto& Element : GetAllSession())
	{
		if (Element->GetSessionName() == TEXT("None"))
		{
			Element->SetDeleteButtonVisibility(ESlateVisibility::Visible);
			GetGameInstance()->GetWidgetManager()->ReturnSessionWidget(Element);
			RemoveSession(Element);
		}
	}

}


void UGameSessionPanel::ShowAllSession()
{
	for (auto& Element : GetAllSession())
	{
		Element->SetVisibility(ESlateVisibility::Visible);
	}


}

void UGameSessionPanel::HideAllSession()
{
	for (auto& Element : GetAllSession())
	{
		Element->SetVisibility(ESlateVisibility::Collapsed);
	}

}

void UGameSessionPanel::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	Super::OnAnimationFinished_Implementation(Animation);
	if (this->SizeBox->GetRenderOpacity() == 1.0f)
	{
	}
	else
	{

	}


}


void UGameSessionPanel::OnClickCreateButton()
{
	int32 Number = GetGameInstance()->GetGameSessionManager()->GetAllLocalSession().Num();
	if (Number>=3)
	{
		GEngine->AddOnScreenDebugMessage(-1,11.0f,FColor::Blue,TEXT("SessionNumber >= 3"));
		return;
	}

	GetGameInstance()->GetGameSessionManager()->CreateSession();

}


void UGameSessionPanel::OnClickSearchButton()
{
	FString Input;
	USessionWidget* Session = nullptr;
	this->EditableTextBox->GetText(Input);
	RemoveAllInvalidSession();
	HideAllSession();
	if (Input == TEXT(""))
	{
		ShowAllSession();
		GetGameInstance()->GetGameSessionManager()->SearchSession();
		this->SearchButton->SetVisibility(ESlateVisibility::HitTestInvisible);
		this->SearchButton->SetRenderOpacity(0.5f);
	}
	else
	{
		Session = GetSession(Input);
		if (Session == nullptr)
		{
			GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, FString::Printf(TEXT("No Find Session: %s !!!!!!!!"), *Input));
			return;
		}
		Session->SetVisibility(ESlateVisibility::Visible);
	}

}

void UGameSessionPanel::OnCreateSession()
{
	

}


void UGameSessionPanel::OnSearchSession()
{
	

}

void UGameSessionPanel::OnCreateSessionComplete(const FName& SessionName)
{
	USessionWidget* Session = nullptr;
	Session = GetGameInstance()->GetWidgetManager()->GetSessionWidget(GetGameInstance());
	if (Session == nullptr)
	{
		return;
	}
	AddSession(Session);
	Session->SetSessionName(SessionName.ToString());

	

}


void UGameSessionPanel::OnSearchSessionComplete(TSharedPtr<FOnlineSessionSearch> SessionSearch)
{
	if (SessionSearch == nullptr)
	{
		return;
	}
	FString Name;
	USessionWidget* Session = nullptr;
	for (auto& Element : SessionSearch->SearchResults)
	{
		Name = GetGameInstance()->GetGameSessionManager()->GetRemoteSessionName(&Element);
		if (GetHasSession(Name) == true)
		{
			continue;
		}
		Session = GetGameInstance()->GetWidgetManager()->GetSessionWidget(GetGameInstance());
		if (Session == nullptr)
		{
			return;
		}
		AddSession(Session);
		Session->SetSessionName(Name);
		Session->SetDeleteButtonVisibility(ESlateVisibility::Collapsed);

	}
	this->SearchButton->SetVisibility(ESlateVisibility::Visible);
	this->SearchButton->SetRenderOpacity(1.0f);
	
	
}


void UGameSessionPanel::OnJoinSessionComplete(const FName& SessionName)
{


}

void UGameSessionPanel::OnDestroySessionComplete(const FName& SessionName)
{

	
}




void UGameSessionPanel::OnGameSessionPanelOpen()
{

	FVector2D Size = GetGameInstance()->GetGameState()->GameDefaultData.Widget.GameSessionPanel.Size;
	FAnchorData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.AnchorData;
	GetGameInstance()->GetWidgetManager()->OpenGameSessionPanel(Size,Data);



}

void UGameSessionPanel::OnGameSessionPanelClose()
{
	GetGameInstance()->GetWidgetManager()->CloseGameSessionPanel();




}

