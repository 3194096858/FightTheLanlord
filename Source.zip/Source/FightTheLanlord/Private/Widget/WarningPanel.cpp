﻿#include "Widget/WarningPanel.h"
#include "Components/SizeBox.h"
#include "Components/Image.h"
#include "Manager/FTL_TimerManager.h"

#include "Manager/FTL_AssetManager.h"
#include "Struct/GameProperty.h"
#include "Manager/DelegateManager.h"
#include "Manager/AudioManager.h"
#include "Widget/ButtonWidget.h"
#include "Widget/TextBlockWidget.h"
#include "Manager/GameSessionManager.h"

#include "Manager/WidgetManager.h"

#include "GameState/FTL_GameStateBase.h"
#include "GameInstance/FTL_GameInstance.h"
#include "PlayerController/PlayerControllerBase.h"

#include "PlayerState/FTL_PlayerStateBase.h"
#include "Manager/LevelManager.h"
#include "OnlineSessionSettings.h"
#include "OnlineSubsystem.h"
#include "Interfaces/OnlineSessionInterface.h"



void UWarningPanel::NativeOnInitialized()
{
	Super::NativeOnInitialized();
	FTextBlockWidgetData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.WarningPanel.TextBlock;
	FTextBlockWidgetAsset Asset;
	UTexture2D* Image = GetGameInstance()->GetAssetManager()->WidgetAsset.WarningPanel.BackGroundImage.Image;
	float PlayRate = GetGameInstance()->GetGameState()->GameDefaultData.Widget.WarningPanelAnimationPlayRate;
	SetAnimationPlayRate(PlayRate);
	this->BackGroundImage->SetBrushFromTexture(Image);
	GetGameInstance()->GetWidgetManager()->InitializeTextBlock(this->TextBlock, Data, Asset);
	InitializeConfirmButton();
	InitializeCancelButton();
	this->ConfirmButton->OnClick.BindUObject(this, &UWarningPanel::OnClickConfirmButton);
	this->CancelButton->OnClick.BindUObject(this, &UWarningPanel::OnClickCancelButton);
	GetGameInstance()->GetDelegateManager()->OnWarningPanelOpen.AddUObject(this, &UWarningPanel::OnWarningPanelOpen);
	GetGameInstance()->GetDelegateManager()->OnWarningPanelClose.AddUObject(this, &UWarningPanel::OnWarningPanelClose);

}





void UWarningPanel::NativePreConstruct()
{
	Super::NativePreConstruct();


}


void UWarningPanel::NativeConstruct()
{
	Super::NativeConstruct();

}


void UWarningPanel::NativeDestruct()
{
	Super::NativeDestruct();

}



void UWarningPanel::InitializeConfirmButton()
{
	FButtonWidgetData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.WarningPanel.ConfirmButton;
	FButtonWidgetAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.WarningPanel.ConfirmButton;
	GetGameInstance()->GetWidgetManager()->InitializeButton(this->ConfirmButton, Data, Asset);


}

void UWarningPanel::InitializeCancelButton()
{
	FButtonWidgetData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.WarningPanel.CancelButton;
	FButtonWidgetAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.WarningPanel.CancelButton;
	GetGameInstance()->GetWidgetManager()->InitializeButton(this->CancelButton, Data, Asset);



}


void UWarningPanel::SetDescription(const FString& NewDescription)
{
	this->TextBlock->SetText(NewDescription);


}
void UWarningPanel::QuitSession()
{
	GetGameInstance()->GetGameSessionManager()->QuitCurrentSession();
	GetWorld()->GetTimerManager().ClearTimer(this->QuitSessionTimerHandle);

}





void UWarningPanel::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	Super::OnAnimationFinished_Implementation(Animation);

	if (this->SizeBox->GetRenderOpacity() == 1.0f)
	{
	}
	else
	{

	}


}



void UWarningPanel::OnClickConfirmButton()
{
	FString Description;
	this->TextBlock->GetText(Description);
	FName WarningName = GetGameInstance()->GetWidgetManager()->GetWarningName(Description);
	if (WarningName == TEXT("QuitGame"))
	{
		GetGameInstance()->GetDelegateManager()->OnGameQuit.Broadcast();
	}

	if (WarningName == TEXT("ResetSettings"))
	{
	}
	if (WarningName == TEXT("JoinSession"))
	{
		FString SelectedSession = GetGameInstance()->GetGameSessionManager()->GetSelectedSessionName();
		GetGameInstance()->GetGameSessionManager()->CheckIsLocalSession(SelectedSession) ? GetGameInstance()->JoinSelectedSession(true) : GetGameInstance()->JoinSelectedSession(false);
		
	}

	if (WarningName == TEXT("DestroySession"))
	{
		GetGameInstance()->GetGameSessionManager()->DestroySelectedSession();

	}

	if (WarningName == TEXT("QuitSession"))
	{
		if (GetIsInServer() == true)
		{
			APlayerControllerBase* Controller = nullptr;
			QuitSessionTimerID = GetGameInstance()->GetTimerManager()->GetRandomID();
			for (auto& Element : GetGameInstance()->GetGameState()->PlayerArray)
			{
				Controller = Cast<APlayerControllerBase>(Element->GetPlayerController());
				if (Controller != GetOwningPlayer())
				{
					Controller->Client_QuitSession();
				}

			}
			GetWorld()->GetTimerManager().SetTimer(this->QuitSessionTimerHandle,this,&UWarningPanel::QuitSession,1.0f,false);
		}
		else
		{
			GetGameInstance()->GetGameSessionManager()->QuitCurrentSession();

		}

	}


	GetGameInstance()->GetWidgetManager()->CloseWarningPanel();

}




void UWarningPanel::OnClickCancelButton()
{
	GetGameInstance()->GetWidgetManager()->CloseWarningPanel();



}





void UWarningPanel::OnWarningPanelOpen(const FString& WarningName)
{
	FVector2D Size = GetGameInstance()->GetGameState()->GameDefaultData.Widget.WarningPanel.Size;
	FAnchorData AnchorData = GetGameInstance()->GetGameState()->GameDefaultData.Widget.AnchorData;
	GetGameInstance()->GetWidgetManager()->OpenWarningPanel(Size, AnchorData, FName(WarningName));

	
}

void UWarningPanel::OnWarningPanelClose()
{

	GetGameInstance()->GetWidgetManager()->CloseWarningPanel();



}

