﻿#include "Widget/PlayerPanel.h"


#include "Components/Button.h"
#include "Components/Image.h"
#include "Components/TextBlock.h"
#include "Widget/TextBlockWidget.h"
#include "GameInstance/FTL_GameInstance.h"
#include "Manager/AudioManager.h"
#include "Manager/FTL_AssetManager.h"
#include "GameState/FTL_GameStateBase.h"
#include "Widget/PlayerWidget.h"

#include "Manager/DelegateManager.h"
#include "PlayerState/FTL_PlayerStateBase.h"

#include "Manager/WidgetManager.h"


void UPlayerPanel::NativeOnInitialized()
{
	Super::NativeOnInitialized();
	
	float PlayRate = GetGameInstance()->GetGameState()->GameDefaultData.Widget.PlayerPanelAnimationPlayRate;
	FPlayerPanelData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.PlayerPanel;
	FPlayerPanelAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.PlayerPanel;
	SetAnimationPlayRate(PlayRate);
	SetWidgetSize(Data.Size);
	SetRelativePosition(Data.RelativePosition);
	InitializeLocalPlayerWidget();
	InitializeLeftPlayerWidget();
	InitializeRightPlayerWidget();
	this->LocalPlayer->SetCardNumberTextBlockVisibility(ESlateVisibility::Collapsed);
	this->LeftPlayer->SetCardNumberTextBlockVisibility(ESlateVisibility::Hidden);
	this->RightPlayer->SetCardNumberTextBlockVisibility(ESlateVisibility::Hidden);

	GetGameInstance()->GetDelegateManager()->OnLocalClientPlayerStateCompleteInitialize.AddUObject(this, &UPlayerPanel::OnLocalClientPlayerStateCompleteInitialize);
	GetGameInstance()->GetDelegateManager()->OnLocalClientPlayerControllerCompleteInitialize.AddUObject(this, &UPlayerPanel::OnLocalClientPlayerControllerCompleteInitialize);
	GetGameInstance()->GetDelegateManager()->OnLocalClientGameStateCompleteInitialize.AddUObject(this, &UPlayerPanel::OnLocalClientGameStateCompleteInitialize);
	GetGameInstance()->GetDelegateManager()->OnPlayerPanelOpen.AddUObject(this, &UPlayerPanel::OnPlayerPanelOpen);
	GetGameInstance()->GetDelegateManager()->OnPlayerPanelClose.AddUObject(this, &UPlayerPanel::OnPlayerPanelClose);
	GetGameInstance()->GetDelegateManager()->OnDealCardComplete.AddUObject(this,&UPlayerPanel::OnDealCardComplete);
	GetGameInstance()->GetDelegateManager()->OnGameOver.AddUObject(this, &UPlayerPanel::OnGameOver);

}

void UPlayerPanel::NativePreConstruct()
{
	Super::NativePreConstruct();
	if (GetOwningPlayer()->HasAuthority() == true)
	{
		AFTL_PlayerStateBase* PlayerState = GetOwningPlayer()->GetPlayerState<AFTL_PlayerStateBase>();
		InitializePlayerID(PlayerState->GetID());
	}

}


void UPlayerPanel::NativeConstruct()
{
	Super::NativeConstruct();
	
	
}


void UPlayerPanel::NativeDestruct()
{
	Super::NativeDestruct();


}

void UPlayerPanel::InitializeLocalPlayerWidget()
{
	FPlayerWidgetData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.PlayerPanel.LocalPlayer;
	FPlayerWidgetAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.PlayerPanel.LocalPlayer;
	this->LocalPlayer->InitializeNameTextBlock(Data.NameTextBlock,Asset.NameTextBlock);
	this->LocalPlayer->InitializeCardNumberTextBlock(Data.CardNumberTextBlock, Asset.CardNumberTextBlock);
	this->LocalPlayer->SetWidgetSize(Data.Size);
	this->LocalPlayer->SetRelativePosition(Data.RelativePosition);

}

void UPlayerPanel::InitializeLeftPlayerWidget()
{
	FPlayerWidgetData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.PlayerPanel.LeftPlayer;
	FPlayerWidgetAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.PlayerPanel.LeftPlayer;
	this->LeftPlayer->InitializeNameTextBlock(Data.NameTextBlock, Asset.NameTextBlock);
	this->LeftPlayer->InitializeCardNumberTextBlock(Data.CardNumberTextBlock, Asset.CardNumberTextBlock);
	this->LeftPlayer->SetWidgetSize(Data.Size);
	this->LeftPlayer->SetRelativePosition(Data.RelativePosition);

}

void UPlayerPanel::InitializeRightPlayerWidget()
{
	FPlayerWidgetData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.PlayerPanel.RightPlayer;
	FPlayerWidgetAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.PlayerPanel.RightPlayer;
	this->RightPlayer->InitializeNameTextBlock(Data.NameTextBlock, Asset.NameTextBlock);
	this->RightPlayer->InitializeCardNumberTextBlock(Data.CardNumberTextBlock, Asset.CardNumberTextBlock);
	this->RightPlayer->SetWidgetSize(Data.Size);
	this->RightPlayer->SetRelativePosition(Data.RelativePosition);

}

void UPlayerPanel::InitializePlayerID(int32 LocalPlayerID)
{
	SetLocalPlayerID(LocalPlayerID);
	switch (LocalPlayerID)
	{
	case 1:
		SetLeftPlayerID(2);
		SetRightPlayerID(3);
		break;
	case 2:
		SetLeftPlayerID(3);
		SetRightPlayerID(1);
		break;
	case 3:
		SetLeftPlayerID(1);
		SetRightPlayerID(2);
		break;
	}


}

void UPlayerPanel::SetLocalPlayerID(int32 NewID)
{
	this->LocalPlayer->SetPlayerID(NewID);

}


void UPlayerPanel::SetPlayerCardNumber(int32 PlayerID, int32 NewValue)
{
	FString Name = TEXT("玩家") + FString::FromInt(PlayerID);
	if (this->LocalPlayer->GetPlayerName() == Name)
	{
		return;
	}
	if (this->LeftPlayer->GetPlayerName() == Name)
	{
		this->LeftPlayer->SetCardNumber(NewValue);

	}
	else
	{
		this->RightPlayer->SetCardNumber(NewValue);

	}
}


void UPlayerPanel::SetLocalPlayerCardNumber(int32 NewValue)
{
	this->LocalPlayer->SetCardNumber(NewValue);
}

void UPlayerPanel::SetLeftPlayerID(int32 NewID)
{
	this->LeftPlayer->SetPlayerID(NewID);
}

void UPlayerPanel::SetLeftPlayerCardNumber(int32 NewValue)
{
	this->LeftPlayer->SetCardNumber(NewValue);
}
void UPlayerPanel::SetRightPlayerID(int32 NewID)
{
	this->RightPlayer->SetPlayerID(NewID);
}

void UPlayerPanel::SetRightPlayerCardNumber(int32 NewValue)
{
	this->RightPlayer->SetCardNumber(NewValue);
}

void UPlayerPanel::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{



}



void UPlayerPanel::OnLocalClientGameStateCompleteInitialize()
{
	Super::OnLocalClientGameStateCompleteInitialize();


}



void UPlayerPanel::OnLocalClientPlayerControllerCompleteInitialize()
{
	Super::OnLocalClientPlayerControllerCompleteInitialize();
	


}


void UPlayerPanel::OnLocalClientPlayerStateCompleteInitialize()
{
	Super::OnLocalClientPlayerStateCompleteInitialize();
	AFTL_PlayerStateBase* PlayerState = GetOwningPlayer()->GetPlayerState<AFTL_PlayerStateBase>();
	InitializePlayerID(PlayerState->GetID());


}




void UPlayerPanel::OnPlayerPanelOpen()
{

	FVector2D Size = GetGameInstance()->GetGameState()->GameDefaultData.Widget.PlayerPanel.Size;
	FAnchorData AnchorData = GetGameInstance()->GetGameState()->GameDefaultData.Widget.AnchorData;
	GetGameInstance()->GetWidgetManager()->OpenPlayerPanel(Size, AnchorData);

}

void UPlayerPanel::OnPlayerPanelClose()
{
	GetGameInstance()->GetWidgetManager()->ClosePlayerPanel();

	this->LeftPlayer->SetCardNumberTextBlockVisibility(ESlateVisibility::Hidden);
	this->RightPlayer->SetCardNumberTextBlockVisibility(ESlateVisibility::Hidden);

}


void UPlayerPanel::OnDealCardComplete()
{
	this->LeftPlayer->SetCardNumberTextBlockVisibility(ESlateVisibility::Visible);
	this->RightPlayer->SetCardNumberTextBlockVisibility(ESlateVisibility::Visible);


}



void UPlayerPanel::OnGameOver(bool IsLanlordWin)
{
	OnPlayerPanelClose();
}



