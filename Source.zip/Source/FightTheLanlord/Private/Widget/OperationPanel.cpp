﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "Widget/OperationPanel.h"

#include "Widget/CardWidget.h"

#include "Components/Button.h"
#include "Components/Image.h"
#include "Components/TextBlock.h"
#include "Widget/TextBlockWidget.h"
#include "GameInstance/FTL_GameInstance.h"
#include "Manager/AudioManager.h"
#include "Manager/FTL_AssetManager.h"
#include "GameState/FTL_GameStateBase.h"
#include "Widget/CountdownTimerWidget.h"
#include "Widget/CardHandWidget.h"
#include "Widget/ButtonWidget.h"
#include "PlayerController/BattleLevelPlayerController.h"
#include "Manager/DelegateManager.h"
#include "PlayerState/FTL_PlayerStateBase.h"
#include "Manager/WidgetManager.h"


void UOperationPanel::NativeOnInitialized()
{
	Super::NativeOnInitialized();
	FOperationPanelData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.OperationPanel;
	FOperationPanelAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.OperationPanel;
	float PlayRate = GetGameInstance()->GetGameState()->GameDefaultData.Widget.PlayerPanelAnimationPlayRate;
	SetAnimationPlayRate(PlayRate);
	InitializePlayCardButton();
	InitializePassButton();
	InitializeMessageButton();
	InitializeCountdownTimer();
	InitializeCardHand();
	SetWidgetSize(Data.Size);
	SetRelativePosition(Data.RelativePosition);
	HideCountdownTimer();
	this->PlayCardButton->OnClick.BindUObject(this,&UOperationPanel::OnClickPlayCardButton);
	this->PassButton->OnClick.BindUObject(this, &UOperationPanel::OnClickPassButton);
	this->MessageButton->OnClick.BindUObject(this, &UOperationPanel::OnClickMessageButton);

	GetGameInstance()->GetDelegateManager()->OnOperationPanelOpen.AddUObject(this, &UOperationPanel::OnOperationPanelOpen);
	GetGameInstance()->GetDelegateManager()->OnOperationPanelClose.AddUObject(this, &UOperationPanel::OnOperationPanelClose);
	GetGameInstance()->GetDelegateManager()->OnDealCardComplete.AddUObject(this, &UOperationPanel::OnDealCardComplete);
	this->PassButton->SetVisibility(ESlateVisibility::Hidden);
	this->PlayCardButton->SetVisibility(ESlateVisibility::Hidden);
	this->MessageButton->SetVisibility(ESlateVisibility::Hidden);

	GetGameInstance()->GetDelegateManager()->OnGameOver.AddUObject(this, &UOperationPanel::OnGameOver);


}

void UOperationPanel::NativePreConstruct()
{
	Super::NativePreConstruct();


}


void UOperationPanel::NativeConstruct()
{
	Super::NativeConstruct();

}


void UOperationPanel::NativeDestruct()
{
	Super::NativeDestruct();


}
void UOperationPanel::InitializePlayCardButton()
{
	FButtonWidgetData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.OperationPanel.PlayCardButton;
	FButtonWidgetAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.OperationPanel.PlayCardButton;
	GetGameInstance()->GetWidgetManager()->InitializeButton(this->PlayCardButton, Data, Asset);

}
void UOperationPanel::InitializePassButton()
{
	FButtonWidgetData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.OperationPanel.PassButton;
	FButtonWidgetAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.OperationPanel.PassButton;
	GetGameInstance()->GetWidgetManager()->InitializeButton(this->PassButton, Data, Asset);

}

void UOperationPanel::InitializeMessageButton()
{
	FButtonWidgetData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.OperationPanel.MessageButton;
	FButtonWidgetAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.OperationPanel.MessageButton;
	GetGameInstance()->GetWidgetManager()->InitializeButton(this->MessageButton, Data, Asset);

}
void UOperationPanel::InitializeCountdownTimer()
{
	FCountdownTimerWidgetData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.OperationPanel.CountdownTimer;
	FCountdownTimerWidgetAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.OperationPanel.CountdownTimer;
	this->CountdownTimer->InitializeTextBlock(Data.TextBlock, Asset.TextBlock);
	this->CountdownTimer->SetWidgetSize(Data.Size);
	this->CountdownTimer->SetRelativePosition(Data.RelativePosition);
}

void UOperationPanel::InitializeCardHand()
{
	FCardHandWidgetData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.OperationPanel.CardHand;
	///FCardHandWidgetAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.OperationPanel.CardHand;
	this->CardHand->SetWidgetSize(Data.Size);
	this->CardHand->SetRelativePosition(Data.RelativePosition);
}

void UOperationPanel::PlayDealCardAnimation()
{
	this->CardHand->PlayDealCardAnimation();

}
void UOperationPanel::ShowCardHand()
{
	this->CardHand->SetVisibility(ESlateVisibility::Visible);
}
void UOperationPanel::HideCardHand()
{
	this->CardHand->SetVisibility(ESlateVisibility::Hidden);

}
TArray<UCardWidget*> UOperationPanel::GetAllCardFromCardHand()
{
	return this->CardHand->GetAllCard();
}
void UOperationPanel::AddCardToCardHand(UCardWidget* Card)
{
	this->CardHand->AddCard(Card);

}

void UOperationPanel::RemoveCardFromCardHand(UCardWidget* Card)
{
	this->CardHand->RemoveCard(Card);

}

void UOperationPanel::ShowCountdownTimer()
{
	this->CountdownTimer->SetText(30);
	this->CountdownTimer->SetVisibility(ESlateVisibility::HitTestInvisible);

}

void UOperationPanel::HideCountdownTimer()
{
	this->CountdownTimer->SetVisibility(ESlateVisibility::Hidden);

}


void UOperationPanel::SetCountdownTimerText(int32 CurrentSecond)
{
	this->CountdownTimer->SetText(CurrentSecond);

}

void UOperationPanel::RemoveAllCardFromCardHand()
{

	this->CardHand->Clear();

}


void UOperationPanel::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{



}

void UOperationPanel::OnClickPlayCardButton()
{
	ABattleLevelPlayerController* Controller = Cast<ABattleLevelPlayerController>(GetOwningPlayer());
	Controller->Client_PlayCard();
	
}


void UOperationPanel::OnClickPassButton()
{
	ABattleLevelPlayerController* Controller = Cast<ABattleLevelPlayerController>(GetOwningPlayer());
	Controller->Client_Pass();
	

}


void UOperationPanel::OnClickMessageButton()
{
	GetGameInstance()->GetDelegateManager()->OnMessagePanelOpen.Broadcast();
}




void UOperationPanel::OnLocalClientGameStateCompleteInitialize()
{
	Super::OnLocalClientGameStateCompleteInitialize();
	

}


void UOperationPanel::OnServerGameStateCompleteInitialize()
{
	Super::OnServerGameStateCompleteInitialize();
	

}



void UOperationPanel::OnLocalClientPlayerControllerCompleteInitialize()
{
	Super::OnLocalClientPlayerControllerCompleteInitialize();
	

}



void UOperationPanel::OnOperationPanelOpen()
{

	FVector2D Size = GetGameInstance()->GetGameState()->GameDefaultData.Widget.OperationPanel.Size;
	FAnchorData AnchorData = GetGameInstance()->GetGameState()->GameDefaultData.Widget.AnchorData;
	GetGameInstance()->GetWidgetManager()->OpenOperationPanel(Size, AnchorData);


}

void UOperationPanel::OnOperationPanelClose()
{

	GetGameInstance()->GetWidgetManager()->CloseOperationPanel();
	HideCountdownTimer();
}



void UOperationPanel::OnDealCardComplete()
{
	this->PassButton->SetVisibility(ESlateVisibility::Visible);
	this->PlayCardButton->SetVisibility(ESlateVisibility::Visible);
	this->MessageButton->SetVisibility(ESlateVisibility::Visible);

}


void UOperationPanel::OnGameOver(bool IsLanlordWin)
{
	OnOperationPanelClose();
}


