﻿

#include "Widget/WidgetBase.h"

#include "GameInstance/FTL_GameInstance.h"

#include "Components/SizeBox.h"

#include "Components/Button.h"
#include "Components/Image.h"

#include "Components/TextBlock.h"
#include "Widget/TextBlockWidget.h"
#include "Manager/DelegateManager.h"

#include "Manager/WidgetManager.h"

#include "Kismet/GameplayStatics.h"

void UWidgetBase::NativeOnInitialized()
{
	Super::NativeOnInitialized();
	GetGameInstance()->GetDelegateManager()->OnLocalClientGameStateCompleteInitialize.AddUObject(this,&UWidgetBase::OnLocalClientGameStateCompleteInitialize);

	GetGameInstance()->GetDelegateManager()->OnServerGameStateCompleteInitialize.AddUObject(this, &UWidgetBase::OnServerGameStateCompleteInitialize);

	GetGameInstance()->GetDelegateManager()->OnLocalClientPlayerControllerCompleteInitialize.AddUObject(this, &UWidgetBase::OnLocalClientPlayerControllerCompleteInitialize);

	GetGameInstance()->GetDelegateManager()->OnLocalClientPlayerStateCompleteInitialize.AddUObject(this, &UWidgetBase::OnLocalClientPlayerStateCompleteInitialize);


}

void UWidgetBase::NativePreConstruct()
{
	Super::NativePreConstruct();

}


void UWidgetBase::NativeConstruct()
{
	Super::NativeConstruct();

}


void UWidgetBase::NativeDestruct()
{
	Super::NativeDestruct();


}

void UWidgetBase::Open(int32 ZOrder)
{
	AddToViewport(ZOrder);
	if (this->WidgetAnimation != nullptr)
	{
		PlayAnimation(this->WidgetAnimation, 0.0f, 1, EUMGSequencePlayMode::Forward, GetAnimationPlayRate());
	}



}

void UWidgetBase::Close()
{
	if (this->WidgetAnimation != nullptr)
	{
		PlayAnimation(this->WidgetAnimation, 0.0f, 1, EUMGSequencePlayMode::Reverse, GetAnimationPlayRate());
	}
	else
	{
		RemoveFromParent();
	}
	////IsInViewport() == true ? RemoveFromParent() : void();


}

void UWidgetBase::SetWidgetSize(const FVector2D& NewSize)
{
	this->WidgetSize = NewSize;
	this->SizeBox->SetWidthOverride(NewSize.X);
    this->SizeBox->SetHeightOverride(NewSize.Y);

}

FVector2D UWidgetBase::GetWidgetSize()
{
	FVector2D Size = FVector2D::ZeroVector;
	Size.X = this->SizeBox->GetWidthOverride();
	Size.Y = this->SizeBox->GetHeightOverride();
	return Size;
}

void UWidgetBase::SetAnimationPlayRate(float NewPlayRate)
{
	this->AnimationPlayRate.SetCurrent(NewPlayRate);
}

float UWidgetBase::GetAnimationPlayRate()
{
	return this->AnimationPlayRate.GetCurrent();

}

void UWidgetBase::SetRelativePosition(const FVector2D& NewPosition)
{
	SetRenderTranslation(NewPosition);
}

FVector2D UWidgetBase::GetRelativePosition()
{
	return GetRenderTransform().Translation;
}

bool UWidgetBase::GetIsInServer()
{
	return GetOwningPlayer()->HasAuthority();

}

UFTL_GameInstance* UWidgetBase::GetGameInstance()
{
	if (this->GameInstance ==nullptr)
	{
		this->GameInstance = Cast<UFTL_GameInstance>(UGameplayStatics::GetGameInstance(GetWorld()));

	}
	return this->GameInstance;
}



void UWidgetBase::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	Super::OnAnimationFinished_Implementation(Animation);
	if (this->SizeBox->GetRenderOpacity() == 1.0f)
	{
	}
	else
	{
		RemoveFromParent();
	}


}

void UWidgetBase::OnLocalClientGameStateCompleteInitialize()
{





}

void UWidgetBase::OnLocalClientPlayerStateCompleteInitialize()
{





}


void UWidgetBase::OnServerGameStateCompleteInitialize()
{





}


void UWidgetBase::OnLocalClientPlayerControllerCompleteInitialize()
{





}
