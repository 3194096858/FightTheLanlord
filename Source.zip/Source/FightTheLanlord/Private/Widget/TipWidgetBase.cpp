﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "Widget/TipWidgetBase.h"


#include "GameInstance/FTL_GameInstance.h"

#include "Components/SizeBox.h"
#include "Components/Image.h"
#include "Components/TextBlock.h"

#include "Manager/FTL_AssetManager.h"
#include "Struct/GameProperty.h"
#include "Manager/DelegateManager.h"
#include "Manager/AudioManager.h"
#include "Widget/ButtonWidget.h"
#include "Widget/ResourcePanel.h"
#include "Manager/WidgetManager.h"

#include "Widget/TextBlockWidget.h"
#include "Widget/LoadingWidget.h"
#include "GameState/FTL_GameStateBase.h"

#include "Manager/FTL_TimerManager.h"




void UTipWidgetBase::NativeOnInitialized()
{
	Super::NativeOnInitialized();
}


void UTipWidgetBase::NativeConstruct()
{
	Super::NativeConstruct();


}


void UTipWidgetBase::NativePreConstruct()
{
	Super::NativePreConstruct();

}


void UTipWidgetBase::NativeDestruct()
{
	Super::NativeDestruct();


}



void UTipWidgetBase::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	///Super::OnAnimationFinished_Implementation(Animation);
	if (this->SizeBox->GetRenderOpacity() == 1.0f)
	{
	}
	else
	{
	}


}

