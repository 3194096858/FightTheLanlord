﻿

#include "Widget/CardWidget.h"

#include "Components/Button.h"
#include "Components/Image.h"

#include "Components/TextBlock.h"
#include "Widget/TextBlockWidget.h"
#include "Struct/CardInformation.h"
#include "GameMode/FTL_GameModeBase.h"
#include "Manager/AudioManager.h"
#include "Manager/WidgetManager.h"
#include "Manager/DelegateManager.h"

#include "Manager/FTL_AssetManager.h"
#include "GameState/FTL_GameStateBase.h"
#include "Struct/WidgetData.h"
#include "Kismet/KismetMathLibrary.h"

#include "GameInstance/FTL_GameInstance.h"

void UCardWidget::NativeOnInitialized()
{
	Super::NativeOnInitialized();
	this->Button->OnClicked.AddDynamic(this, &UCardWidget::OnClickCard);
	this->Button->OnPressed.AddDynamic(this, &UCardWidget::OnPressCard);
	this->Button->OnReleased.AddDynamic(this, &UCardWidget::OnReleaseCard);
	this->Button->SetRenderOpacity(0.0f);
	this->Image->SetVisibility(ESlateVisibility::HitTestInvisible);
	GetGameInstance()->GetDelegateManager()->OnGameOver.AddUObject(this, &UCardWidget::OnGameOver);

	

}

void UCardWidget::NativeConstruct()
{
	Super::NativeConstruct();


}


void UCardWidget::NativePreConstruct()
{
	Super::NativePreConstruct();
	

}


void UCardWidget::NativeDestruct()
{
	Super::NativeDestruct();

}

void UCardWidget::NativeTick(const FGeometry& MyGeometry, float InDeltaTime)
{
	Super::NativeTick(MyGeometry,InDeltaTime);


}


void UCardWidget::SetIsSelected(bool NewValue)
{
	this->IsSelected = NewValue;

}


bool UCardWidget::GetIsSelected()
{
	return this->IsSelected;

}


FCardInformation UCardWidget::GetCardInformation()
{
	return GetGameInstance()->GetWidgetManager()->GetActiveCardInformation(this);


}

void UCardWidget::SetCardInformation(FCardInformation NewInformation)
{
	GetGameInstance()->GetWidgetManager()->SetActiveCardInformation(this,NewInformation);


}
void UCardWidget::SetImage(UTexture2D* NewImage)
{
	this->Image->SetBrushFromTexture(NewImage);

}

void UCardWidget::MoveTo(const FVector2D& StartPosition, const FVector2D& EndPosition, float Speed)
{
	

}


void UCardWidget::OnClickCard()
{
	this->OnClick.ExecuteIfBound();
	FVector2D Position = GetRelativePosition();
	if (this->IsSelected == false)
	{
		SetRelativePosition(Position + FVector2D(0.0f,-100.0f));
		this->IsSelected = true;
		////FCardInformation Information = GetGameInstance()->GetWidgetManager()->GetActiveCardInformation(this);
	   //// GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, FString::Printf(TEXT("Name  == %s  ,Value = %d !!!!!!!  "), *Information.Name.ToString(),Information.Value));

	}
	else
	{
		SetRelativePosition(Position + FVector2D(0.0f, 100.0f));
		this->IsSelected = false;

	}


}


void UCardWidget::OnPressCard()
{
	this->OnPress.ExecuteIfBound();
	


}


void UCardWidget::OnReleaseCard()
{
	this->OnRelease.ExecuteIfBound();

	

}




void UCardWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{



}



void UCardWidget::OnLocalClientGameStateCompleteInitialize()
{
	Super::OnLocalClientGameStateCompleteInitialize();
	

}





void UCardWidget::OnServerGameStateCompleteInitialize()
{
	Super::OnServerGameStateCompleteInitialize();



}




void UCardWidget::OnLocalClientPlayerControllerCompleteInitialize()
{
	Super::OnLocalClientPlayerControllerCompleteInitialize();
	
}




void UCardWidget::OnGameOver(bool IsLanlordWin)
{
	
}

