﻿

#include "Widget/HUDWidget.h"

#include "Components/CanvasPanel.h"
#include "Components/CanvasPanelSlot.h"
#include "Components/PanelSlot.h"
#include "GameInstance/FTL_GameInstance.h"

void UHUDWidget::NativePreConstruct()
{
	Super::NativePreConstruct();


}


void  UHUDWidget::NativeConstruct()
{
	Super::NativeConstruct();
	//GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, TEXT("AddHUDWidgetToVewport"));


}


void  UHUDWidget::NativeDestruct()
{
	Super::NativeDestruct();
	///GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, TEXT("RemoveHUDWidgetFormVewport"));


}


void UHUDWidget::AddWidgetToCanvasPanel(UWidgetBase* Widget, const FVector2D& Size, const FAnchorData& AnchorData)
{
	UPanelSlot* PanelSlot = this->CanvasPanel->AddChild(Widget);
	UCanvasPanelSlot* CanvasPanelSlot = nullptr;
	CanvasPanelSlot = Cast<UCanvasPanelSlot>(PanelSlot);

	if (CanvasPanelSlot != nullptr && Widget != nullptr)
	{
		Widget->SetWidgetSize(Size);
		CanvasPanelSlot->SetAutoSize(true);
		CanvasPanelSlot->SetLayout(AnchorData);

	}



}


void UHUDWidget::RemoveWidgetFromCanvasPanel(UWidgetBase* Widget)
{
	if (this->CanvasPanel->HasChild(Widget) == true)
	{
		this->CanvasPanel->RemoveChild(Widget);
	}

}

