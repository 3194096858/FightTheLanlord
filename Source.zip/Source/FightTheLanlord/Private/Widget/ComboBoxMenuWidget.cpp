﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "Widget/ComboBoxMenuWidget.h"

#include "Components/Button.h"
#include "Components/Image.h"
#include "Components/ComboBoxString.h"
#include "Components/PanelSlot.h"
#include "Components/ScrollBoxSlot.h"

#include "Components/TextBlock.h"
#include "Widget/TextBlockWidget.h"
#include "Widget/ComboBoxItemWidget.h"
#include "Widget/ButtonWidget.h"

#include "GameInstance/FTL_GameInstance.h"
#include "Manager/AudioManager.h"
#include "Manager/FTL_AssetManager.h"
#include "GameState/FTL_GameStateBase.h"
#include "Components/ScrollBox.h"
#include "Kismet/GameplayStatics.h"


void UComboBoxMenuWidget::NativeOnInitialized()
{
	Super::NativeOnInitialized();
	FSlateBrush ScrollBoxSlateBrush;
	ScrollBoxSlateBrush.SetImageSize(FVector2D(0.0f));
	this->Style.SetBottomShadowBrush(ScrollBoxSlateBrush);
	this->Style.SetTopShadowBrush(ScrollBoxSlateBrush);
	this->ScrollBox->SetWidgetStyle(this->Style);
	
}

void UComboBoxMenuWidget::NativePreConstruct()
{
	Super::NativePreConstruct();
	
}


void UComboBoxMenuWidget::NativeConstruct()
{
	Super::NativeConstruct();

	float StartAtTime = 0.0f;
	int32 NumberLoopsToPlay = 1;
	EUMGSequencePlayMode::Type PlayMode = EUMGSequencePlayMode::Forward;
	int32 PlayRate = this->AnimationPlayRate.GetCurrent();
	PlayAnimation(this->WidgetAnimation, StartAtTime, NumberLoopsToPlay, PlayMode, PlayRate);


}


void UComboBoxMenuWidget::NativeDestruct()
{
	Super::NativeDestruct();


}

TArray<UComboBoxItemWidget*> UComboBoxMenuWidget::GetAllItem()
{
	TArray<UComboBoxItemWidget*> ItemArray;
	for (auto Element : this->ScrollBox->GetAllChildren())
	{
		ItemArray.Add(Cast<UComboBoxItemWidget>(Element));
	}

	return ItemArray;


}

void UComboBoxMenuWidget::SetScrollBarVisibility(const ESlateVisibility& NewVisibility)
{
	this->ScrollBox->SetScrollBarVisibility(NewVisibility);

}


void UComboBoxMenuWidget::AddItem(UComboBoxItemWidget* Item, const FMargin& ItemPadding)
{
	UPanelSlot* PanelSlot = this->ScrollBox->AddChild(Item);
	UScrollBoxSlot* ScrollBoxSlot = Cast<UScrollBoxSlot>(PanelSlot);
	if (ScrollBoxSlot == nullptr)
	{
		return;
	}
	ScrollBoxSlot->SetPadding(ItemPadding);
	ScrollBoxSlot->SetHorizontalAlignment(EHorizontalAlignment::HAlign_Center);
	ScrollBoxSlot->SetVerticalAlignment(EVerticalAlignment::VAlign_Center);


}


void UComboBoxMenuWidget::SetItemFontColor(const FColor& NewColor)
{
	TArray<UComboBoxItemWidget*> ItemArray = GetAllItem();

	for (auto& Element : ItemArray)
	{
		Element->SetFontColor(NewColor);
	}


}

void UComboBoxMenuWidget::SetItemFontSize(int32 NewSize)
{
	TArray<UComboBoxItemWidget*> ItemArray = GetAllItem();
	for (auto& Element : ItemArray)
	{
		Element->SetFontSize(NewSize);
	}


}

void UComboBoxMenuWidget::SetBackGroundImageSlateBrush(const FSlateBrush& NewBackGroundImageSlateBrush)
{
	this->BackGroundImage->SetBrush(NewBackGroundImageSlateBrush);

}



void UComboBoxMenuWidget::SetItemFontInformation(const FSlateFontInfo& NewFontInformation)
{
	TArray<UComboBoxItemWidget*> ItemArray = GetAllItem();

	for (auto& Element : ItemArray)
	{
		Element->SetFontInformation(NewFontInformation);
	}


}



void UComboBoxMenuWidget::SetItemSize(const FVector2D& NewSize)
{
	TArray<UComboBoxItemWidget*> ItemArray = GetAllItem();
	for (auto& Element : ItemArray)
	{
		Element->SetWidgetSize(NewSize);
	}

}


void UComboBoxMenuWidget::SetItemBackGroundImage(UTexture2D* NewImage)
{
	TArray<UComboBoxItemWidget*> ItemArray = GetAllItem();
		for (auto& Element : ItemArray)
	{
		Element->SetBackGroundImage(NewImage);
	}

}

void UComboBoxMenuWidget::SetBackGroundImage(UTexture2D* NewImage)
{
	this->BackGroundImage->SetBrushFromTexture(NewImage);


}


void UComboBoxMenuWidget::SetItemBackGroundImageVisibility(const ESlateVisibility& NewVisibility)
{

	TArray<UComboBoxItemWidget*> ItemArray = GetAllItem();

	for (auto& Element : ItemArray)
	{
		Element->SetBackGroundImageVisibility(NewVisibility);
	}


}


void UComboBoxMenuWidget::SetItemBackGroundImageColor(const FColor& NewColor)
{

	TArray<UComboBoxItemWidget*> ItemArray = GetAllItem();

	for (auto& Element : ItemArray)
	{
		Element->SetBackGroundImageColor(NewColor);
	}

}


void UComboBoxMenuWidget::SetBackGroundImageColor(const FColor& NewColor)
{
	this->BackGroundImage->SetBrushTintColor(NewColor);

}



void UComboBoxMenuWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	Super::OnAnimationFinished_Implementation(Animation);



}




