﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "Widget/SessionWidget.h"


#include "Components/SizeBox.h"
#include "Components/Image.h"

#include "Manager/FTL_AssetManager.h"
#include "Struct/GameProperty.h"
#include "Manager/DelegateManager.h"
#include "Manager/AudioManager.h"
#include "Widget/ButtonWidget.h"
#include "Widget/TextBlockWidget.h"
#include "Manager/GameSessionManager.h"

#include "Manager/WidgetManager.h"
#include "Manager/LevelManager.h"

#include "GameState/FTL_GameStateBase.h"
#include "GameInstance/FTL_GameInstance.h"





void USessionWidget::NativeOnInitialized()
{
	Super::NativeOnInitialized();
	FSessionWidgetData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.SessionWidget;
	FSessionWidgetAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.SessionWidget;
	FTextBlockWidgetAsset TextBlockAsset;
	InitializeJoinButton();
	InitializeDeleteButton();
	GetGameInstance()->GetWidgetManager()->InitializeTextBlock(this->NameTextBlock, Data.NameTextBlock,TextBlockAsset);
	this->BackGroundImage->SetBrushFromTexture(Asset.BackGroundImage.Image);
	this->BackGroundImage->SetBrushTintColor(Data.BackGroundImage.Color);
	this->Icon->SetBrushFromTexture(Asset.Icon.Image);
	this->Icon->SetBrushTintColor(Data.Icon.Color);
	this->Icon->Brush.ImageSize = Data.Icon.Size;
	this->JoinButton->OnClick.BindUObject(this, &USessionWidget::OnClickJoinButton);
	this->DeleteButton->OnClick.BindUObject(this, &USessionWidget::OnClickDeleteButton);
	///GetGameInstance()->GetGameSessionManager()->OnSearchSession.AddUObject(this, &USessionWidget::OnSearchSession);
	//GetGameInstance()->GetGameSessionManager()->OnJoinSessionComplete.AddUObject(this, &USessionWidget::OnJoinSessionComplete);
	GetGameInstance()->GetGameSessionManager()->OnDestroySessionComplete.AddUObject(this, &USessionWidget::OnDestroySessionComplete);
	GetGameInstance()->GetGameSessionManager()->OnQuitSessionComplete.AddUObject(this, &USessionWidget::OnQuitSessionComplete);

	SetSessionName(TEXT("None"));



}





void USessionWidget::NativePreConstruct()
{
	Super::NativePreConstruct();


}


void USessionWidget::NativeConstruct()
{
	Super::NativeConstruct();


}


void USessionWidget::NativeDestruct()
{
	Super::NativeDestruct();


}


void USessionWidget::SetSessionName(const FString& NewName)
{
	this->NameTextBlock->SetText(NewName);

}
FString USessionWidget::GetSessionName()
{
	FString Name;
	this->NameTextBlock->GetText(Name);
	return Name;
}



void USessionWidget::RemoveFromScrollBox()
{
	GetParent()->RemoveChild(this);

}

void USessionWidget::SetDeleteButtonVisibility(const ESlateVisibility& NewVisibility)
{
	this->DeleteButton->SetVisibility(NewVisibility);
}


void USessionWidget::InitializeJoinButton()
{
	FButtonWidgetData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.SessionWidget.JoinButton;
	FButtonWidgetAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.SessionWidget.JoinButton;
	GetGameInstance()->GetWidgetManager()->InitializeButton(this->JoinButton, Data, Asset);


}


void USessionWidget::InitializeDeleteButton()
{
	FButtonWidgetData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.SessionWidget.DeleteButton;
	FButtonWidgetAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.SessionWidget.DeleteButton;
	GetGameInstance()->GetWidgetManager()->InitializeButton(this->DeleteButton, Data, Asset);



}

void USessionWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	Super::OnAnimationFinished_Implementation(Animation);
	if (this->SizeBox->GetRenderOpacity() == 1.0f)
	{
	}
	else
	{

	}


}



void USessionWidget::OnClickJoinButton()
{
	FString WarningName = TEXT("JoinSession");
	GetGameInstance()->GetGameSessionManager()->SetSelectedSessionName(GetSessionName());
	GetGameInstance()->GetDelegateManager()->OnWarningPanelOpen.Broadcast(WarningName);


}

void USessionWidget::OnClickDeleteButton()
{
	FString WarningName = TEXT("DestroySession");
	GetGameInstance()->GetGameSessionManager()->SetSelectedSessionName(GetSessionName());
	GetGameInstance()->GetDelegateManager()->OnWarningPanelOpen.Broadcast(WarningName);

}


void USessionWidget::OnSearchSession()
{
	


}


void USessionWidget::OnJoinSessionComplete(const FName& SessionName)
{
	/*FString HostIP;
	FString HostPort;
	GetGameInstance()->GetGameSessionManager()->GetHostIPAndPort(SessionName,HostIP,HostPort);
	GetGameInstance()->GetLevelManager()->SetLevelSwitchSettings(HostIP);
	GetGameInstance()->GetDelegateManager()->OnLocalClientSwitchLevel.Broadcast();

	///GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, FString::Printf(TEXT("SessionName = %s, HostIP = %s, HostPort = %s !!!!!!!!"), *SessionName.ToString(), *HostIP, *HostPort));*/



}


void USessionWidget::OnDestroySessionComplete(const FName& SessionName)
{
	FString Name;
	this->NameTextBlock->GetText(Name);
	if (SessionName == Name)
	{
		GetGameInstance()->GetWidgetManager()->ReturnSessionWidget(this);
		SetSessionName(TEXT("None"));
		SetVisibility(ESlateVisibility::Collapsed);
	}

}

void USessionWidget::OnQuitSessionComplete(const FName& SessionName)
{
	FString Name;
	this->NameTextBlock->GetText(Name);
	if (SessionName == Name)
	{
		GetGameInstance()->GetWidgetManager()->ReturnSessionWidget(this);
		SetSessionName(TEXT("None"));
		SetVisibility(ESlateVisibility::Collapsed);
	}

}
