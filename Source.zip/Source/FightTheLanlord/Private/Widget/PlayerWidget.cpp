﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "Widget/PlayerWidget.h"



#include "Components/Button.h"
#include "Components/Image.h"
#include "Components/TextBlock.h"
#include "Widget/TextBlockWidget.h"
#include "GameInstance/FTL_GameInstance.h"
#include "Manager/AudioManager.h"
#include "Manager/FTL_AssetManager.h"
#include "Manager/WidgetManager.h"

#include "GameState/FTL_GameStateBase.h"




void UPlayerWidget::NativeOnInitialized()
{
	Super::NativeOnInitialized();
	
}

void UPlayerWidget::NativePreConstruct()
{
	Super::NativePreConstruct();


}


void UPlayerWidget::NativeConstruct()
{
	Super::NativeConstruct();


}


void UPlayerWidget::NativeDestruct()
{
	Super::NativeDestruct();


}

void UPlayerWidget::InitializeNameTextBlock(FTextBlockWidgetData Data, FTextBlockWidgetAsset Asset)
{
	
	GetGameInstance()->GetWidgetManager()->InitializeTextBlock(this->NameTextBlock,Data,Asset);
}

void UPlayerWidget::InitializeCardNumberTextBlock(FTextBlockWidgetData Data, FTextBlockWidgetAsset Asset)
{
	GetGameInstance()->GetWidgetManager()->InitializeTextBlock(this->CardNumberTextBlock, Data, Asset);


}

FString UPlayerWidget::GetPlayerName()
{
	FString Name;
	this->NameTextBlock->GetText(Name);
	return Name;
}

void UPlayerWidget::SetPlayerID(int32 NewID)
{
	FString Name = TEXT("玩家") + FString::FromInt(NewID);
	this->NameTextBlock->SetText(Name);

}

void UPlayerWidget::SetCardNumber(int32 NewValue)
{
	this->CardNumberTextBlock->SetText(FString::FromInt(NewValue));

}
void UPlayerWidget::SetCardNumberTextBlockVisibility(ESlateVisibility NewVisibility)
{
	this->CardNumberTextBlock->SetVisibility(NewVisibility);
}
void UPlayerWidget::SetCardNumberTextBlockRelativePosition(const FVector2D& NewPosition)
{
	this->CardNumberTextBlock->SetRelativePosition(NewPosition);

}

void UPlayerWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{



}

