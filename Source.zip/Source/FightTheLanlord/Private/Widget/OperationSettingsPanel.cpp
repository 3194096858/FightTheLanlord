﻿

#include "Widget/OperationSettingsPanel.h"


#include "Components/SizeBox.h"
#include "Components/Image.h"

#include "Manager/FTL_AssetManager.h"
#include "Struct/GameProperty.h"
#include "Manager/DelegateManager.h"
#include "Manager/AudioManager.h"
#include "Widget/ButtonWidget.h"
#include "Widget/TextBlockWidget.h"

#include "Manager/WidgetManager.h"

#include "GameState/FTL_GameStateBase.h"
#include "GameInstance/FTL_GameInstance.h"




#include "Components/Button.h"

#include "Components/TextBlock.h"




void UOperationSettingsPanel::NativeOnInitialized()
{
	Super::NativeOnInitialized();


}





void UOperationSettingsPanel::NativePreConstruct()
{
	Super::NativePreConstruct();


}


void UOperationSettingsPanel::NativeConstruct()
{
	Super::NativeConstruct();


}


void UOperationSettingsPanel::NativeDestruct()
{
	Super::NativeDestruct();
	//PlayAnimation(this->WidgetAnimation, 0.0f, 1, EUMGSequencePlayMode::Reverse, 3.0f);


}




void UOperationSettingsPanel::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	if (this->SizeBox->GetRenderOpacity() == 1.0f)
	{
	}
	else
	{

	}


}