﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "Widget/GameLobbyPanel.h"


#include "Components/SizeBox.h"
#include "Components/Image.h"

#include "Manager/FTL_AssetManager.h"
#include "Struct/GameProperty.h"
#include "Manager/DelegateManager.h"
#include "Manager/AudioManager.h"
#include "Widget/ButtonWidget.h"
#include "Widget/TextBlockWidget.h"
#include "Manager/GameSessionManager.h"
#include "Manager/LevelManager.h"

#include "Manager/WidgetManager.h"
#include "PlayerState/FTL_PlayerStateBase.h"
#include "GameMode/GameLobbyGameMode.h"
#include "GameState/FTL_GameStateBase.h"
#include "GameInstance/FTL_GameInstance.h"

#include "Kismet/GameplayStatics.h"

#include "PlayerController/GameLobbyLevelPlayerController.h"

void UGameLobbyPanel::NativeOnInitialized()
{
	Super::NativeOnInitialized();
	float PlayRate = GetGameInstance()->GetGameState()->GameDefaultData.Widget.GameLobbyPanelAnimationPlayRate;
	InitializeTextBlock();
	InitializeReturnButton();
	InitializeStartFightingButton();
	this->StartFightingButton->OnClick.BindUObject(this, &UGameLobbyPanel::OnClickStartFightingButton);
	this->QuitButton->OnClick.BindUObject(this, &UGameLobbyPanel::OnClickQuitButton);
	SetAnimationPlayRate(PlayRate);
	GetGameInstance()->GetDelegateManager()->OnGameLobbyPanelOpen.AddUObject(this, &UGameLobbyPanel::OnGameLobbyPanelOpen);
	GetGameInstance()->GetDelegateManager()->OnGameLobbyPanelClose.AddUObject(this, &UGameLobbyPanel::OnGameLobbyPanelClose);
	GetGameInstance()->GetDelegateManager()->OnGameStart.AddUObject(this, &UGameLobbyPanel::OnGameStart);
	GetGameInstance()->GetDelegateManager()->OnGameOver.AddUObject(this, &UGameLobbyPanel::OnGameOver);



}





void UGameLobbyPanel::NativePreConstruct()
{
	Super::NativePreConstruct();


}


void UGameLobbyPanel::NativeConstruct()
{
	Super::NativeConstruct();
	
}


void UGameLobbyPanel::NativeDestruct()
{
	Super::NativeDestruct();

}

void UGameLobbyPanel::InitializeReturnButton()
{

	FButtonWidgetData Data= GetGameInstance()->GetGameState()->GameDefaultData.Widget.GameLobbyPanel.QuitButton;
	FButtonWidgetAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.GameLobbyPanel.QuitButton;
	GetGameInstance()->GetWidgetManager()->InitializeButton(this->QuitButton, Data, Asset);
}


void UGameLobbyPanel::InitializeStartFightingButton()
{

	FButtonWidgetData Data= GetGameInstance()->GetGameState()->GameDefaultData.Widget.GameLobbyPanel.StartFightingButton;
	FButtonWidgetAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.GameLobbyPanel.StartFightingButton;
	GetGameInstance()->GetWidgetManager()->InitializeButton(this->StartFightingButton, Data, Asset);
}

void UGameLobbyPanel::InitializeTextBlock()
{

	FTextBlockWidgetData Data= GetGameInstance()->GetGameState()->GameDefaultData.Widget.GameLobbyPanel.TextBlock;
	FTextBlockWidgetAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.GameLobbyPanel.TextBlock;
	GetGameInstance()->GetWidgetManager()->InitializeTextBlock(this->TextBlock, Data, Asset);
}

void UGameLobbyPanel::SetText(const FString& NewText)
{
	this->TextBlock->SetText(NewText);
}

void UGameLobbyPanel::SetCurrentPlayerNumber(int32 Number)
{
	FString Text;
	if ( Number == 3)
	{
		Text = TEXT("房间已满,请开始对战!");
	}
	else
	{
		Text = TEXT("请等待其他玩家进入... ") + FString::FromInt(Number) + TEXT("/3");

	}

	this->TextBlock->SetText(Text);
}

void UGameLobbyPanel::ShowStartFightingButton()
{
	this->StartFightingButton->SetVisibility(ESlateVisibility::Visible);
}

void UGameLobbyPanel::HideStartFightingButton()
{
	this->StartFightingButton->SetVisibility(ESlateVisibility::Collapsed);

}


void UGameLobbyPanel::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	Super::OnAnimationFinished_Implementation(Animation);
	

}



void UGameLobbyPanel::OnClickQuitButton()
{
	FString WarningName = TEXT("QuitSession");
	GetGameInstance()->GetDelegateManager()->OnWarningPanelOpen.Broadcast(WarningName);

}


void UGameLobbyPanel::OnClickStartFightingButton()
{
	AGameLobbyGameMode* GameMode = Cast<AGameLobbyGameMode>(UGameplayStatics::GetGameMode(GetGameInstance()));
	/*if (GameMode->GetCurrentPlayerNumber() != 3)
	{
		GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Red, TEXT("无法开始对战 , 玩家数量不等于  3   ！！！！"));
		return;
	}*/
	AGameLobbyLevelPlayerController* Controller = nullptr;
	GetGameInstance()->GetLevelManager()->SetLevelSwitchSettings(TEXT("BattleLevel"), true);

	for (auto& Element : UGameplayStatics::GetGameMode(GetGameInstance())->GameState->PlayerArray)
	{
		Controller = Cast<AGameLobbyLevelPlayerController>(Element->GetPlayerController());
		if (Controller == nullptr)
		{
			continue;
		}
		Controller->Client_OnGameStart();
		Controller->Client_OnLocalClientSwitchLevel();
	}

}


void UGameLobbyPanel::OnGameLobbyPanelOpen()
{
	FVector2D Size= GetGameInstance()->GetGameState()->GameDefaultData.Widget.GameLobbyPanel.Size;
	FAnchorData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.AnchorData;
	GetGameInstance()->GetWidgetManager()->OpenGameLobbyPanel(Size,Data);
	GetGameInstance()->GetDelegateManager()->OnGameMainPageClose.Broadcast();
	GetGameInstance()->GetDelegateManager()->OnGameSessionPanelClose.Broadcast();
	GetGameInstance()->GetWidgetManager()->UpdateBackGroundImage(GetGameInstance(),TEXT("GameLobby"));
	GetOwningPlayer()->HasAuthority() == true ? ShowStartFightingButton() : HideStartFightingButton();
	this->QuitButton->SetVisibility(ESlateVisibility::Visible);
	this->QuitButton->SetRenderOpacity(1.0f);
	this->TextBlock->SetVisibility(ESlateVisibility::HitTestInvisible);

}

void UGameLobbyPanel::OnGameLobbyPanelClose()
{
	GetGameInstance()->GetWidgetManager()->CloseGameLobbyPanel();

	


}


void UGameLobbyPanel::OnGameStart()
{

	GetOwningPlayer()->HasAuthority() == true ? this->StartFightingButton->SetVisibility(ESlateVisibility::HitTestInvisible) : void();
	this->QuitButton->SetVisibility(ESlateVisibility::HitTestInvisible);
	this->QuitButton->SetRenderOpacity(0.5f);
	this->TextBlock->SetVisibility(ESlateVisibility::Collapsed);


}




void UGameLobbyPanel::OnGameOver(bool IsLanlordWin)
{
	

}



