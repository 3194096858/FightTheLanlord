﻿

#include "Widget/GameMainPage.h"


#include "Components/SizeBox.h"
#include "Components/Image.h"
#include "Components/TextBlock.h"

#include "Manager/FTL_AssetManager.h"
#include "Struct/GameProperty.h"
#include "Manager/DelegateManager.h"
#include "Manager/AudioManager.h"
#include "Widget/ButtonWidget.h"
#include "Widget/ResourcePanel.h"
#include "Manager/WidgetManager.h"

#include "Widget/TextBlockWidget.h"

#include "GameState/FTL_GameStateBase.h"

#include "GameInstance/FTL_GameInstance.h"



void UGameMainPage::NativeOnInitialized()
{
	Super::NativeOnInitialized();
	float PlayRate = GetGameInstance()->GetGameState()->GameDefaultData.Widget.GameMainPageAnimationPlayRate;
	SetAnimationPlayRate(PlayRate);
	InitializeGameSettingsButton();
	InitializeSessionButton();
	InitializeQuitGameButton();
	GetGameInstance()->GetDelegateManager()->OnGameMainPageOpen.AddUObject(this,&UGameMainPage::OnGameMainPageOpen);
	this->SettingsButton->OnClick.BindUObject(this,&UGameMainPage::OnClickSettingsButton);
	this->SessionButton->OnClick.BindUObject(this, &UGameMainPage::OnClickSessionButton);
	this->QuitGameButton->OnClick.BindUObject(this, &UGameMainPage::OnClickQuitGameButton);
	GetGameInstance()->GetDelegateManager()->OnGameMainPageClose.AddUObject(this, &UGameMainPage::OnGameMainPageClose);

}





void UGameMainPage::NativePreConstruct()
{
	Super::NativePreConstruct();
	
}


void UGameMainPage::NativeConstruct()
{
	Super::NativeConstruct();
	

}


void UGameMainPage::NativeDestruct()
{
	Super::NativeDestruct();


}

void UGameMainPage::InitializeGameSettingsButton()
{
	FButtonWidgetData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.GameMainPage.SettingsButton;
	FButtonWidgetAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.GameMainPage.SettingsButton;
	GetGameInstance()->GetWidgetManager()->InitializeButton(this->SettingsButton, Data, Asset);
}


void UGameMainPage::InitializeSessionButton()
{

	FButtonWidgetData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.GameMainPage.SessionButton;
	FButtonWidgetAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.GameMainPage.SessionButton;
	GetGameInstance()->GetWidgetManager()->InitializeButton(this->SessionButton, Data, Asset);
	
}


void UGameMainPage::InitializeQuitGameButton()
{

	FButtonWidgetData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.GameMainPage.QuitGameButton;
	FButtonWidgetAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.GameMainPage.QuitGameButton;
	GetGameInstance()->GetWidgetManager()->InitializeButton(this->QuitGameButton, Data, Asset);
	
}


void UGameMainPage::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	Super::OnAnimationFinished_Implementation(Animation);

	if (this->SizeBox->GetRenderOpacity() == 1.0f)
	{
	}
	else
	{

	}


}



void UGameMainPage::OnGameMainPageOpen()
{
	GetGameInstance()->GetWidgetManager()->UpdateBackGroundImage(GetGameInstance(), TEXT("GameMainPage"));
	FVector2D GameMainPageSize = GetGameInstance()->GetGameState()->GameDefaultData.Widget.GameMainPage.Size;
	FVector2D ResourcePanelSize = GetGameInstance()->GetGameState()->GameDefaultData.Widget.ResourcePanel.Size;
	FAnchorData AnchorData = GetGameInstance()->GetGameState()->GameDefaultData.Widget.AnchorData;
	GetGameInstance()->GetWidgetManager()->OpenGameMainPage(GameMainPageSize, AnchorData);
	GetGameInstance()->GetWidgetManager()->OpenResourcePanel(ResourcePanelSize,AnchorData);


}

void UGameMainPage::OnGameMainPageClose()
{
	GetGameInstance()->GetWidgetManager()->CloseGameMainPage();
	GetGameInstance()->GetWidgetManager()->CloseResourcePanel();


}



void UGameMainPage::OnClickSettingsButton()
{
	
	GetGameInstance()->GetDelegateManager()->OnGameSettingsPanelOpen.Broadcast();

	
}

void UGameMainPage::OnClickSessionButton()
{

	GetGameInstance()->GetDelegateManager()->OnGameSessionPanelOpen.Broadcast();




}


void UGameMainPage::OnClickQuitGameButton()
{
	
	FString WarningName = TEXT("QuitGame");
	GetGameInstance()->GetDelegateManager()->OnWarningPanelOpen.Broadcast(WarningName);



}









