﻿

#include "Widget/StartMenu.h"

#include "Components/SizeBox.h"
#include "Components/Image.h"

#include "Manager/FTL_AssetManager.h"
#include "Struct/GameProperty.h"
#include "Manager/DelegateManager.h"
#include "Manager/AudioManager.h"
#include "Widget/ButtonWidget.h"
#include "Widget/TextBlockWidget.h"
#include "Manager/LevelManager.h"

#include "Manager/WidgetManager.h"

#include "GameState/FTL_GameStateBase.h"
#include "GameInstance/FTL_GameInstance.h"
#include "PlayerController/PlayerControllerBase.h"




void UStartMenu::NativeOnInitialized()
{
	Super::NativeOnInitialized();
	float PlayRate = GetGameInstance()->GetGameState()->GameDefaultData.Widget.StartMenuAnimationPlayRate;

	UTexture2D* TitleImage = GetGameInstance()->GetAssetManager()->WidgetAsset.StartMenu.GameTitleImage;
	FButtonWidgetData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.StartMenu.StartGameButton;
	FButtonWidgetAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.StartMenu.StartGameButton;
	GetGameInstance()->GetWidgetManager()->InitializeButton(this->StartGameButton, Data, Asset);
	this->GameTitleImage->SetBrushFromTexture(TitleImage);
	this->StartGameButton->OnClick.BindUObject(this,&UStartMenu::OnClickStartGameButton);
	SetAnimationPlayRate(PlayRate);
	GetGameInstance()->GetDelegateManager()->OnStartMenuOpen.AddUObject(this,&UStartMenu::OnStartMenuOpen);
	GetGameInstance()->GetDelegateManager()->OnStartMenuClose.AddUObject(this, &UStartMenu::OnStartMenuClose);

}





void UStartMenu::NativePreConstruct()
{
	Super::NativePreConstruct();
	
	
}


void UStartMenu::NativeConstruct()
{
	Super::NativeConstruct();
	

}


void UStartMenu::NativeDestruct()
{
	Super::NativeDestruct();


}

void UStartMenu::InitializeStartGameButton()
{
	


}


void UStartMenu::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	Super::OnAnimationFinished_Implementation(Animation);
	

}



void UStartMenu::OnClickStartGameButton()
{
	GetGameInstance()->GetLevelManager()->SetLevelSwitchSettings(TEXT("GameMainPageLevel"),false);
	GetGameInstance()->GetDelegateManager()->OnLocalClientSwitchLevel.Broadcast();
	this->StartGameButton->SetVisibility(ESlateVisibility::HitTestInvisible);


}




void UStartMenu::OnStartMenuOpen()
{
	FVector2D Size = GetGameInstance()->GetGameState()->GameDefaultData.Widget.StartMenu.Size;
	FAnchorData AnchorData = GetGameInstance()->GetGameState()->GameDefaultData.Widget.AnchorData;
	GetGameInstance()->GetWidgetManager()->OpenStartMenu(Size, AnchorData);
	GetGameInstance()->GetWidgetManager()->UpdateBackGroundImage(GetGameInstance(), TEXT("StartMenu"));
	this->StartGameButton->SetVisibility(ESlateVisibility::Visible);


}

void UStartMenu::OnStartMenuClose()
{
	GetGameInstance()->GetWidgetManager()->CloseStartMenu();



}





