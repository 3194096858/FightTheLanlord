﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "Widget/AudioSettingsPanel.h"


#include "Components/SizeBox.h"
#include "Components/Image.h"

#include "Manager/FTL_AssetManager.h"
#include "Struct/GameProperty.h"
#include "Manager/DelegateManager.h"
#include "Manager/AudioManager.h"
#include "Widget/ButtonWidget.h"
#include "Widget/TextBlockWidget.h"

#include "Manager/WidgetManager.h"

#include "GameState/FTL_GameStateBase.h"
#include "GameInstance/FTL_GameInstance.h"
#include "Widget/GameSettingsOptionWidget.h"



#include "Components/Button.h"

#include "Components/TextBlock.h"




void UAudioSettingsPanel::NativeOnInitialized()
{
	Super::NativeOnInitialized();
	USoundMix* SoundMix = GetGameInstance()->GetAssetManager()->GetSoundMix();
	USoundClass* BGMSoundClass = GetGameInstance()->GetAssetManager()->GetBGMSoundClass();
	USoundClass* SFXSoundClass = GetGameInstance()->GetAssetManager()->GetBGMSoundClass();

	InitializeBGMOptionWidget();
	InitializeSFXOptionWidget();
	this->BGMOptionWidget->OnSliderValueChange.BindUObject(this,&UAudioSettingsPanel::OnBGMVolumeChange);
	this->SFXOptionWidget->OnSliderValueChange.BindUObject(this, &UAudioSettingsPanel::OnSFXVolumeChange);

	GetGameInstance()->GetAudioManager()->SetBGMVolume(SoundMix, BGMSoundClass, this->BGMOptionWidget->GetSliderValue());
	GetGameInstance()->GetAudioManager()->SetSFXVolume(SoundMix, SFXSoundClass, this->SFXOptionWidget->GetSliderValue());

}





void UAudioSettingsPanel::NativePreConstruct()
{
	Super::NativePreConstruct();


}


void UAudioSettingsPanel::NativeConstruct()
{
	Super::NativeConstruct();


}


void UAudioSettingsPanel::NativeDestruct()
{
	Super::NativeDestruct();


}



void UAudioSettingsPanel::InitializeBGMOptionWidget()
{
	FGameSettingsOptionWidgetData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.GameSettingsPanel.Audio.BGM;
	FGameSettingsOptionWidgetAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.GameSettingsPanel.Audio.BGM;

	GetGameInstance()->GetWidgetManager()->InitializeGameSettingsOption(this->BGMOptionWidget, Data, Asset);
	this->BGMOptionWidget->SetSliderMaxValue(1.0f);
	this->BGMOptionWidget->SetSliderMinValue(0.0f);
	this->BGMOptionWidget->SetSliderCurrentPercent(this->BGMOptionWidget->GetSliderCurrentPercent());

}

void UAudioSettingsPanel::InitializeSFXOptionWidget()
{
	FGameSettingsOptionWidgetData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.GameSettingsPanel.Audio.SFX;
	FGameSettingsOptionWidgetAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.GameSettingsPanel.Audio.SFX;

	GetGameInstance()->GetWidgetManager()->InitializeGameSettingsOption(this->SFXOptionWidget, Data, Asset);
	this->SFXOptionWidget->SetSliderMaxValue(1.0f);
	this->SFXOptionWidget->SetSliderMinValue(0.0f);

	this->SFXOptionWidget->SetSliderCurrentPercent(this->SFXOptionWidget->GetSliderCurrentPercent());


}


void UAudioSettingsPanel::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	


}

void UAudioSettingsPanel::OnBGMVolumeChange(float Value)
{
	USoundMix* SoundMix = GetGameInstance()->GetAssetManager()->GetSoundMix();
	USoundClass* SoundClass = GetGameInstance()->GetAssetManager()->GetBGMSoundClass();
	float Max = GetGameInstance()->GetGameState()->GameDefaultData.GameSettings.Audio.BGMVolume.GetMax();
	float NewValue = Max * Value;
	this->BGMOptionWidget->SetSliderCurrentPercent(Value * 100);
	GetGameInstance()->GetAudioManager()->SetBGMVolume(SoundMix,SoundClass,NewValue);
}


void UAudioSettingsPanel::OnSFXVolumeChange(float Value)
{
	USoundMix* SoundMix = GetGameInstance()->GetAssetManager()->GetSoundMix();
	USoundClass* SoundClass = GetGameInstance()->GetAssetManager()->GetSFXSoundClass();
	float Max = GetGameInstance()->GetGameState()->GameDefaultData.GameSettings.Audio.SFXVolume.GetMax();
	float NewValue = Max * Value;
	this->SFXOptionWidget->SetSliderCurrentPercent(Value * 100);
	GetGameInstance()->GetAudioManager()->SetSFXVolume(SoundMix, SoundClass, Value);

}