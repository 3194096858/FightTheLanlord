﻿

#include "Widget/UserTipWidget.h"

#include "Components/CanvasPanel.h"

#include "Components/CanvasPanelSlot.h"
#include "Components/PanelSlot.h"

#include "GameInstance/FTL_GameInstance.h"

#include "Components/SizeBox.h"
#include "Components/Image.h"
#include "Components/TextBlock.h"

#include "Manager/FTL_AssetManager.h"
#include "Struct/GameProperty.h"
#include "Manager/DelegateManager.h"
#include "Manager/AudioManager.h"
#include "Widget/ButtonWidget.h"
#include "Widget/ResourcePanel.h"
#include "Manager/WidgetManager.h"

#include "Widget/TextBlockWidget.h"
#include "Widget/LoadingWidget.h"
#include "GameState/FTL_GameStateBase.h"

#include "Manager/FTL_TimerManager.h"




void UUserTipWidget::NativeOnInitialized()
{
	Super::NativeOnInitialized();
	SetVisibility(ESlateVisibility::HitTestInvisible);
}


void UUserTipWidget::NativeConstruct()
{
	Super::NativeConstruct();


}


void UUserTipWidget::NativePreConstruct()
{
	Super::NativePreConstruct();

}


void UUserTipWidget::NativeDestruct()
{
	Super::NativeDestruct();


}


void UUserTipWidget::PlayLoadingAnimation(bool IsForward)
{
	this->LoadingWidget->PlayLoadingAnimation(IsForward);

}





void UUserTipWidget::AddWidgetToCanvasPanel(UWidgetBase* Widget, const FVector2D& Size, const FAnchorData& AnchorData)
{
	UPanelSlot* PanelSlot = this->CanvasPanel->AddChild(Widget);
	UCanvasPanelSlot* CanvasPanelSlot = nullptr;
	CanvasPanelSlot = Cast<UCanvasPanelSlot>(PanelSlot);

	if (CanvasPanelSlot != nullptr && Widget != nullptr)
	{
		Widget->SetWidgetSize(Size);
		CanvasPanelSlot->SetAutoSize(true);
		CanvasPanelSlot->SetLayout(AnchorData);

	}



}


void UUserTipWidget::RemoveWidgetFromCanvasPanel(UWidgetBase* Widget)
{
	if (this->CanvasPanel->HasChild(Widget) == true)
	{
		this->CanvasPanel->RemoveChild(Widget);
	}

}
















