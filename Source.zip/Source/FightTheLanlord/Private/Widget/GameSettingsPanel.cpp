﻿

#include "Widget/GameSettingsPanel.h"


#include "Components/SizeBox.h"
#include "Components/Image.h"

#include "Manager/FTL_AssetManager.h"
#include "Struct/GameProperty.h"
#include "Manager/DelegateManager.h"
#include "Manager/AudioManager.h"
#include "Widget/ButtonWidget.h"
#include "Widget/TextBlockWidget.h"

#include "Manager/WidgetManager.h"

#include "GameState/FTL_GameStateBase.h"
#include "GameInstance/FTL_GameInstance.h"

#include "Widget/AudioSettingsPanel.h"

#include "Widget/DisplaySettingsPanel.h"
#include "Widget/OperationSettingsPanel.h"



void UGameSettingsPanel::NativeOnInitialized()
{
	Super::NativeOnInitialized();
	UTexture2D* Image = GetGameInstance()->GetAssetManager()->WidgetAsset.GameSettingsPanel.BackGroundImage.Image;
	float PlayRate = GetGameInstance()->GetGameState()->GameDefaultData.Widget.GameSettingsPanelAnimationPlayRate;
	SetAnimationPlayRate(PlayRate);
	this->BackGroundImage->SetBrushFromTexture(Image);
	InitializeReturnButton();
	InitializeResetButton();
	InitializeAudioButton();
	InitializeDisplayButton();
	InitializeOperationButton();

	GetGameInstance()->GetDelegateManager()->OnGameSettingsPanelOpen.AddUObject(this,&UGameSettingsPanel::OnGameSettingsPanelOpen);
	GetGameInstance()->GetDelegateManager()->OnGameSettingsPanelClose.AddUObject(this, &UGameSettingsPanel::OnGameSettingsPanelClose);
	this->ReturnButton->OnClick.BindUObject(this, &UGameSettingsPanel::OnClickReturnButton);
	this->ResetButton->OnClick.BindUObject(this, &UGameSettingsPanel::OnClickResetButton);
	this->AudioButton->OnClick.BindUObject(this, &UGameSettingsPanel::OnClickAudioButton);
	this->DisplayButton->OnClick.BindUObject(this, &UGameSettingsPanel::OnClickDisplayButton);
	this->OperationButton->OnClick.BindUObject(this, &UGameSettingsPanel::OnClickOperationButton);

}





void UGameSettingsPanel::NativePreConstruct()
{
	Super::NativePreConstruct();


}


void UGameSettingsPanel::NativeConstruct()
{
	Super::NativeConstruct();
	this->DisplaySettingsPanel->SetVisibility(ESlateVisibility::Visible);
	this->AudioSettingsPanel->SetVisibility(ESlateVisibility::Collapsed);
	this->OperationSettingsPanel->SetVisibility(ESlateVisibility::Collapsed);

}


void UGameSettingsPanel::NativeDestruct()
{
	Super::NativeDestruct();


}


void UGameSettingsPanel::InitializeAudioButton()
{
	
	FButtonWidgetData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.GameSettingsPanel.AudioButton;
	FButtonWidgetAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.GameSettingsPanel.AudioButton;
	GetGameInstance()->GetWidgetManager()->InitializeButton(this->AudioButton, Data, Asset);


}


void UGameSettingsPanel::InitializeDisplayButton()
{
	FButtonWidgetData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.GameSettingsPanel.DisplayButton;
	FButtonWidgetAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.GameSettingsPanel.DisplayButton;
	GetGameInstance()->GetWidgetManager()->InitializeButton(this->DisplayButton, Data, Asset);


}

void UGameSettingsPanel::InitializeOperationButton()
{
	FButtonWidgetData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.GameSettingsPanel.OperationButton;
	FButtonWidgetAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.GameSettingsPanel.OperationButton;
	GetGameInstance()->GetWidgetManager()->InitializeButton(this->OperationButton, Data, Asset);


}

void UGameSettingsPanel::InitializeReturnButton()
{
	
	FButtonWidgetData Data= GetGameInstance()->GetGameState()->GameDefaultData.Widget.GameSettingsPanel.ReturnButton;
	FButtonWidgetAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.GameSettingsPanel.ReturnButton;
	GetGameInstance()->GetWidgetManager()->InitializeButton(this->ReturnButton, Data, Asset);


}

void UGameSettingsPanel::InitializeResetButton()
{

	FButtonWidgetData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.GameSettingsPanel.ResetButton;
	FButtonWidgetAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.GameSettingsPanel.ResetButton;
	GetGameInstance()->GetWidgetManager()->InitializeButton(this->ResetButton, Data, Asset);


}
void UGameSettingsPanel::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	Super::OnAnimationFinished_Implementation(Animation);
	


}


void UGameSettingsPanel::OnClickReturnButton()
{
	GetGameInstance()->GetDelegateManager()->OnGameSettingsPanelClose.Broadcast();

}


void UGameSettingsPanel::OnClickResetButton()
{

}

void UGameSettingsPanel::OnClickAudioButton()
{
	if (this->AudioSettingsPanel->GetVisibility() == ESlateVisibility::Visible)
	{
		return;
	}
	this->AudioSettingsPanel->SetVisibility(ESlateVisibility::Visible);
	this->DisplaySettingsPanel->SetVisibility(ESlateVisibility::Collapsed);
	this->OperationSettingsPanel->SetVisibility(ESlateVisibility::Collapsed);




}

void UGameSettingsPanel::OnClickDisplayButton()
{
	if (this->DisplaySettingsPanel->GetVisibility() == ESlateVisibility::Visible)
	{
		return;
	}
	this->DisplaySettingsPanel->SetVisibility(ESlateVisibility::Visible);
	this->AudioSettingsPanel->SetVisibility(ESlateVisibility::Collapsed);
	this->OperationSettingsPanel->SetVisibility(ESlateVisibility::Collapsed);

}

void UGameSettingsPanel::OnClickOperationButton()
{
	if (this->OperationSettingsPanel->GetVisibility() == ESlateVisibility::Visible)
	{
		return;
	}
	this->OperationSettingsPanel->SetVisibility(ESlateVisibility::Visible);
	this->DisplaySettingsPanel->SetVisibility(ESlateVisibility::Collapsed);
	this->AudioSettingsPanel->SetVisibility(ESlateVisibility::Collapsed);

}



void UGameSettingsPanel::OnGameSettingsPanelOpen()
{
	GetGameInstance()->GetWidgetManager()->UpdateBackGroundImage(GetGameInstance(), TEXT("GameSettings"));
	FVector2D Size = GetGameInstance()->GetGameState()->GameDefaultData.Widget.GameSettingsPanel.Size;
	FAnchorData AnchorData = GetGameInstance()->GetGameState()->GameDefaultData.Widget.AnchorData;
	GetGameInstance()->GetWidgetManager()->OpenGameSettingsPanel(Size, AnchorData);
	GetGameInstance()->GetDelegateManager()->OnGameMainPageClose.Broadcast();





}



void UGameSettingsPanel::OnGameSettingsPanelClose()
{
	
	GetGameInstance()->GetWidgetManager()->CloseGameSettingsPanel(GetGameInstance());

	GetGameInstance()->GetDelegateManager()->OnGameMainPageOpen.Broadcast();



}

