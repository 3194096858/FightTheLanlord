﻿

#include "Widget/CountdownTimerWidget.h"



#include "Components/SizeBox.h"
#include "Components/Image.h"
#include "Components/TextBlock.h"
#include "Components/CircularThrobber.h"

#include "Manager/FTL_AssetManager.h"
#include "Struct/GameProperty.h"
#include "Manager/DelegateManager.h"
#include "Manager/AudioManager.h"
#include "Widget/ButtonWidget.h"
#include "Widget/ResourcePanel.h"
#include "Manager/WidgetManager.h"

#include "Widget/TextBlockWidget.h"
#include "GameInstance/FTL_GameInstance.h"

#include "GameState/FTL_GameStateBase.h"

#include "Manager/FTL_TimerManager.h"




void UCountdownTimerWidget::NativeOnInitialized()
{
	Super::NativeOnInitialized();

}


void UCountdownTimerWidget::NativeConstruct()
{
	Super::NativeConstruct();


}


void UCountdownTimerWidget::NativePreConstruct()
{
	Super::NativePreConstruct();

}


void UCountdownTimerWidget::NativeDestruct()
{
	Super::NativeDestruct();


}
void UCountdownTimerWidget::InitializeTextBlock(FTextBlockWidgetData Data, FTextBlockWidgetAsset Asset)
{
	GetGameInstance()->GetWidgetManager()->InitializeTextBlock(this->TextBlock,Data,Asset);
}
void UCountdownTimerWidget::SetCountdownTimerIcon(UTexture2D* NewIcon)
{
	this->TextBlock->SetBackGroundImage(NewIcon);

}

void UCountdownTimerWidget::SetText(int32 CurrentSecond)
{
	this->TextBlock->SetText(CurrentSecond);
}

void UCountdownTimerWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	////Super::OnAnimationFinished_Implementation(Animation);



}
