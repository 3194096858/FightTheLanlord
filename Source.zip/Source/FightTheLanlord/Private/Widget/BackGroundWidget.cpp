﻿

#include "Widget/BackGroundWidget.h"
#include "Components/CanvasPanel.h"
#include "Components/Image.h"
#include "Components/Button.h"
#include "GameInstance/FTL_GameInstance.h"
#include "Manager/WidgetManager.h"
#include "Components/CanvasPanelSlot.h"
#include "Components/PanelSlot.h"


void UBackGroundWidget::NativeConstruct()
{
	Super::NativeConstruct();
	this->Button->OnClicked.AddDynamic(this, &UBackGroundWidget::OnClickButton);
	this->Button->SetRenderOpacity(0.0f);

}


void UBackGroundWidget::NativePreConstruct()
{
	Super::NativePreConstruct();

}

void UBackGroundWidget::NativeDestruct()
{
	Super::NativeDestruct();


}


void UBackGroundWidget::SetBackGroundImage(UTexture2D* Texture)
{
	if (this->BackGroundImage == nullptr)
	{
		return;
	}
	this->BackGroundImage->SetBrushFromTexture(Texture);
    


}


void UBackGroundWidget::HideBackGroundImage()
{

	this->BackGroundImage->SetVisibility(ESlateVisibility::Collapsed);



}

void UBackGroundWidget::ShowBackGroundImage()
{

	this->BackGroundImage->SetVisibility(ESlateVisibility::HitTestInvisible);



}

void UBackGroundWidget::AddWidgetToCanvasPanel(UWidgetBase* Widget, const FVector2D& Size, const FAnchorData& AnchorData)
{
	UPanelSlot* PanelSlot = this->CanvasPanel->AddChild(Widget);
	UCanvasPanelSlot* CanvasPanelSlot = nullptr;
	CanvasPanelSlot = Cast<UCanvasPanelSlot>(PanelSlot);

	if (CanvasPanelSlot != nullptr && Widget != nullptr)
	{
		Widget->SetWidgetSize(Size);
		CanvasPanelSlot->SetAutoSize(true);
		CanvasPanelSlot->SetLayout(AnchorData);

	}


}


void UBackGroundWidget::RemoveWidgetFromCanvasPanel(UWidgetBase* Widget)
{
	if (this->CanvasPanel->HasChild(Widget) == true)
	{
		this->CanvasPanel->RemoveChild(Widget);
	}

}





void UBackGroundWidget::OnClickButton()
{
	///GEngine->AddOnScreenDebugMessage(-1,12.0f,FColor::Blue,TEXT(" Invalid Click !!!!!!"));
	TArray<UWidgetBase*> ActiveWidgetArray;
	ActiveWidgetArray = GetGameInstance()->GetWidgetManager()->GetAllActiveWidgetFromViewport(EWidgetRenderingLevel::HUD);
	if (ActiveWidgetArray.Num() >= 2)
	{
		GetGameInstance()->GetWidgetManager()->RemoveTopWidgetFromViewport(EWidgetRenderingLevel::HUD);
		GEngine->AddOnScreenDebugMessage(-1, 12.0f, FColor::Blue, TEXT(" Remove Widget!!!!!!"));

	}




}




