﻿

#include "Widget/ComboBoxItemWidget.h"

#include "Widget/ButtonWidget.h"
#include "Components/Image.h"
#include "Components/ComboBoxString.h"

#include "Components/TextBlock.h"
#include "Widget/TextBlockWidget.h"

#include "GameInstance/FTL_GameInstance.h"
#include "Manager/AudioManager.h"
#include "Manager/FTL_AssetManager.h"
#include "GameState/FTL_GameStateBase.h"
#include "Components/ScrollBox.h"



void UComboBoxItemWidget::NativeOnInitialized()
{
	Super::NativeOnInitialized();
	this->Button->OnClick.BindUObject(this, &UComboBoxItemWidget::OnClickButton);
	this->Button->SetIconVisibility(ESlateVisibility::Hidden);

}

void UComboBoxItemWidget::NativePreConstruct()
{
	Super::NativePreConstruct();
	
	

}


void UComboBoxItemWidget::NativeConstruct()
{
	Super::NativeConstruct();



}


void UComboBoxItemWidget::NativeDestruct()
{
	Super::NativeDestruct();


}


void UComboBoxItemWidget::SetIconImage(UTexture2D* NewIcon)
{
	this->Button->SetIconImage(NewIcon);
}


void UComboBoxItemWidget::SetBackGroundImage(UTexture2D* NewBackGround)
{
	this->Button->SetBackGroundImage(NewBackGround);

}


void UComboBoxItemWidget::SetBackGroundImageColor(const FColor& NewColor)
{
	this->Button->SetBackGroundImageColor(NewColor);

}


void UComboBoxItemWidget::SetIconColor(const FColor& NewColor)
{
	this->Button->SetIconColor(NewColor);


}




void UComboBoxItemWidget::SetIconSize(const FVector2D& NewSize)
{
	this->Button->SetIconSize(NewSize);


}


void UComboBoxItemWidget::SetText(const FText& NewText)
{
	this->Button->SetText(NewText);

}

void UComboBoxItemWidget::SetFontSize(int32 NewSize)
{
	this->Button->SetFontSize(NewSize);

}

void UComboBoxItemWidget::SetFontColor(const FColor& NewColor)
{
	this->Button->SetFontColor(NewColor);

}

void UComboBoxItemWidget::SetFontInformation(const FSlateFontInfo& NewFont)
{
	this->Button->SetFontInformation(NewFont);

}




void UComboBoxItemWidget::SetBackGroundImageVisibility(const ESlateVisibility& NewVisibility)
{
	this->Button->SetBackGroundImageVisibility(NewVisibility);


}

void UComboBoxItemWidget::SetIconVisibility(const ESlateVisibility& NewVisibility)
{
	this->Button->SetIconVisibility(NewVisibility);

}

void UComboBoxItemWidget::SetTextBlockVisibility(const ESlateVisibility& NewVisibility)
{
	this->Button->SetTextBlockVisibility(NewVisibility);

}



void UComboBoxItemWidget::SetIconOffsetPosition(const FVector2D& OffsetPosition)
{
	this->Button->SetIconRelativePosition(OffsetPosition);

}

void UComboBoxItemWidget::SetTextOffsetPosition(const FVector2D& OffsetPosition)
{
	this->Button->SetTextRelativePosition(OffsetPosition);

}



void UComboBoxItemWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{



}

void UComboBoxItemWidget::OnClickButton()
{
	FString SelectedItem;
	this->Button->GetText(SelectedItem);
	ESelectInfo::Type SelectionInfo = ESelectInfo::OnKeyPress;
	this->OnSelectionChange.ExecuteIfBound(SelectedItem,SelectionInfo);

}
