﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "Widget/CardHandWidget.h"


#include "Components/SizeBox.h"
#include "Components/Image.h"
#include "Components/OverLay.h"

#include "Components/TextBlock.h"
#include "Components/CircularThrobber.h"
#include "Widget/CardWidget.h"
#include "GlobalStaticFunctionLibrary/GlobalStaticFunctionLibrary.h"
#include "Manager/FTL_AssetManager.h"
#include "Struct/GameProperty.h"
#include "Manager/DelegateManager.h"
#include "Manager/AudioManager.h"
#include "Widget/ButtonWidget.h"
#include "Widget/ResourcePanel.h"
#include "Manager/WidgetManager.h"
#include "Struct/CardInformation.h"

#include "Widget/TextBlockWidget.h"
#include "GameInstance/FTL_GameInstance.h"

#include "GameState/FTL_GameStateBase.h"

#include "Manager/FTL_TimerManager.h"




void UCardHandWidget::NativeOnInitialized()
{
	Super::NativeOnInitialized();
	GetGameInstance()->GetDelegateManager()->OnLocalPlayerPlayCardSucceed.AddUObject(this, &UCardHandWidget::OnLocalPlayerPlayCardSucceed);
	GetGameInstance()->GetDelegateManager()->OnDealCardComplete.AddUObject(this, &UCardHandWidget::OnDealCardComplete);
	GetWorld()->GetTimerManager().SetTimer(this->DealCardTimerHandle, this, &UCardHandWidget::ShowCard, 0.5f, true);
	GetWorld()->GetTimerManager().PauseTimer(this->DealCardTimerHandle);
}


void UCardHandWidget::NativeConstruct()
{
	Super::NativeConstruct();

}


void UCardHandWidget::NativePreConstruct()
{
	Super::NativePreConstruct();

}


void UCardHandWidget::NativeDestruct()
{
	Super::NativeDestruct();


}



void UCardHandWidget::PlayDealCardAnimation()
{
	for (auto& Element : this->Overlay->GetAllChildren())
	{
		Element->SetVisibility(ESlateVisibility::Hidden);

	}
	GetWorld()->GetTimerManager().UnPauseTimer(this->DealCardTimerHandle);


}

void UCardHandWidget::ShowCard()
{
	static int32 Index = 0;
	TArray<UWidget*> Array = this->Overlay->GetAllChildren();
	if (Index == Array.Num())
	{
		GetGameInstance()->GetDelegateManager()->OnDealCardComplete.Broadcast();
		GetWorld()->GetTimerManager().PauseTimer(this->DealCardTimerHandle);
		Index = 0;
		return;
	}
	if (Array.IsValidIndex(Index) == true)
	{
		Array[Index]->SetVisibility(ESlateVisibility::HitTestInvisible);
		Index++;

	}
	


}

void UCardHandWidget::AddCard(UCardWidget* Card)
{
	if(Card==nullptr)
	{
		return;
	}
	if (this->Overlay->HasChild(Card) ==true)
	{
		return;
	}
	this->Overlay->AddChild(Card);
}

void UCardHandWidget::RemoveCard(UCardWidget* Card)
{
	if (this->Overlay->HasChild(Card) == false)
	{
		return;
	}
	Card->SetVisibility(ESlateVisibility::Collapsed);
	GetGameInstance()->GetWidgetManager()->ReturnCardWidget(Card);
	this->Overlay->RemoveChild(Card);

}

TArray<UCardWidget*> UCardHandWidget::GetAllCard()
{
	TArray<UCardWidget*> Array;
	UCardWidget* Widget = nullptr;
	for (auto& Element : this->Overlay->GetAllChildren())
	{
		Widget = Cast<UCardWidget>(Element);
		if (Widget!=nullptr)
		{
			Array.Add(Widget);
		}
	}
	return Array;
}

void UCardHandWidget::Clear()
{
	for (auto& Element : GetAllCard())
	{
		Element->SetVisibility(ESlateVisibility::Collapsed);
		GetGameInstance()->GetWidgetManager()->ReturnCardWidget(Element);
	}
	this->Overlay->ClearChildren();
}


void UCardHandWidget::UpdateCardRelativeTransform()
{
	TArray<UCardWidget*> Array = GetAllCard();
	FVector2D Position;
	FVector2D Size = GetGameInstance()->GetGameState()->GameDefaultData.Widget.OperationPanel.CardHand.CardSize;
	int32 Index = 0;
	float HoriontalInterval = 50.0f;
	float VerticalInterval = 0.0f;

	for (auto& Element : Array)
	{
		Index++;
		Position.X = HoriontalInterval * Index;
		Element->SetRelativePosition(Position);
		Element->SetWidgetSize(Size);

	}

}

void UCardHandWidget::SortByValue()
{
	UTexture2D* Image = nullptr;
	FCardInformation t ;
	bool IsFinish = true;
	TArray<UCardWidget*> WidgetArray = GetGameInstance()->GetWidgetManager()->GetAllCardFromCardHand();
	TArray<FCardInformation> InformationArray = GetGameInstance()->GetWidgetManager()->GetAllActiveCardInformation();
	for (int32 i = 0; i < InformationArray.Num(); i++)
	{
		IsFinish = true;
		for (int32 j = 0; j < InformationArray.Num() -1 -i; j++)
		{
			if (InformationArray[j].Value > InformationArray[j + 1].Value)
			{
				t = InformationArray[j];
				InformationArray[j] = InformationArray[j+1];
				InformationArray[j + 1] = t;
				IsFinish = false;
			}
		}
		if (IsFinish ==true)
		{
			break;
		}
	}
	for (int32 i = 0; i < InformationArray.Num(); i++)
	{
		
		Image = GetGameInstance()->GetAssetManager()->GetCardImage(InformationArray[i].Name, InformationArray[i].Suit);
		WidgetArray[i]->SetImage(Image);
		WidgetArray[i]->SetCardInformation(InformationArray[i]);
	}

	

}



void UCardHandWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	Super::OnAnimationFinished_Implementation(Animation);


}




void UCardHandWidget::OnLocalClientGameStateCompleteInitialize()
{
	Super::OnLocalClientGameStateCompleteInitialize();
	

}


void UCardHandWidget::OnServerGameStateCompleteInitialize()
{
	Super::OnServerGameStateCompleteInitialize();

}



void UCardHandWidget::OnLocalClientPlayerControllerCompleteInitialize()
{
	Super::OnLocalClientPlayerControllerCompleteInitialize();
	UpdateCardRelativeTransform();
	SortByValue();
	/*for (auto& Element : GetAllCard())
	{
		FName Name = UGlobalStaticFunctionLibrary::GetNameByEnum(Element->GetCardInformation().Suit);
		UE_LOG(LogTemp, Warning, TEXT("    CardHand   :  CardName = %s, CardSuit = %s  "), *Element->GetCardInformation().Name.ToString(), *Name.ToString());

	}*/
}

void UCardHandWidget::OnLocalPlayerPlayCardSucceed()
{
	UpdateCardRelativeTransform();

}



void UCardHandWidget::OnDealCardComplete()
{
	for (auto& Element : this->Overlay->GetAllChildren())
	{
		Element->SetVisibility(ESlateVisibility::Visible);
	}
}

