﻿

#include "Widget/ButtonWidget.h"


#include "Components/Button.h"
#include "Components/Image.h"
#include "Components/TextBlock.h"
#include "Widget/TextBlockWidget.h"
#include "GameInstance/FTL_GameInstance.h"
#include "Manager/AudioManager.h"
#include "Manager/FTL_AssetManager.h"
#include "GameState/FTL_GameStateBase.h"




void UButtonWidget::NativeOnInitialized()
{
	Super::NativeOnInitialized();
	float PlayRate = GetGameInstance()->GetGameState()->GameDefaultData.Widget.ButtonAnimationPlayRate;
	this->Button->OnClicked.AddDynamic(this, &UButtonWidget::OnClickButton);
	this->Button->OnPressed.AddDynamic(this, &UButtonWidget::OnPressButton);
	this->Button->OnReleased.AddDynamic(this, &UButtonWidget::OnReleaseButton);
	SetAnimationPlayRate(PlayRate);
	this->Button->SetRenderOpacity(0.0f);
	SetIconVisibility(ESlateVisibility::HitTestInvisible);
	SetBackGroundImageVisibility(ESlateVisibility::HitTestInvisible);
	SetTextBlockVisibility(ESlateVisibility::HitTestInvisible);
	SetTextBackGroundImageVisibility(ESlateVisibility::Collapsed);


}

void UButtonWidget::NativePreConstruct()
{
	Super::NativePreConstruct();
	

}


void UButtonWidget::NativeConstruct()
{
	Super::NativeConstruct();


}


void UButtonWidget::NativeDestruct()
{
	Super::NativeDestruct();


}



void UButtonWidget::SetIconImage(UTexture2D* NewIcon)
{
	this->Icon->SetBrushFromTexture(NewIcon);

}


void UButtonWidget::SetBackGroundImage(UTexture2D* NewBackGround)
{
	this->BackGroundImage->SetBrushFromTexture(NewBackGround);


}


void UButtonWidget::SetBackGroundImageColor(const FColor& NewColor)
{

	this->BackGroundImage->SetBrushTintColor(NewColor);

}


void UButtonWidget::SetIconColor(const FColor& NewColor)
{
	this->Icon->SetBrushTintColor(NewColor);


}


void UButtonWidget::SetIconSize(float NewSize)
{
	/*if (this->IconSlateBrush.GetResourceObject() == nullptr)
	//{
		return;
	}
	
	this->IconSlateBrush.ImageSize = NewSize * this->IconOriginalSize;
	this->IconSlateBrush.SetImageSize(NewSize * this->IconOriginalSize);*/



}



void UButtonWidget::SetIconSize(const FVector2D& NewSize)
{
	
	this->Icon->Brush.SetImageSize(NewSize);

}


void UButtonWidget::SetText(const FText& NewText)
{
	this->TextBlock->SetText(NewText);

}

void UButtonWidget::SetText(const FString& NewText)
{
	this->TextBlock->SetText(NewText);

}

void UButtonWidget::SetFontSize(int32 NewSize)
{
	this->TextBlock->SetFontSize(NewSize);

}

void UButtonWidget::SetFontColor(const FColor& NewColor)
{
	this->TextBlock->SetFontColor(NewColor);

}

void UButtonWidget::SetFontInformation(const FSlateFontInfo& NewFont)
{
	this->TextBlock->SetFontInformation(NewFont);

}



void UButtonWidget::SetIconSlateBrush(const FSlateBrush& NewSlateBrush)
{
	this->Icon->SetBrush(NewSlateBrush);


}

void UButtonWidget::SetBackGroundImageSlateBrush(const FSlateBrush& NewSlateBrush)
{
	this->BackGroundImage->SetBrush(NewSlateBrush);

}

void UButtonWidget::SetTextBackGroundImageVisibility(const ESlateVisibility& NewVisibility)
{
	this->TextBlock->SetBackGroundImageVisibility(NewVisibility);


}


void UButtonWidget::SetBackGroundImageVisibility(const ESlateVisibility& NewVisibility)
{
	this->BackGroundImage->SetVisibility(NewVisibility);


}

void UButtonWidget::SetIconVisibility(const ESlateVisibility& NewVisibility)
{
	this->Icon->SetVisibility(NewVisibility);


}

void UButtonWidget::SetTextBlockVisibility(const ESlateVisibility& NewVisibility)
{
	this->TextBlock->SetVisibility(NewVisibility);


}



void UButtonWidget::SetIconRelativePosition(const FVector2D& NewPosition)
{
	this->Icon->SetRenderTranslation(NewPosition);

}

void UButtonWidget::SetTextRelativePosition(const FVector2D& NewPosition)
{
	this->TextBlock->SetRelativePosition(NewPosition);

}


void UButtonWidget::OnClickButton()
{
	this->OnClick.ExecuteIfBound();
	USoundBase* ClickSFX = GetGameInstance()->GetAssetManager()->GetSFX(TEXT("ButtonClick"));
	if (ClickSFX != nullptr)
	{
		GetGameInstance()->GetAudioManager()->PlaySFX(ClickSFX);
	}


}


void UButtonWidget::OnPressButton()
{
	this->OnPress.ExecuteIfBound();
	if (this->WidgetAnimation == nullptr)
	{
		return;
	}
	float StartAtTime = 0.0f;
	int32 NumberLoopsToPlay = 1;
	EUMGSequencePlayMode::Type PlayMode = EUMGSequencePlayMode::Forward;
	int32 PlayRate = this->AnimationPlayRate.GetCurrent();
	PlayAnimation(this->WidgetAnimation, StartAtTime, NumberLoopsToPlay, PlayMode, PlayRate);



}


void UButtonWidget::OnReleaseButton()
{
	this->OnRelease.ExecuteIfBound();

	if (this->WidgetAnimation == nullptr)
	{
		return;
	}
	float StartAtTime = 0.0f;
	int32 NumberLoopsToPlay = 1;
	EUMGSequencePlayMode::Type PlayMode = EUMGSequencePlayMode::Reverse;
	int32 PlayRate = this->AnimationPlayRate.GetCurrent();
	PlayAnimation(this->WidgetAnimation, StartAtTime, NumberLoopsToPlay, PlayMode, PlayRate);


}


void UButtonWidget::GetText(FText& Result)
{
	this->TextBlock->GetText(Result);
}

void UButtonWidget::GetText(FString& Result)
{
	this->TextBlock->GetText(Result);

}

void UButtonWidget::GetText(int32& Result)
{
	this->TextBlock->GetText(Result);

}

void UButtonWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{



}













