﻿

#include "Widget/CheckBoxWidget.h"


#include "Components/Button.h"
#include "Components/Image.h"
#include "Components/CheckBox.h"

#include "Components/TextBlock.h"
#include "Widget/TextBlockWidget.h"

#include "GameInstance/FTL_GameInstance.h"
#include "Manager/AudioManager.h"
#include "Manager/FTL_AssetManager.h"
////#include "GameState/FTL_GameStateBase.h"




void UCheckBoxWidget::NativeOnInitialized()
{
	Super::NativeOnInitialized();
	this->CheckBox->OnCheckStateChanged.AddDynamic(this, &UCheckBoxWidget::OnCheckStateChange);



}

void UCheckBoxWidget::NativePreConstruct()
{
	Super::NativePreConstruct();
	

}


void UCheckBoxWidget::NativeConstruct()
{
	Super::NativeConstruct();


}


void UCheckBoxWidget::NativeDestruct()
{
	Super::NativeDestruct();


}


void UCheckBoxWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{



}


void UCheckBoxWidget::OnCheckStateChange(bool IsCheck)
{
	OnStateChange.ExecuteIfBound(IsCheck);
	
	
}



void UCheckBoxWidget::SetStyle(const FSlateBrush& Uncheck, const FSlateBrush& Check)
{
	/*this->UncheckSlateBrush = Uncheck;
	this->CheckSlateBrush = Check;
	Style.SetUncheckedImage(Uncheck);
	Style.SetCheckedImage(Check);
	Style.SetCheckBoxType(ESlateCheckBoxType::ToggleButton);
	this->CheckBox->SetWidgetStyle(Style);*/


}