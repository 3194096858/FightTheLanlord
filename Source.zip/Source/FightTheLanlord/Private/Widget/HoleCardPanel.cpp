﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "Widget/HoleCardPanel.h"


#include "Widget/CardWidget.h"
#include "Components/Overlay.h"

#include "Components/Button.h"
#include "Components/Image.h"
#include "Components/TextBlock.h"
#include "Widget/TextBlockWidget.h"
#include "GameInstance/FTL_GameInstance.h"
#include "Manager/AudioManager.h"
#include "Manager/FTL_AssetManager.h"
#include "GameState/FTL_GameStateBase.h"
#include "Widget/CountdownTimerWidget.h"
#include "Widget/CardHandWidget.h"
#include "Widget/ButtonWidget.h"
#include "PlayerController/BattleLevelPlayerController.h"
#include "Manager/DelegateManager.h"
#include "PlayerState/FTL_PlayerStateBase.h"
#include "Manager/WidgetManager.h"
#include "Components/OverlaySlot.h"


void UHoleCardPanel::NativeOnInitialized()
{
	Super::NativeOnInitialized();
	FHoleCardPanelData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.HoleCardPanel;
	FHoleCardPanelAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.HoleCardPanel;
	float PlayRate = GetGameInstance()->GetGameState()->GameDefaultData.Widget.PlayerPanelAnimationPlayRate;
	SetAnimationPlayRate(PlayRate);
	SetWidgetSize(Data.Size);
	SetRelativePosition(Data.RelativePosition);
	GetGameInstance()->GetDelegateManager()->OnHoleCardPanelOpen.AddUObject(this, &UHoleCardPanel::OnHoleCardPanelOpen);
	GetGameInstance()->GetDelegateManager()->OnHoleCardPanelClose.AddUObject(this, &UHoleCardPanel::OnHoleCardPanelClose);
	this->BackGroundImage->SetBrushFromTexture(Asset.BackGroundImage.Image);
	this->BackGroundImage->SetBrushTintColor(Data.BackGroundImage.Color);
	GetGameInstance()->GetDelegateManager()->OnDealCardComplete.AddUObject(this, &UHoleCardPanel::OnDealCardComplete);


	GetGameInstance()->GetDelegateManager()->OnGameOver.AddUObject(this, &UHoleCardPanel::OnGameOver);





}

void UHoleCardPanel::NativePreConstruct()
{
	Super::NativePreConstruct();


}


void UHoleCardPanel::NativeConstruct()
{
	Super::NativeConstruct();

}


void UHoleCardPanel::NativeDestruct()
{
	Super::NativeDestruct();


}


void UHoleCardPanel::AddWidgetToOverlay(UWidgetBase* Widget)
{
	UPanelSlot* PanelSlot = this->Overlay->AddChild(Widget);
	UOverlaySlot* OverlaySlot = Cast<UOverlaySlot>(PanelSlot);
	if (OverlaySlot == nullptr)
	{
		return;
	}
	OverlaySlot->SetHorizontalAlignment(EHorizontalAlignment::HAlign_Left);
	OverlaySlot->SetVerticalAlignment(EVerticalAlignment::VAlign_Center);


}

void UHoleCardPanel::AddCard(const TArray<FCardInformation>& CardArray)
{

	UCardWidget* Widget = nullptr;
	UTexture2D* Image = nullptr;
	for (auto& Element : CardArray)
	{
		Widget = GetGameInstance()->GetWidgetManager()->GetCardWidget(GetGameInstance());
		if (Widget == nullptr)
		{
			GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Red, TEXT("HoleCardPanel: Widget == nullptr"));
		}
		if (Widget != nullptr && this->Overlay->HasChild(Widget) == false)
		{
			Image = GetGameInstance()->GetAssetManager()->GetCardImage(Element.Name, Element.Suit);
			Widget->SetImage(Image);
			AddWidgetToOverlay(Widget);
			UpdateCardRelativeTransform();

			////GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Red, TEXT("HoleCardPanel: AddWidget !!!!!"));

		}
		
	}

}

void UHoleCardPanel::RemoveCard(UCardWidget* Card)
{
	if (this->Overlay->HasChild(Card) == false)
	{
		return;
	}
	GetGameInstance()->GetWidgetManager()->ReturnCardWidget(Card);
	this->Overlay->RemoveChild(Card);

}

void UHoleCardPanel::Clear()
{
	for (auto& Element : GetAllCard())
	{
		Element->SetVisibility(ESlateVisibility::Collapsed);
		GetGameInstance()->GetWidgetManager()->ReturnCardWidget(Element);
	}
	this->Overlay->ClearChildren();
}

TArray<UCardWidget*> UHoleCardPanel::GetAllCard()
{
	TArray<UCardWidget*> Array;
	UCardWidget* Widget = nullptr;
	for (auto& Element : this->Overlay->GetAllChildren())
	{
		Widget = Cast<UCardWidget>(Element);
		if (Widget != nullptr)
		{
			Array.Add(Widget);
		}
	}
	return Array;
}

void UHoleCardPanel::UpdateCardRelativeTransform()
{
	TArray<UCardWidget*> Array = GetAllCard();
	FVector2D Position;
	FVector2D Size = GetGameInstance()->GetGameState()->GameDefaultData.Widget.HoleCardPanel.CardSize;
	int32 Index = 0;
	float HoriontalInterval = 95.0f;
	float VerticalInterval = 0.0f;

	for (auto& Element : Array)
	{
		Index++;
		Position.X = HoriontalInterval * Index;
		Element->SetRelativePosition(Position);
		Element->SetWidgetSize(Size);

	}

}




void UHoleCardPanel::OnHoleCardPanelOpen()
{

	FVector2D Size = GetGameInstance()->GetGameState()->GameDefaultData.Widget.HoleCardPanel.Size;
	FAnchorData AnchorData = GetGameInstance()->GetGameState()->GameDefaultData.Widget.AnchorData;
	GetGameInstance()->GetWidgetManager()->OpenHoleCardPanel(Size, AnchorData);

}

void UHoleCardPanel::OnHoleCardPanelClose()
{
	GetGameInstance()->GetWidgetManager()->CloseHoleCardPanel();
	Clear();


}


void UHoleCardPanel::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	Super::OnAnimationFinished_Implementation(Animation);


}



void UHoleCardPanel::OnDealCardComplete()
{
	///OnHoleCardPanelOpen();
	//UpdateCardRelativeTransform();

}



void UHoleCardPanel::OnGameOver(bool IsLanlordWin)
{
	OnHoleCardPanelClose();
}


