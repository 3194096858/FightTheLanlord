﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "Widget/MessageWidget.h"


#include "Components/SizeBox.h"
#include "Components/Image.h"

#include "Manager/FTL_AssetManager.h"
#include "Struct/GameProperty.h"
#include "Manager/DelegateManager.h"
#include "Manager/AudioManager.h"
#include "Widget/ButtonWidget.h"
#include "Widget/TextBlockWidget.h"
#include "Manager/GameSessionManager.h"

#include "Manager/WidgetManager.h"
#include "Manager/LevelManager.h"

#include "GameState/FTL_GameStateBase.h"
#include "GameInstance/FTL_GameInstance.h"





void UMessageWidget::NativeOnInitialized()
{
	Super::NativeOnInitialized();
	FMessageWidgetData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.MessageWidget;
	FTextBlockWidgetAsset Asset;
	GetGameInstance()->GetWidgetManager()->InitializeTextBlock(this->TextBlock, Data.TextBlock, Asset);
	SetWidgetSize(Data.Size);
	SetRelativePosition(Data.RelativePosition);
}





void UMessageWidget::NativePreConstruct()
{
	Super::NativePreConstruct();


}


void UMessageWidget::NativeConstruct()
{
	Super::NativeConstruct();


}


void UMessageWidget::NativeDestruct()
{
	Super::NativeDestruct();


}


void UMessageWidget::SetMessage(int32 PlayerID, const FString& NewMessage)
{
	FString Text = TEXT("玩家") + FString::FromInt(PlayerID) + TEXT(": ") + NewMessage;
	this->TextBlock->SetText(Text);

}

void UMessageWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{



}

