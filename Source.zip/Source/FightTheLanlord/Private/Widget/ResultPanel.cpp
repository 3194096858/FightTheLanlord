﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "Widget/ResultPanel.h"


#include "Widget/CardWidget.h"

#include "Components/Button.h"
#include "Components/Image.h"
#include "Components/TextBlock.h"
#include "Widget/TextBlockWidget.h"
#include "GameInstance/FTL_GameInstance.h"
#include "Manager/AudioManager.h"
#include "Manager/FTL_AssetManager.h"
#include "GameState/FTL_GameStateBase.h"
#include "Widget/CountdownTimerWidget.h"
#include "Widget/CardHandWidget.h"
#include "Widget/ButtonWidget.h"
#include "PlayerController/BattleLevelPlayerController.h"
#include "Manager/DelegateManager.h"
#include "PlayerState/FTL_PlayerStateBase.h"
#include "Manager/WidgetManager.h"
#include "Manager/FTL_TimerManager.h"
#include "Manager/GameSessionManager.h"
#include "Manager/LevelManager.h"


void UResultPanel::NativeOnInitialized()
{
	Super::NativeOnInitialized();
	FResultPanelData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.ResultPanel;
	FResultPanelAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.ResultPanel;
	float PlayRate = GetGameInstance()->GetGameState()->GameDefaultData.Widget.PlayerPanelAnimationPlayRate;
	SetAnimationPlayRate(PlayRate);
	SetWidgetSize(Data.Size);
	SetRelativePosition(Data.RelativePosition);
	////this->ReturnButton->OnClick.BindUObject(this, &UResultPanel::OnClickReturnButton);
	this->QuitButton->OnClick.BindUObject(this, &UResultPanel::OnClickQuitButton);
	GetGameInstance()->GetDelegateManager()->OnResultPanelOpen.AddUObject(this, &UResultPanel::OnResultPanelOpen);
	GetGameInstance()->GetDelegateManager()->OnResultPanelClose.AddUObject(this, &UResultPanel::OnResultPanelClose);
	this->BackGroundImage->SetBrushFromTexture(Asset.BackGroundImage.Image);
	this->BackGroundImage->SetBrushTintColor(Data.BackGroundImage.Color);
	///InitializeReturnButton();
	InitializeQuitButton();
	InitializeGameOverTextBlock();
	InitializeGameResultTextBlock();
	GetGameInstance()->GetDelegateManager()->OnGameOver.AddUObject(this, &UResultPanel::OnGameOver);
	this->ReturnButton->SetVisibility(ESlateVisibility::Collapsed);
}

void UResultPanel::NativePreConstruct()
{
	Super::NativePreConstruct();


}


void UResultPanel::NativeConstruct()
{
	Super::NativeConstruct();
	
}


void UResultPanel::NativeDestruct()
{
	Super::NativeDestruct();


}


void UResultPanel::InitializeReturnButton()
{
	FButtonWidgetData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.ResultPanel.ReturnButton;
	FButtonWidgetAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.ResultPanel.ReturnButton;
	GetGameInstance()->GetWidgetManager()->InitializeButton(this->ReturnButton, Data, Asset);

}
void UResultPanel::InitializeQuitButton()
{
	FButtonWidgetData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.ResultPanel.QuitButton;
	FButtonWidgetAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.ResultPanel.QuitButton;
	GetGameInstance()->GetWidgetManager()->InitializeButton(this->QuitButton, Data, Asset);

}

void UResultPanel::InitializeGameOverTextBlock()
{
	FTextBlockWidgetData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.ResultPanel.GameOverTextBlock;
	FTextBlockWidgetAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.ResultPanel.GameOverTextBlock;
	GetGameInstance()->GetWidgetManager()->InitializeTextBlock(this->GameOverTextBlock, Data, Asset);


}
void UResultPanel::InitializeGameResultTextBlock()
{

	FTextBlockWidgetData Data = GetGameInstance()->GetGameState()->GameDefaultData.Widget.ResultPanel.GameResultTextBlock;
	FTextBlockWidgetAsset Asset = GetGameInstance()->GetAssetManager()->WidgetAsset.ResultPanel.GameResultTextBlock;
	GetGameInstance()->GetWidgetManager()->InitializeTextBlock(this->GameResultTextBlock, Data, Asset);

}


void UResultPanel::SetGameResultTextBlockText(const FString& NewText)
{
	this->GameResultTextBlock->SetText(NewText);
}

void UResultPanel::QuitSession()
{
	GetGameInstance()->GetGameSessionManager()->QuitCurrentSession();
	GetWorld()->GetTimerManager().ClearTimer(this->QuitSessionTimerHandle);

}

void UResultPanel::OnResultPanelOpen()
{
	FVector2D Size = GetGameInstance()->GetGameState()->GameDefaultData.Widget.ResultPanel.Size;
	FAnchorData AnchorData = GetGameInstance()->GetGameState()->GameDefaultData.Widget.AnchorData;
	GetGameInstance()->GetWidgetManager()->OpenResultPanel(Size, AnchorData);
	this->QuitButton->SetVisibility(ESlateVisibility::Visible);
	this->QuitButton->SetRenderOpacity(1.0f);

}

void UResultPanel::OnResultPanelClose()
{
	GetGameInstance()->GetWidgetManager()->CloseResultPanel();


}


void UResultPanel::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	Super::OnAnimationFinished_Implementation(Animation);


}


void UResultPanel::OnClickReturnButton()
{


}


void UResultPanel::OnClickQuitButton()
{
	if (GetIsInServer() == true)
	{
		APlayerControllerBase* Controller = nullptr;
		for (auto& Element : GetGameInstance()->GetGameState()->PlayerArray)
		{
			Controller = Cast<APlayerControllerBase>(Element->GetPlayerController());
			if (Controller != GetOwningPlayer())
			{
				Controller->Client_QuitSession();
			}

		}
		GetWorld()->GetTimerManager().SetTimer(this->QuitSessionTimerHandle,this, &UResultPanel::QuitSession, 1.0f,false);
	}
	else
	{
		GetGameInstance()->GetGameSessionManager()->QuitCurrentSession();

	}
	this->QuitButton->SetVisibility(ESlateVisibility::HitTestInvisible);
	this->QuitButton->SetRenderOpacity(0.5f);

}


void UResultPanel::OnGameOver(bool IsLanlordWin)
{
	if (IsLanlordWin == true)
	{
		SetGameResultTextBlockText(TEXT("地主获胜"));
	}
	else
	{
		SetGameResultTextBlockText(TEXT("农民获胜"));

	}
	OnResultPanelOpen();
	
}



