﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "Widget/ComboBoxWidget.h"


#include "Components/Button.h"
#include "Components/Image.h"
#include "Components/ComboBoxString.h"
#include "Components/SizeBox.h"

#include "Components/TextBlock.h"
#include "Widget/TextBlockWidget.h"
#include "Widget/ComboBoxItemWidget.h"
#include "Widget/ButtonWidget.h"
#include "Widget/ComboBoxMenuWidget.h"
#include "GameInstance/FTL_GameInstance.h"
#include "Manager/AudioManager.h"
#include "Manager/WidgetManager.h"

#include "Manager/FTL_AssetManager.h"
#include "GameState/FTL_GameStateBase.h"
#include "Components/ScrollBox.h"
#include "Kismet/GameplayStatics.h"



UComboBoxWidget::UComboBoxWidget()
{


}



void UComboBoxWidget::NativeOnInitialized()
{
	Super::NativeOnInitialized();
	float PlayRate = GetGameInstance()->GetGameState()->GameDefaultData.Widget.ComboBoxAnimationPlayRate;
	SetAnimationPlayRate(PlayRate);

	this->Button->OnClick.BindUObject(this, &UComboBoxWidget::OnMenuOpen);
	

}

void UComboBoxWidget::NativePreConstruct()
{
	Super::NativePreConstruct();
	
}


void UComboBoxWidget::NativeConstruct()
{
	Super::NativeConstruct();
	


}


void UComboBoxWidget::NativeDestruct()
{
	Super::NativeDestruct();


}

void UComboBoxWidget::SetDownArrowSlateBrush(const FSlateBrush& NewSlateBrush)
{
	
	this->Button->SetIconSlateBrush(NewSlateBrush);

}

void UComboBoxWidget::SetDownArrowVisibility(const ESlateVisibility& NewVisibility)
{
	this->Button->SetIconVisibility(NewVisibility);

}

void UComboBoxWidget::SetButtonSlateBrush(const FSlateBrush& NewSlateBrush)
{
	this->Button->SetBackGroundImageSlateBrush(NewSlateBrush);


}



UComboBoxMenuWidget* UComboBoxWidget::GetMenu()
{
	if (this->Menu == nullptr)
	{
		FString WidgetName = TEXT("ComboBoxMenuWidget");
		UClass* WidgetClass = GetGameInstance()->GetAssetManager()->GetWidgetClass(WidgetName);
		this->Menu = GetGameInstance()->GetWidgetManager()->SpawnWidget<UComboBoxMenuWidget>(WidgetClass);
	
	}
	return this->Menu;


}

void UComboBoxWidget::OpenMenu(const FVector2D& Size, const FAnchorData& AnchorData)
{
	GetGameInstance()->GetWidgetManager()->OpenComboBoxMenu(GetMenu(), Size, AnchorData);

}


void UComboBoxWidget::CloseMenu()
{
	GetGameInstance()->GetWidgetManager()->CloseComboBoxMenu(GetMenu());


}

void UComboBoxWidget::AddOption(const FString& Target, const FMargin& ItemPadding)
{
	FString WidgetName = TEXT("ComboBoxItemWidget");
	UClass* WidgetClass = GetGameInstance()->GetAssetManager()->GetWidgetClass(WidgetName);
	if (WidgetClass == nullptr)
	{
		return;
	}

	UComboBoxItemWidget* Item = GetGameInstance()->GetWidgetManager()->SpawnWidget<UComboBoxItemWidget>(WidgetClass);
	if (Item == nullptr)
	{

		return;
	}
	GetMenu()->AddItem(Item, ItemPadding);
	Item->SetText(FText::FromString(Target));
	Item->OnSelectionChange.BindUObject(this, &UComboBoxWidget::OnSelectionUpdate);

}


void UComboBoxWidget::SetMenuAnimationPlayRate(float NewPlayRate)
{
	GetMenu()->SetAnimationPlayRate(NewPlayRate);
	
}

void UComboBoxWidget::SetMenuSize(const FVector2D& NewSize)
{
	GetMenu()->SetWidgetSize(NewSize);

}


FVector2D UComboBoxWidget::GetMenuSzie()
{

	return GetMenu()->GetWidgetSize();
}


void UComboBoxWidget::SetMenuRelativePosition(const FVector2D& NewPosition)
{
	GetMenu()->SetRenderTranslation(NewPosition);

}


void UComboBoxWidget::ShowMenuScrollBar()
{
	GetMenu()->SetScrollBarVisibility(ESlateVisibility::Visible);

}


void UComboBoxWidget::HideMenuScrollBar()
{
	GetMenu()->SetScrollBarVisibility(ESlateVisibility::Collapsed);


}

void UComboBoxWidget::SetButtonRelativePosition(const FVector2D& NewPosition)
{
	this->Button->SetRelativePosition(NewPosition);

}


void UComboBoxWidget::SetButtonTextRelativePosition(const FVector2D& NewPosition)
{
	this->Button->SetTextRelativePosition(NewPosition);

}


void UComboBoxWidget::SetButtonFontSize(int32 NewSize)
{
	this->Button->SetFontSize(NewSize);
}

void UComboBoxWidget::SetButtonFontColor(const FColor& NewColor)
{

	this->Button->SetFontColor(NewColor);

}

void UComboBoxWidget::SetButtonFontInformation(const FSlateFontInfo& NewFont)
{
	this->Button->SetFontInformation(NewFont);

}

void UComboBoxWidget::SetButtonText(const FString& Target)
{

	this->Button->SetText(FText::FromString(Target));

}


void UComboBoxWidget::SetTextBlockVisibility(const ESlateVisibility& NewVisibility)
{


}


void UComboBoxWidget::SetDownArrowImage(UTexture2D* NewImage)
{

	this->Button->SetIconImage(NewImage);

}

void UComboBoxWidget::SetItemBackGroundImageVisibility(const ESlateVisibility& NewVisibility)
{
	GetMenu()->SetItemBackGroundImageVisibility(NewVisibility);


}

void UComboBoxWidget::SetItemFontColor(const FColor& NewColor)
{

	GetMenu()->SetItemFontColor(NewColor);



}

void UComboBoxWidget::SetItemFontSize(int32 NewSize)
{

	GetMenu()->SetItemFontSize(NewSize);



}

void UComboBoxWidget::SetItemSize(const FVector2D& NewSize)
{
	GetMenu()->SetItemSize(NewSize);



}



void UComboBoxWidget::SetItemFontInformation(const FSlateFontInfo& NewFontInformation)
{
	GetMenu()->SetItemFontInformation(NewFontInformation);
	


}



void UComboBoxWidget::SetItemBackGroundImage(UTexture2D* NewImage)
{
	GetMenu()->SetItemBackGroundImage(NewImage);

}

void UComboBoxWidget::SetMenuBackGroundImage(UTexture2D* NewImage)
{

	GetMenu()->SetBackGroundImage(NewImage);


}


void UComboBoxWidget::SetMenuBackGroundImageColor(const FColor& NewColor)
{

	GetMenu()->SetBackGroundImageColor(NewColor);

}


void UComboBoxWidget::SetButtonBackGroundImage(UTexture2D* NewImage)
{

	this->Button->SetBackGroundImage(NewImage);

}

void UComboBoxWidget::SetDownArrowSize(const FVector2D& NewSize)
{

	this->Button->SetIconSize(NewSize);

}


void UComboBoxWidget::SetDownArrowRelativePosition(const FVector2D& NewPosition)
{

	this->Button->SetIconRelativePosition(NewPosition);

}

void UComboBoxWidget::SetDownArrowImageColor(const FColor& NewColor)
{

	this->Button->SetIconColor(NewColor);

}



void UComboBoxWidget::SetItemBackGroundImageColor(const FColor& NewColor)
{

	GetMenu()->SetItemBackGroundImageColor(NewColor);


}

void UComboBoxWidget::SetButtonBackGroundImageColor(const FColor& NewColor)
{
	this->Button->SetBackGroundImageColor(NewColor);
}



void UComboBoxWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{



}


void UComboBoxWidget::OnSelectionUpdate(FString SelectedItem, ESelectInfo::Type SelectionInfo)
{
	this->OnSelectionChange.ExecuteIfBound(SelectedItem,SelectionInfo);


}


void UComboBoxWidget::OnMenuOpen()
{
	this->OnOpenMenu.ExecuteIfBound();
	


}

