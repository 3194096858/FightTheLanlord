﻿

#include "Widget/TextBlockWidget.h"


#include "Components/Button.h"
#include "Components/Image.h"
#include "Manager/FTL_AssetManager.h"
#include "Components/TextBlock.h"


#include "GameInstance/FTL_GameInstance.h"




void UTextBlockWidget::NativeOnInitialized()
{
	Super::NativeOnInitialized();

	FSlateFontInfo Font;
	Font.FontObject = GetGameInstance()->GetAssetManager()->WidgetAsset.Font;
	this->TextBlock->SetFont(Font);



}

void UTextBlockWidget::NativePreConstruct()
{
	Super::NativePreConstruct();


}


void UTextBlockWidget::NativeConstruct()
{
	Super::NativeConstruct();


}


void UTextBlockWidget::NativeDestruct()
{
	Super::NativeDestruct();

}


void UTextBlockWidget::SetTextRelativePosition(const FVector2D& NewPosition)
{
	this->TextBlock->SetRenderTranslation(NewPosition);
}

void UTextBlockWidget::SetFontSize(int32 NewSize)
{
	FSlateFontInfo Font;
	Font.FontObject = GetGameInstance()->GetAssetManager()->WidgetAsset.Font;
	Font.Size = NewSize;
	this->TextBlock->SetFont(Font);

}

void UTextBlockWidget::SetFontColor(const FColor& NewColor)
{
	this->TextBlock->SetColorAndOpacity(NewColor);

}

void UTextBlockWidget::SetText(const FText& NewText)
{
	this->TextBlock->SetText(NewText);


}

void UTextBlockWidget::SetText(const FString& NewText)
{

    this->TextBlock->SetText(FText::FromString(NewText));

}

void UTextBlockWidget::SetText(int32 Number)
{

	this->TextBlock->SetText(FText::FromString(FString::FromInt(Number)));
}

void UTextBlockWidget::SetBackGroundImageSlateBrush(const FSlateBrush& NewSlateBrush)
{
	this->BackGroundImage->SetBrush(NewSlateBrush);

}

void UTextBlockWidget::SetBackGroundImageColor(const FColor& NewColor)
{
	this->BackGroundImage->SetBrushTintColor(NewColor);

}

void UTextBlockWidget::SetBackGroundImage(UTexture2D* NewImage)
{
	this->BackGroundImage->SetBrushFromTexture(NewImage);

}


void UTextBlockWidget::SetBackGroundImageVisibility(const ESlateVisibility& NewVisibility)
{
	this->BackGroundImage->SetVisibility(NewVisibility);

}

void UTextBlockWidget::SetTextVisibility(const ESlateVisibility& NewVisibility)
{
	this->TextBlock->SetVisibility(NewVisibility);

}


void UTextBlockWidget::SetFontInformation(const FSlateFontInfo& NewFont)
{
	this->TextBlock->SetFont(NewFont);


}


void UTextBlockWidget::GetText(FText& Result)
{
	Result = this->TextBlock->GetText();

}

void UTextBlockWidget::GetText(FString& Result)
{
	Result = this->TextBlock->GetText().ToString();



}

void UTextBlockWidget::GetText(int32& Result)
{
	///*TArray<FString> StringArray;

	//this->TextBlock->GetText().ToString().ParseIntoArray(StringArray, TEXT(""));
	//Result = this->TextBlock->GetText().ToString();*/

}


void UTextBlockWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{



}




