﻿// Fill out your copyright notice in the Description page of Project Settings.



#include "GameState/FTL_GameStateBase.h"

#include "Net/UnrealNetwork.h"
#include "GameFramework//GameUserSettings.h"
#include "Kismet/KismetSystemLibrary.h"
#include "GameInstance/FTL_GameInstance.h"
#include "Manager/DelegateManager.h"
AFTL_GameStateBase::AFTL_GameStateBase()
{
    //// this->bReplicates = true;
    // this->bAlwaysRelevant = true;
    this->GameDefaultData.Widget.AnchorData.Alignment = FVector2D(0.5f);
    this->GameDefaultData.Widget.AnchorData.Offsets = FMargin();
    this->GameDefaultData.Widget.AnchorData.Anchors = FAnchors(0.5f);
    this->GameDefaultData.Widget.StartMenuAnimationPlayRate = 2.0f;
    this->GameDefaultData.Widget.GameMainPageAnimationPlayRate = 2.0f;
    this->GameDefaultData.Widget.GameSettingsPanelAnimationPlayRate = 2.0f;
    this->GameDefaultData.Widget.WarningPanelAnimationPlayRate = 2.0f;
    this->GameDefaultData.Widget.ResourcePanelAnimationPlayRate = 4.0f;
    this->GameDefaultData.Widget.ButtonAnimationPlayRate = 5.0f;
    this->GameDefaultData.Widget.GameSessionPanelAnimationPlayRate = 1.5f;
    this->GameDefaultData.Widget.GameLobbyPanelAnimationPlayRate = 3.0f;

     ////****GameSettings****/////
    this->GameDefaultData.GameSettings.Display.ScreenResolution = FIntPoint(1280, 720);
    this->GameDefaultData.GameSettings.Display.WindowMode = EWindowMode::Windowed;
    ////***StartMenu****/////
    this->GameDefaultData.Widget.StartMenu.Size = FVector2D(800.0f, 900.0f);
    this->GameDefaultData.Widget.StartMenu.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.StartMenu.GameTitleImageColor = FColor::White;
    this->GameDefaultData.Widget.StartMenu.StartGameButton.Size = FVector2D(300.0f, 100.0f);
    this->GameDefaultData.Widget.StartMenu.StartGameButton.RelativePosition = FVector2D(0.0f, 0.0f);
    this->GameDefaultData.Widget.StartMenu.StartGameButton.TextBlock.FontColor = FColor::White;
    this->GameDefaultData.Widget.StartMenu.StartGameButton.TextBlock.FontSize = 32;
    this->GameDefaultData.Widget.StartMenu.StartGameButton.TextBlock.Text = FText::FromString(TEXT("开始游戏"));
    this->GameDefaultData.Widget.StartMenu.StartGameButton.TextBlock.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.StartMenu.StartGameButton.TextBlock.IsShowText = true;
    this->GameDefaultData.Widget.StartMenu.StartGameButton.Icon.IsShowImage = false;
    this->GameDefaultData.Widget.StartMenu.StartGameButton.BackGroundImage.IsShowImage = true;
    this->GameDefaultData.Widget.StartMenu.StartGameButton.BackGroundImage.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.StartMenu.StartGameButton.BackGroundImage.Color = FColor::White;
    this->GameDefaultData.Widget.StartMenu.StartGameButton.BackGroundImage.Size = FVector2D(0.0f);
    ////***GameMainPage****/////
    this->GameDefaultData.Widget.GameMainPage.Size = FVector2D(1900.0f, 1100.0f);
    this->GameDefaultData.Widget.GameMainPage.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameMainPage.SessionButton.Size = FVector2D(130.0f);
    this->GameDefaultData.Widget.GameMainPage.SessionButton.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameMainPage.SessionButton.BackGroundImage.IsShowImage = false;
    this->GameDefaultData.Widget.GameMainPage.SessionButton.TextBlock.IsShowText = false;
    this->GameDefaultData.Widget.GameMainPage.SessionButton.TextBlock.BackGroundImage.IsShowImage = false;
    this->GameDefaultData.Widget.GameMainPage.SessionButton.Icon.IsShowImage = true;
    this->GameDefaultData.Widget.GameMainPage.SessionButton.Icon.Color = FColor::White;
    this->GameDefaultData.Widget.GameMainPage.SessionButton.Icon.Size = FVector2D(130.0f);
    this->GameDefaultData.Widget.GameMainPage.SessionButton.Icon.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameMainPage.SettingsButton.Size = FVector2D(130.0f);
    this->GameDefaultData.Widget.GameMainPage.SettingsButton.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameMainPage.SettingsButton.BackGroundImage.IsShowImage = true;
    this->GameDefaultData.Widget.GameMainPage.SettingsButton.BackGroundImage.Color = FColor::White;
    this->GameDefaultData.Widget.GameMainPage.SettingsButton.BackGroundImage.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameMainPage.SettingsButton.BackGroundImage.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameMainPage.SettingsButton.TextBlock.IsShowText = false;
    this->GameDefaultData.Widget.GameMainPage.SettingsButton.TextBlock.BackGroundImage.IsShowImage = false;
    this->GameDefaultData.Widget.GameMainPage.SettingsButton.Icon.IsShowImage = true;
    this->GameDefaultData.Widget.GameMainPage.SettingsButton.Icon.Color = FColor::White;
    this->GameDefaultData.Widget.GameMainPage.SettingsButton.Icon.Size = FVector2D(80.0f);
    this->GameDefaultData.Widget.GameMainPage.SettingsButton.Icon.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameMainPage.QuitGameButton.Size = FVector2D(130.0f);
    this->GameDefaultData.Widget.GameMainPage.QuitGameButton.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameMainPage.QuitGameButton.BackGroundImage.IsShowImage = true;
    this->GameDefaultData.Widget.GameMainPage.QuitGameButton.BackGroundImage.Color = FColor::White;
    this->GameDefaultData.Widget.GameMainPage.QuitGameButton.BackGroundImage.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameMainPage.QuitGameButton.BackGroundImage.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameMainPage.QuitGameButton.TextBlock.IsShowText = false;
    this->GameDefaultData.Widget.GameMainPage.QuitGameButton.TextBlock.BackGroundImage.IsShowImage = false;
    this->GameDefaultData.Widget.GameMainPage.QuitGameButton.Icon.IsShowImage = true;
    this->GameDefaultData.Widget.GameMainPage.QuitGameButton.Icon.Color = FColor::White;
    this->GameDefaultData.Widget.GameMainPage.QuitGameButton.Icon.Size = FVector2D(100.0f);
    this->GameDefaultData.Widget.GameMainPage.QuitGameButton.Icon.RelativePosition = FVector2D(0.0f);
    ////***ResourcePanel****/////
    this->GameDefaultData.Widget.ResourcePanel.Size = FVector2D(200.0f, 70.0f);
    this->GameDefaultData.Widget.ResourcePanel.RelativePosition = FVector2D(300.0f, -450.0f);
    this->GameDefaultData.Widget.ResourcePanel.BeanTextBlock.FontColor = FColor::White;
    this->GameDefaultData.Widget.ResourcePanel.BeanTextBlock.BackGroundImage.Color = FLinearColor(0.5f, 0.7f, 0.7f, 0.4f).ToFColor(true);
    this->GameDefaultData.Widget.ResourcePanel.BeanTextBlock.FontSize = 32;
    this->GameDefaultData.Widget.ResourcePanel.BeanTextBlock.Text = FText::FromString(TEXT("0"));
    this->GameDefaultData.Widget.ResourcePanel.BeanTextBlock.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.ResourcePanel.BeanTextBlock.RelativePosition = FVector2D(0.0f, 0.0f);
    this->GameDefaultData.Widget.ResourcePanel.BeanIcon.IsShowImage = true;
    this->GameDefaultData.Widget.ResourcePanel.BeanIcon.Size = FVector2D(70.0f);
    this->GameDefaultData.Widget.ResourcePanel.BeanIcon.RelativePosition = FVector2D(-80.0f, 0.0f);
    this->GameDefaultData.Widget.ResourcePanel.BeanIcon.Color = FColor::White;
    ////***WarningPanel****/////
    this->GameDefaultData.Widget.WarningPanel.Size = FVector2D(800.0f, 500.0f);
    this->GameDefaultData.Widget.WarningPanel.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.WarningPanel.TextBlock.BackGroundImage.IsShowImage = false;
    this->GameDefaultData.Widget.WarningPanel.TextBlock.IsShowText = true;
    this->GameDefaultData.Widget.WarningPanel.TextBlock.FontColor = FColor::Black;
    this->GameDefaultData.Widget.WarningPanel.TextBlock.FontSize = 32;
    this->GameDefaultData.Widget.WarningPanel.TextBlock.RelativePosition = FVector2D(-30.0f, 0.0f);
    this->GameDefaultData.Widget.WarningPanel.TextBlock.Size = FVector2D(200.0f, 100.0f);
    this->GameDefaultData.Widget.WarningPanel.ConfirmButton.Size = FVector2D(100.0f);
    this->GameDefaultData.Widget.WarningPanel.ConfirmButton.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.WarningPanel.ConfirmButton.Icon.Color = FColor::White;
    this->GameDefaultData.Widget.WarningPanel.ConfirmButton.Icon.IsShowImage = true;
    this->GameDefaultData.Widget.WarningPanel.ConfirmButton.Icon.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.WarningPanel.ConfirmButton.Icon.Size = this->GameDefaultData.Widget.WarningPanel.ConfirmButton.Size;
    this->GameDefaultData.Widget.WarningPanel.ConfirmButton.TextBlock.IsShowText = false;
    this->GameDefaultData.Widget.WarningPanel.ConfirmButton.BackGroundImage.IsShowImage = false;
    this->GameDefaultData.Widget.WarningPanel.CancelButton.Size = FVector2D(100.0f);
    this->GameDefaultData.Widget.WarningPanel.CancelButton.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.WarningPanel.CancelButton.Icon.Color = FColor::White;
    this->GameDefaultData.Widget.WarningPanel.CancelButton.Icon.IsShowImage = true;
    this->GameDefaultData.Widget.WarningPanel.CancelButton.Icon.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.WarningPanel.CancelButton.Icon.Size = this->GameDefaultData.Widget.WarningPanel.CancelButton.Size;
    this->GameDefaultData.Widget.WarningPanel.CancelButton.TextBlock.IsShowText = false;
    this->GameDefaultData.Widget.WarningPanel.CancelButton.BackGroundImage.IsShowImage = false;
    ////***GameSettingsPanel****/////
    this->GameDefaultData.Widget.GameSettingsPanel.Size = FVector2D(1500.0f, 1000.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.ReturnButton.Size = FVector2D(130.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.ReturnButton.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.ReturnButton.Icon.IsShowImage = false;
    this->GameDefaultData.Widget.GameSettingsPanel.ReturnButton.TextBlock.IsShowText = false;
    this->GameDefaultData.Widget.GameSettingsPanel.ReturnButton.BackGroundImage.IsShowImage = true;
    this->GameDefaultData.Widget.GameSettingsPanel.ReturnButton.BackGroundImage.Color = FColor::White;
    this->GameDefaultData.Widget.GameSettingsPanel.ReturnButton.BackGroundImage.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.ReturnButton.BackGroundImage.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.ResetButton.Size = FVector2D(130.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.ResetButton.RelativePosition = FVector2D(0.0f,10.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.ResetButton.Icon.IsShowImage = true;
    this->GameDefaultData.Widget.GameSettingsPanel.ResetButton.Icon.Color = FColor::White;
    this->GameDefaultData.Widget.GameSettingsPanel.ResetButton.Icon.Size = FVector2D(130.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.ResetButton.Icon.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.ResetButton.TextBlock.IsShowText = false;
    this->GameDefaultData.Widget.GameSettingsPanel.ResetButton.BackGroundImage.IsShowImage = true;
    this->GameDefaultData.Widget.GameSettingsPanel.ResetButton.BackGroundImage.Color = FColor::White;
    this->GameDefaultData.Widget.GameSettingsPanel.ResetButton.BackGroundImage.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.ResetButton.BackGroundImage.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.AudioButton.Size = FVector2D(150.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.AudioButton.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.AudioButton.Icon.IsShowImage = false;
    this->GameDefaultData.Widget.GameSettingsPanel.AudioButton.TextBlock.IsShowText = false;
    this->GameDefaultData.Widget.GameSettingsPanel.AudioButton.BackGroundImage.IsShowImage = true;
    this->GameDefaultData.Widget.GameSettingsPanel.AudioButton.BackGroundImage.Color = FColor::White;
    this->GameDefaultData.Widget.GameSettingsPanel.AudioButton.BackGroundImage.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.AudioButton.BackGroundImage.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.DisplayButton.Size = FVector2D(150.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.DisplayButton.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.DisplayButton.Icon.IsShowImage = false;
    this->GameDefaultData.Widget.GameSettingsPanel.DisplayButton.TextBlock.IsShowText = false;
    this->GameDefaultData.Widget.GameSettingsPanel.DisplayButton.BackGroundImage.IsShowImage = true;
    this->GameDefaultData.Widget.GameSettingsPanel.DisplayButton.BackGroundImage.Color = FColor::White;
    this->GameDefaultData.Widget.GameSettingsPanel.DisplayButton.BackGroundImage.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.DisplayButton.BackGroundImage.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.OperationButton.Size = FVector2D(150.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.OperationButton.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.OperationButton.Icon.IsShowImage = false;
    this->GameDefaultData.Widget.GameSettingsPanel.OperationButton.TextBlock.IsShowText = false;
    this->GameDefaultData.Widget.GameSettingsPanel.OperationButton.BackGroundImage.IsShowImage = true;
    this->GameDefaultData.Widget.GameSettingsPanel.OperationButton.BackGroundImage.Color = FColor::White;
    this->GameDefaultData.Widget.GameSettingsPanel.OperationButton.BackGroundImage.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.OperationButton.BackGroundImage.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.OptionType = EGameSettingsOptionType::ComboBox;
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.Size = FVector2D(400.0f, 100.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.TextBlock.BackGroundImage.IsShowImage = false;
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.TextBlock.FontColor = FColor::White;
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.TextBlock.FontSize = 40;
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.TextBlock.IsShowText = true;
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.TextBlock.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.TextBlock.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.TextBlock.Text = FText::FromString(TEXT("屏幕分辨率"));
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.BackGroundImage.Color = FLinearColor(0.0f, 0.5f, 0.4f, 1.0f).ToFColor(true);
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.BackGroundImage.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.BackGroundImage.IsShowImage = true;
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.BackGroundImage.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.ComboBox.ItemPadding = FMargin(5.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.ComboBox.MenuAnimationPlayRate = 3.0f;
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.ComboBox.Menu.Color = FLinearColor(0.7f, 0.7f, 0.7f, 1.0f).ToFColor(true);
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.ComboBox.Menu.IsShowImage = true;
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.ComboBox.Menu.RelativePosition = FVector2D(500.0f, 50.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.ComboBox.Menu.Size = FVector2D(230.0f, 250.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.ComboBox.Size = FVector2D(200.0f, 70.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.ComboBox.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.ComboBox.Button.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.ComboBox.Button.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.ComboBox.Button.TextBlock.IsShowText = true;
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.ComboBox.Button.TextBlock.FontColor = FColor::Black;
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.ComboBox.Button.TextBlock.FontSize = 20;
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.ComboBox.Button.TextBlock.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.ComboBox.Button.TextBlock.RelativePosition = FVector2D(-30.0f, 0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.ComboBox.Button.Icon.IsShowImage = true;
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.ComboBox.Button.Icon.Color = FColor::White;
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.ComboBox.Button.Icon.RelativePosition = FVector2D(70.0f, 0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.ComboBox.Button.Icon.Size = FVector2D(50.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.ComboBox.Button.BackGroundImage.IsShowImage = true;
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.ComboBox.Button.BackGroundImage.Color = FLinearColor(0.3f, 0.3f, 0.4f, 1.0f).ToFColor(true);
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.ComboBox.Button.BackGroundImage.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.ComboBox.Button.BackGroundImage.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.ComboBox.ItemButton.Size = FVector2D(200.0f, 60.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.ComboBox.ItemButton.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.ComboBox.ItemButton.Icon.IsShowImage = false;
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.ComboBox.ItemButton.BackGroundImage.IsShowImage = true;
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.ComboBox.ItemButton.BackGroundImage.Color = FLinearColor(0.2f, 0.2f, 0.2f, 1.0f).ToFColor(true);
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.ComboBox.ItemButton.BackGroundImage.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.ComboBox.ItemButton.BackGroundImage.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.ComboBox.ItemButton.TextBlock.IsShowText = true;
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.ComboBox.ItemButton.TextBlock.FontColor = FColor::Black;
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.ComboBox.ItemButton.TextBlock.FontSize = 22;
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.ComboBox.ItemButton.TextBlock.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Display.ScreenResolution.ComboBox.ItemButton.TextBlock.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.Size = FVector2D(1500.0f, 1000.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.BGM.OptionType = EGameSettingsOptionType::Slider;
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.BGM.Size = FVector2D(400.0f, 100.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.BGM.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.BGM.TextBlock.BackGroundImage.IsShowImage = false;
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.BGM.TextBlock.FontColor = FColor::White;
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.BGM.TextBlock.FontSize = 40;
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.BGM.TextBlock.IsShowText = true;
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.BGM.TextBlock.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.BGM.TextBlock.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.BGM.TextBlock.Text = FText::FromString(TEXT("音乐"));
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.BGM.BackGroundImage.Color = FLinearColor(0.0f, 0.5f, 0.4f, 1.0f).ToFColor(true);
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.BGM.BackGroundImage.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.BGM.BackGroundImage.IsShowImage = true;
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.BGM.BackGroundImage.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.BGM.Slider.Size = FVector2D(300.0f, 70.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.BGM.Slider.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.BGM.Slider.TextBlock.IsShowText = true;
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.BGM.Slider.TextBlock.FontSize = 50.0f;
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.BGM.Slider.TextBlock.FontColor = FColor::White;
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.BGM.Slider.TextBlock.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.BGM.Slider.TextBlock.RelativePosition = FVector2D(-200.0f,0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.BGM.Slider.StepSize = 0.1f;
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.BGM.Slider.BarThickness = 20.0f;
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.BGM.Slider.BarImage.IsShowImage = true;
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.BGM.Slider.BarImage.Color = FLinearColor(0.4f,0.4f,0.2f,1.0f).ToFColor(true);
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.BGM.Slider.BarImage.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.BGM.Slider.BarImage.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.BGM.Slider.HandleImage.IsShowImage = true;
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.BGM.Slider.HandleImage.Color = FColor::White;
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.BGM.Slider.HandleImage.Size = FVector2D(50.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.BGM.Slider.HandleImage.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.BGM.Slider.BackGroundImage.IsShowImage = false;
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.SFX.OptionType = EGameSettingsOptionType::Slider;
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.SFX.Size = FVector2D(400.0f, 100.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.SFX.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.SFX.TextBlock.BackGroundImage.IsShowImage = false;
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.SFX.TextBlock.FontColor = FColor::White;
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.SFX.TextBlock.FontSize = 40;
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.SFX.TextBlock.IsShowText = true;
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.SFX.TextBlock.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.SFX.TextBlock.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.SFX.TextBlock.Text = FText::FromString(TEXT("音效"));
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.SFX.BackGroundImage.Color = FLinearColor(0.0f, 0.5f, 0.4f, 1.0f).ToFColor(true);
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.SFX.BackGroundImage.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.SFX.BackGroundImage.IsShowImage = true;
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.SFX.BackGroundImage.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.SFX.Slider.Size = FVector2D(300.0f, 70.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.SFX.Slider.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.SFX.Slider.TextBlock.IsShowText = true;
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.SFX.Slider.TextBlock.FontSize = 50.0f;
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.SFX.Slider.TextBlock.FontColor = FColor::White;
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.SFX.Slider.TextBlock.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.SFX.Slider.TextBlock.RelativePosition = FVector2D(-200.0f, 0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.SFX.Slider.StepSize = 0.1f;
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.SFX.Slider.BarThickness = 20.0f;
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.SFX.Slider.BarImage.IsShowImage = true;
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.SFX.Slider.BarImage.Color = FLinearColor(0.4f, 0.4f, 0.2f, 1.0f).ToFColor(true);
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.SFX.Slider.BarImage.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.SFX.Slider.BarImage.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.SFX.Slider.HandleImage.IsShowImage = true;
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.SFX.Slider.HandleImage.Color = FColor::White;
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.SFX.Slider.HandleImage.Size = FVector2D(50.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.SFX.Slider.HandleImage.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSettingsPanel.Audio.SFX.Slider.BackGroundImage.IsShowImage = false;


    ////***GameSessionPanel****/////
    this->GameDefaultData.Widget.GameSessionPanel.Size = FVector2D(1000.0f, 800.0f);
    this->GameDefaultData.Widget.GameSessionPanel.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSessionPanel.SessionPadding = FMargin(20.0f);
    this->GameDefaultData.Widget.GameSessionPanel.BackGroundImage.IsShowImage = true;
    this->GameDefaultData.Widget.GameSessionPanel.BackGroundImage.Color = FColor::White;
    this->GameDefaultData.Widget.GameSessionPanel.BackGroundImage.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSessionPanel.BackGroundImage.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSessionPanel.EditableTextBox.HintText = FText::FromString(TEXT("请输入名称..."));
    this->GameDefaultData.Widget.GameSessionPanel.EditableTextBox.Size = FVector2D(500.0f, 100.0f);
    this->GameDefaultData.Widget.GameSessionPanel.EditableTextBox.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSessionPanel.EditableTextBox.BackGroundImage.IsShowImage = true;
    this->GameDefaultData.Widget.GameSessionPanel.EditableTextBox.BackGroundImage.Color = FLinearColor(0.3f, 0.4f, 0.4f).ToFColor(true);
    this->GameDefaultData.Widget.GameSessionPanel.EditableTextBox.BackGroundImage.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSessionPanel.EditableTextBox.BackGroundImage.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSessionPanel.CreateButton.Size = FVector2D(200.0f, 100.0f);
    this->GameDefaultData.Widget.GameSessionPanel.CreateButton.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSessionPanel.CreateButton.BackGroundImage.IsShowImage = true;
    this->GameDefaultData.Widget.GameSessionPanel.CreateButton.BackGroundImage.Color = FColor::White;
    this->GameDefaultData.Widget.GameSessionPanel.CreateButton.BackGroundImage.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSessionPanel.CreateButton.BackGroundImage.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSessionPanel.CreateButton.TextBlock.BackGroundImage.IsShowImage = false;
    this->GameDefaultData.Widget.GameSessionPanel.CreateButton.TextBlock.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSessionPanel.CreateButton.TextBlock.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSessionPanel.CreateButton.TextBlock.FontColor = FColor::White;
    this->GameDefaultData.Widget.GameSessionPanel.CreateButton.TextBlock.FontSize = 32;
    this->GameDefaultData.Widget.GameSessionPanel.CreateButton.TextBlock.Text = FText::FromString(TEXT("创建"));
    this->GameDefaultData.Widget.GameSessionPanel.CreateButton.Icon.IsShowImage = false;
    this->GameDefaultData.Widget.GameSessionPanel.SearchButton.Size = FVector2D(200.0f, 100.0f);
    this->GameDefaultData.Widget.GameSessionPanel.SearchButton.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSessionPanel.SearchButton.BackGroundImage.IsShowImage = true;
    this->GameDefaultData.Widget.GameSessionPanel.SearchButton.BackGroundImage.Color = FColor::White;
    this->GameDefaultData.Widget.GameSessionPanel.SearchButton.BackGroundImage.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSessionPanel.SearchButton.BackGroundImage.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSessionPanel.SearchButton.TextBlock.BackGroundImage.IsShowImage = false;
    this->GameDefaultData.Widget.GameSessionPanel.SearchButton.TextBlock.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSessionPanel.SearchButton.TextBlock.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameSessionPanel.SearchButton.TextBlock.FontColor = FColor::White;
    this->GameDefaultData.Widget.GameSessionPanel.SearchButton.TextBlock.FontSize = 32;
    this->GameDefaultData.Widget.GameSessionPanel.SearchButton.TextBlock.Text = FText::FromString(TEXT("搜索"));
    this->GameDefaultData.Widget.GameSessionPanel.SearchButton.Icon.IsShowImage = false;
    ////***SessionWidget****/////
    this->GameDefaultData.Widget.SessionWidget.Size = FVector2D(800.0f, 150.0f);
    this->GameDefaultData.Widget.SessionWidget.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.SessionWidget.BackGroundImage.IsShowImage = true;
    this->GameDefaultData.Widget.SessionWidget.BackGroundImage.Color = FLinearColor(0.1f, 0.3f, 0.3f, 1.0f).ToFColor(true);
    this->GameDefaultData.Widget.SessionWidget.BackGroundImage.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.SessionWidget.BackGroundImage.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.SessionWidget.NameTextBlock.RelativePosition = FVector2D(0.0f, -20.0f);
    this->GameDefaultData.Widget.SessionWidget.NameTextBlock.IsShowText = true;
    this->GameDefaultData.Widget.SessionWidget.NameTextBlock.Size = FVector2D(0.0f, -20.0f);
    this->GameDefaultData.Widget.SessionWidget.NameTextBlock.FontSize = 32;
    this->GameDefaultData.Widget.SessionWidget.NameTextBlock.FontColor = FColor::White;
    this->GameDefaultData.Widget.SessionWidget.Icon.IsShowImage = true;
    this->GameDefaultData.Widget.SessionWidget.Icon.Size = FVector2D(100.0f, 100.0f);
    this->GameDefaultData.Widget.SessionWidget.Icon.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.SessionWidget.Icon.Color = FColor::White;
    this->GameDefaultData.Widget.SessionWidget.DeleteButton.Size = FVector2D(180.0f, 80.0f);
    this->GameDefaultData.Widget.SessionWidget.DeleteButton.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.SessionWidget.DeleteButton.BackGroundImage.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.SessionWidget.DeleteButton.BackGroundImage.Color = FColor::White;
    this->GameDefaultData.Widget.SessionWidget.DeleteButton.BackGroundImage.IsShowImage = true;
    this->GameDefaultData.Widget.SessionWidget.DeleteButton.BackGroundImage.RelativePosition = FVector2D();
    this->GameDefaultData.Widget.SessionWidget.DeleteButton.Icon.IsShowImage = false;
    this->GameDefaultData.Widget.SessionWidget.DeleteButton.TextBlock.BackGroundImage.IsShowImage = false;
    this->GameDefaultData.Widget.SessionWidget.DeleteButton.TextBlock.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.SessionWidget.DeleteButton.TextBlock.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.SessionWidget.DeleteButton.TextBlock.FontColor = FColor::White;
    this->GameDefaultData.Widget.SessionWidget.DeleteButton.TextBlock.FontSize = 32;
    this->GameDefaultData.Widget.SessionWidget.DeleteButton.TextBlock.Text = FText::FromString(TEXT("删除"));
    this->GameDefaultData.Widget.SessionWidget.JoinButton.Size = FVector2D(180.0f, 80.0f);
    this->GameDefaultData.Widget.SessionWidget.JoinButton.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.SessionWidget.JoinButton.BackGroundImage.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.SessionWidget.JoinButton.BackGroundImage.Color = FColor::White;
    this->GameDefaultData.Widget.SessionWidget.JoinButton.BackGroundImage.IsShowImage = true;
    this->GameDefaultData.Widget.SessionWidget.JoinButton.BackGroundImage.RelativePosition = FVector2D();
    this->GameDefaultData.Widget.SessionWidget.JoinButton.Icon.IsShowImage = false;
    this->GameDefaultData.Widget.SessionWidget.JoinButton.TextBlock.BackGroundImage.IsShowImage = false;
    this->GameDefaultData.Widget.SessionWidget.JoinButton.TextBlock.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.SessionWidget.JoinButton.TextBlock.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.SessionWidget.JoinButton.TextBlock.FontColor = FColor::White;
    this->GameDefaultData.Widget.SessionWidget.JoinButton.TextBlock.FontSize = 32;
    this->GameDefaultData.Widget.SessionWidget.JoinButton.TextBlock.Text = FText::FromString(TEXT("进入"));
    ////***GameLobbyPanel****/////
    this->GameDefaultData.Widget.GameLobbyPanel.Size = FVector2D(2000.0f, 800.0f);
    this->GameDefaultData.Widget.GameLobbyPanel.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameLobbyPanel.TextBlock.BackGroundImage.IsShowImage = false;
    this->GameDefaultData.Widget.GameLobbyPanel.TextBlock.IsShowText = true;
    this->GameDefaultData.Widget.GameLobbyPanel.TextBlock.FontColor = FColor::White;
    this->GameDefaultData.Widget.GameLobbyPanel.TextBlock.FontSize = 50;
    this->GameDefaultData.Widget.GameLobbyPanel.TextBlock.RelativePosition = FVector2D(-500.0f, 0.0f);
    this->GameDefaultData.Widget.GameLobbyPanel.TextBlock.Size = FVector2D(0.0f, 0.0f);
    this->GameDefaultData.Widget.GameLobbyPanel.QuitButton.Size = FVector2D(250.0f, 100.0f);
    this->GameDefaultData.Widget.GameLobbyPanel.QuitButton.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameLobbyPanel.QuitButton.BackGroundImage.IsShowImage = true;
    this->GameDefaultData.Widget.GameLobbyPanel.QuitButton.BackGroundImage.Color = FColor::White;
    this->GameDefaultData.Widget.GameLobbyPanel.QuitButton.BackGroundImage.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameLobbyPanel.QuitButton.BackGroundImage.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameLobbyPanel.QuitButton.TextBlock.BackGroundImage.IsShowImage = false;
    this->GameDefaultData.Widget.GameLobbyPanel.QuitButton.TextBlock.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameLobbyPanel.QuitButton.TextBlock.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameLobbyPanel.QuitButton.TextBlock.FontColor = FColor::White;
    this->GameDefaultData.Widget.GameLobbyPanel.QuitButton.TextBlock.FontSize = 32;
    this->GameDefaultData.Widget.GameLobbyPanel.QuitButton.TextBlock.Text = FText::FromString(TEXT("退出"));
    this->GameDefaultData.Widget.GameLobbyPanel.QuitButton.Icon.IsShowImage = false;
    this->GameDefaultData.Widget.GameLobbyPanel.StartFightingButton.Size = FVector2D(250.0f, 100.0f);
    this->GameDefaultData.Widget.GameLobbyPanel.StartFightingButton.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameLobbyPanel.StartFightingButton.BackGroundImage.IsShowImage = true;
    this->GameDefaultData.Widget.GameLobbyPanel.StartFightingButton.BackGroundImage.Color = FColor::White;
    this->GameDefaultData.Widget.GameLobbyPanel.StartFightingButton.BackGroundImage.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameLobbyPanel.StartFightingButton.BackGroundImage.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameLobbyPanel.StartFightingButton.TextBlock.BackGroundImage.IsShowImage = false;
    this->GameDefaultData.Widget.GameLobbyPanel.StartFightingButton.TextBlock.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameLobbyPanel.StartFightingButton.TextBlock.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.GameLobbyPanel.StartFightingButton.TextBlock.FontColor = FColor::White;
    this->GameDefaultData.Widget.GameLobbyPanel.StartFightingButton.TextBlock.FontSize = 32;
    this->GameDefaultData.Widget.GameLobbyPanel.StartFightingButton.TextBlock.Text = FText::FromString(TEXT("开始对战"));
    this->GameDefaultData.Widget.GameLobbyPanel.StartFightingButton.Icon.IsShowImage = false;

    ////***PlayerPanel****/////
    this->GameDefaultData.Widget.PlayerPanel.Size = FVector2D(1700.0f, 700.0f);
    this->GameDefaultData.Widget.PlayerPanel.RelativePosition = FVector2D(50.0f, 150.0f);
    this->GameDefaultData.Widget.PlayerPanel.LocalPlayer.Size = FVector2D(250.0f);
    this->GameDefaultData.Widget.PlayerPanel.LocalPlayer.RelativePosition = FVector2D(100.0f,0.0f);
    this->GameDefaultData.Widget.PlayerPanel.LocalPlayer.NameTextBlock.FontColor = FColor::White;
    this->GameDefaultData.Widget.PlayerPanel.LocalPlayer.NameTextBlock.BackGroundImage.Color = FColor::White;
    this->GameDefaultData.Widget.PlayerPanel.LocalPlayer.NameTextBlock.BackGroundImage.IsShowImage = true;
    this->GameDefaultData.Widget.PlayerPanel.LocalPlayer.NameTextBlock.Size = FVector2D(153.0f);
    this->GameDefaultData.Widget.PlayerPanel.LocalPlayer.NameTextBlock.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.PlayerPanel.LocalPlayer.NameTextBlock.TextRelativePosition = FVector2D(0.0f,120.0f);
    this->GameDefaultData.Widget.PlayerPanel.LocalPlayer.CardNumberTextBlock.IsShowText = false;
    this->GameDefaultData.Widget.PlayerPanel.LocalPlayer.CardNumberTextBlock.BackGroundImage.IsShowImage = false;
    this->GameDefaultData.Widget.PlayerPanel.LeftPlayer.Size = FVector2D(250.0f);
    this->GameDefaultData.Widget.PlayerPanel.LeftPlayer.RelativePosition = FVector2D(0.0f, 0.0f);
    this->GameDefaultData.Widget.PlayerPanel.LeftPlayer.NameTextBlock.FontColor = FColor::White;
    this->GameDefaultData.Widget.PlayerPanel.LeftPlayer.NameTextBlock.BackGroundImage.Color = FColor::White;
    this->GameDefaultData.Widget.PlayerPanel.LeftPlayer.NameTextBlock.BackGroundImage.IsShowImage = true;
    this->GameDefaultData.Widget.PlayerPanel.LeftPlayer.NameTextBlock.TextRelativePosition = FVector2D(0.0f,120.0f);
    this->GameDefaultData.Widget.PlayerPanel.LeftPlayer.NameTextBlock.Size = FVector2D(153.0f);
    this->GameDefaultData.Widget.PlayerPanel.LeftPlayer.NameTextBlock.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.PlayerPanel.LeftPlayer.CardNumberTextBlock.IsShowText = true;
    this->GameDefaultData.Widget.PlayerPanel.LeftPlayer.CardNumberTextBlock.FontColor = FColor::White;
    this->GameDefaultData.Widget.PlayerPanel.LeftPlayer.CardNumberTextBlock.TextRelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.PlayerPanel.LeftPlayer.CardNumberTextBlock.BackGroundImage.IsShowImage = true;
    this->GameDefaultData.Widget.PlayerPanel.LeftPlayer.CardNumberTextBlock.FontSize = 30;
    this->GameDefaultData.Widget.PlayerPanel.LeftPlayer.CardNumberTextBlock.Text = FText::FromString(TEXT("00"));
    this->GameDefaultData.Widget.PlayerPanel.LeftPlayer.CardNumberTextBlock.Size = FVector2D(50.0f, 66.0f);
    this->GameDefaultData.Widget.PlayerPanel.LeftPlayer.CardNumberTextBlock.RelativePosition = FVector2D(0.0f, 0.0f);
    this->GameDefaultData.Widget.PlayerPanel.RightPlayer.Size = FVector2D(250.0f);
    this->GameDefaultData.Widget.PlayerPanel.RightPlayer.RelativePosition = FVector2D(0.0f, 0.0f);
    this->GameDefaultData.Widget.PlayerPanel.RightPlayer.NameTextBlock.FontColor = FColor::White;
    this->GameDefaultData.Widget.PlayerPanel.RightPlayer.NameTextBlock.BackGroundImage.Color = FColor::White;
    this->GameDefaultData.Widget.PlayerPanel.RightPlayer.NameTextBlock.BackGroundImage.IsShowImage = true;
    this->GameDefaultData.Widget.PlayerPanel.RightPlayer.NameTextBlock.TextRelativePosition = FVector2D(0.0f,120.0f);
    this->GameDefaultData.Widget.PlayerPanel.RightPlayer.NameTextBlock.Size = FVector2D(153.0f);
    this->GameDefaultData.Widget.PlayerPanel.RightPlayer.NameTextBlock.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.PlayerPanel.RightPlayer.CardNumberTextBlock.IsShowText = true;
    this->GameDefaultData.Widget.PlayerPanel.RightPlayer.CardNumberTextBlock.FontColor = FColor::White;
    this->GameDefaultData.Widget.PlayerPanel.RightPlayer.CardNumberTextBlock.TextRelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.PlayerPanel.RightPlayer.CardNumberTextBlock.BackGroundImage.IsShowImage = true;
    this->GameDefaultData.Widget.PlayerPanel.RightPlayer.CardNumberTextBlock.FontSize = 30;
    this->GameDefaultData.Widget.PlayerPanel.RightPlayer.CardNumberTextBlock.Text = FText::FromString(TEXT("00"));
    this->GameDefaultData.Widget.PlayerPanel.RightPlayer.CardNumberTextBlock.Size = FVector2D(50.0f, 66.0f);
    this->GameDefaultData.Widget.PlayerPanel.RightPlayer.CardNumberTextBlock.RelativePosition = FVector2D(-300.0f, 0.0f);

    ////***OperationPanel****/////
    this->GameDefaultData.Widget.OperationPanel.Size = FVector2D(1500.0f, 400.0f);
    this->GameDefaultData.Widget.OperationPanel.RelativePosition = FVector2D(-60.0f,300.0f);
    this->GameDefaultData.Widget.OperationPanel.PlayCardButton.Size = FVector2D(200.0f, 100.0f);
    this->GameDefaultData.Widget.OperationPanel.PlayCardButton.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.OperationPanel.PlayCardButton.BackGroundImage.IsShowImage = true;
    this->GameDefaultData.Widget.OperationPanel.PlayCardButton.BackGroundImage.Color = FColor::White;
    this->GameDefaultData.Widget.OperationPanel.PlayCardButton.BackGroundImage.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.OperationPanel.PlayCardButton.BackGroundImage.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.OperationPanel.PlayCardButton.TextBlock.BackGroundImage.IsShowImage = false;
    this->GameDefaultData.Widget.OperationPanel.PlayCardButton.TextBlock.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.OperationPanel.PlayCardButton.TextBlock.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.OperationPanel.PlayCardButton.TextBlock.FontColor = FColor::White;
    this->GameDefaultData.Widget.OperationPanel.PlayCardButton.TextBlock.FontSize = 32;
    this->GameDefaultData.Widget.OperationPanel.PlayCardButton.TextBlock.Text = FText::FromString(TEXT("出牌"));
    this->GameDefaultData.Widget.OperationPanel.PlayCardButton.Icon.IsShowImage = false;
    this->GameDefaultData.Widget.OperationPanel.PassButton.Size = FVector2D(200.0f, 100.0f);
    this->GameDefaultData.Widget.OperationPanel.PassButton.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.OperationPanel.PassButton.BackGroundImage.IsShowImage = true;
    this->GameDefaultData.Widget.OperationPanel.PassButton.BackGroundImage.Color = FColor::White;
    this->GameDefaultData.Widget.OperationPanel.PassButton.BackGroundImage.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.OperationPanel.PassButton.BackGroundImage.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.OperationPanel.PassButton.TextBlock.BackGroundImage.IsShowImage = false;
    this->GameDefaultData.Widget.OperationPanel.PassButton.TextBlock.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.OperationPanel.PassButton.TextBlock.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.OperationPanel.PassButton.TextBlock.FontColor = FColor::White;
    this->GameDefaultData.Widget.OperationPanel.PassButton.TextBlock.FontSize = 32;
    this->GameDefaultData.Widget.OperationPanel.PassButton.TextBlock.Text = FText::FromString(TEXT("跳过"));
    this->GameDefaultData.Widget.OperationPanel.PassButton.Icon.IsShowImage = false;
    this->GameDefaultData.Widget.OperationPanel.MessageButton.Size = FVector2D(130.0f);
    this->GameDefaultData.Widget.OperationPanel.MessageButton.RelativePosition = FVector2D(0.0f,-20.0f);
    this->GameDefaultData.Widget.OperationPanel.MessageButton.Icon.IsShowImage = false;
    this->GameDefaultData.Widget.OperationPanel.MessageButton.TextBlock.IsShowText = false;
    this->GameDefaultData.Widget.OperationPanel.MessageButton.BackGroundImage.IsShowImage = true;
    this->GameDefaultData.Widget.OperationPanel.MessageButton.BackGroundImage.Color = FColor::White;
    this->GameDefaultData.Widget.OperationPanel.MessageButton.BackGroundImage.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.OperationPanel.MessageButton.BackGroundImage.Size = FVector2D(0.0f);



    this->GameDefaultData.Widget.OperationPanel.CountdownTimer.Size = FVector2D(150.0f);
    this->GameDefaultData.Widget.OperationPanel.CountdownTimer.RelativePosition = FVector2D(0.0f,-30.0f);
    this->GameDefaultData.Widget.OperationPanel.CountdownTimer.TextBlock.BackGroundImage.IsShowImage = true;
    this->GameDefaultData.Widget.OperationPanel.CountdownTimer.TextBlock.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.OperationPanel.CountdownTimer.TextBlock.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.OperationPanel.CountdownTimer.TextBlock.TextRelativePosition = FVector2D(0.0f,20.0f);
    this->GameDefaultData.Widget.OperationPanel.CountdownTimer.TextBlock.FontColor = FColor::White;
    this->GameDefaultData.Widget.OperationPanel.CountdownTimer.TextBlock.FontSize = 40;
    this->GameDefaultData.Widget.OperationPanel.CountdownTimer.TextBlock.Text = FText::FromString(TEXT("30"));
    this->GameDefaultData.Widget.OperationPanel.CardHand.Size = FVector2D(1000.0f,500.0f);
    this->GameDefaultData.Widget.OperationPanel.CardHand.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.OperationPanel.CardHand.CardSize = FVector2D(160.0f, 208.0f);

    ////***CardTableWidget****/////
    this->GameDefaultData.Widget.CardTableWidget.Size = FVector2D(500.0f, 250.0f);
    this->GameDefaultData.Widget.CardTableWidget.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.CardTableWidget.CardSize = FVector2D(80.0f, 104.0f);


    ////***HoleCardWidget****/////
    this->GameDefaultData.Widget.HoleCardPanel.Size = FVector2D(500.0f, 200.0f);
    this->GameDefaultData.Widget.HoleCardPanel.RelativePosition = FVector2D(0.0f,-400.0f);
    this->GameDefaultData.Widget.HoleCardPanel.BackGroundImage.IsShowImage = true;
    this->GameDefaultData.Widget.HoleCardPanel.BackGroundImage.Color = FLinearColor(0.0f,0.0f,0.0f,0.6f).ToFColor(true);
    this->GameDefaultData.Widget.HoleCardPanel.CardSize = FVector2D(120.0f, 156.0f);


    ////***ResultPanel****/////
    this->GameDefaultData.Widget.ResultPanel.Size = FVector2D(800.0f, 600.0f);
    this->GameDefaultData.Widget.ResultPanel.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.ResultPanel.QuitButton.Size = FVector2D(250.0f, 100.0f);
    this->GameDefaultData.Widget.ResultPanel.QuitButton.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.ResultPanel.QuitButton.BackGroundImage.IsShowImage = true;
    this->GameDefaultData.Widget.ResultPanel.QuitButton.BackGroundImage.Color = FColor::White;
    this->GameDefaultData.Widget.ResultPanel.QuitButton.BackGroundImage.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.ResultPanel.QuitButton.BackGroundImage.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.ResultPanel.QuitButton.TextBlock.BackGroundImage.IsShowImage = false;
    this->GameDefaultData.Widget.ResultPanel.QuitButton.TextBlock.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.ResultPanel.QuitButton.TextBlock.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.ResultPanel.QuitButton.TextBlock.FontColor = FColor::White;
    this->GameDefaultData.Widget.ResultPanel.QuitButton.TextBlock.FontSize = 32;
    this->GameDefaultData.Widget.ResultPanel.QuitButton.TextBlock.Text = FText::FromString(TEXT("退出"));
    this->GameDefaultData.Widget.ResultPanel.QuitButton.Icon.IsShowImage = false;
    this->GameDefaultData.Widget.ResultPanel.GameOverTextBlock.Size = FVector2D(2664.0f, 115.0f);
    this->GameDefaultData.Widget.ResultPanel.GameOverTextBlock.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.ResultPanel.GameOverTextBlock.BackGroundImage.IsShowImage = true;
    this->GameDefaultData.Widget.ResultPanel.GameOverTextBlock.BackGroundImage.Color = FColor::White;
    this->GameDefaultData.Widget.ResultPanel.GameOverTextBlock.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.ResultPanel.GameOverTextBlock.TextRelativePosition = FVector2D(0.0f, -10.0f);
    this->GameDefaultData.Widget.ResultPanel.GameOverTextBlock.FontColor = FColor::White;
    this->GameDefaultData.Widget.ResultPanel.GameOverTextBlock.FontSize = 50;
    this->GameDefaultData.Widget.ResultPanel.GameOverTextBlock.Text = FText::FromString(TEXT("游戏结束"));
    this->GameDefaultData.Widget.ResultPanel.GameResultTextBlock.Size = FVector2D(200.0f);
    this->GameDefaultData.Widget.ResultPanel.GameResultTextBlock.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.ResultPanel.GameResultTextBlock.BackGroundImage.IsShowImage = false;
    this->GameDefaultData.Widget.ResultPanel.GameResultTextBlock.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.ResultPanel.GameResultTextBlock.TextRelativePosition = FVector2D(0.0f, -10.0f);
    this->GameDefaultData.Widget.ResultPanel.GameResultTextBlock.FontColor = FColor::Black;
    this->GameDefaultData.Widget.ResultPanel.GameResultTextBlock.FontSize = 40;


    //////***MessagePanel****/////
    this->GameDefaultData.Widget.MessagePanel.Size = FVector2D(800.0f, 600.0f);
    this->GameDefaultData.Widget.MessagePanel.RelativePosition = FVector2D(-200.0f,50.0f);
    this->GameDefaultData.Widget.MessagePanel.SendingButton.Size = FVector2D(200.0f, 100.0f);
    this->GameDefaultData.Widget.MessagePanel.SendingButton.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.MessagePanel.SendingButton.BackGroundImage.IsShowImage = true;
    this->GameDefaultData.Widget.MessagePanel.SendingButton.BackGroundImage.Color = FColor::White;
    this->GameDefaultData.Widget.MessagePanel.SendingButton.BackGroundImage.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.MessagePanel.SendingButton.BackGroundImage.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.MessagePanel.SendingButton.TextBlock.BackGroundImage.IsShowImage = false;
    this->GameDefaultData.Widget.MessagePanel.SendingButton.TextBlock.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.MessagePanel.SendingButton.TextBlock.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.MessagePanel.SendingButton.TextBlock.FontColor = FColor::White;
    this->GameDefaultData.Widget.MessagePanel.SendingButton.TextBlock.FontSize = 32;
    this->GameDefaultData.Widget.MessagePanel.SendingButton.TextBlock.Text = FText::FromString(TEXT("发送"));
    this->GameDefaultData.Widget.MessagePanel.SendingButton.Icon.IsShowImage = false;
    this->GameDefaultData.Widget.MessagePanel.EditableTextBox.HintText = FText::FromString(TEXT("请输入文本..."));
    this->GameDefaultData.Widget.MessagePanel.EditableTextBox.Size = FVector2D(200.0f, 100.0f);
    this->GameDefaultData.Widget.MessagePanel.EditableTextBox.RelativePosition = FVector2D(0.0f);
    this->GameDefaultData.Widget.MessagePanel.EditableTextBox.BackGroundImage.IsShowImage = true;
    this->GameDefaultData.Widget.MessagePanel.EditableTextBox.BackGroundImage.Color = FLinearColor(0.3f, 0.4f, 0.4f).ToFColor(true);
    this->GameDefaultData.Widget.MessagePanel.EditableTextBox.BackGroundImage.Size = FVector2D(0.0f);
    this->GameDefaultData.Widget.MessagePanel.EditableTextBox.BackGroundImage.RelativePosition = FVector2D(0.0f);





}


 void AFTL_GameStateBase::BeginPlay()
{
     Super::BeginPlay();
}

void AFTL_GameStateBase::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps)const
{
    Super::GetLifetimeReplicatedProps(OutLifetimeProps);


}



void AFTL_GameStateBase::OnRep_ReplicatedHasBegunPlay()
{
    Super::OnRep_ReplicatedHasBegunPlay();
  ////  GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Red, TEXT("OnRep_ReplicatedHasBegunPlay11111111111!!!!!!!!!!!!!!!"));

    UFTL_GameInstance* GameInstance = Cast<UFTL_GameInstance>(GetGameInstance());
    if (GameInstance==nullptr)
    {
        return;
    }
    GameInstance->GetDelegateManager()->OnLocalClientGameStateCompleteInitialize.Broadcast();



}

