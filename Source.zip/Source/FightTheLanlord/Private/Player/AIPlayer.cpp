﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "Player/AIPlayer.h"
#include "GameInstance/FTL_GameInstance.h"
#include "kismet/GameplayStatics.h"
#include "GameMode/BattleGameMode.h"
#include "Manager/DelegateManager.h"
#include "Manager/ObjectPoolManager.h"
#include "AIController/FTL_AIController.h"

#include "Manager/FTL_AssetManager.h"

AAIPlayer::AAIPlayer()
{
	this->AIControllerClass = AFTL_AIController::StaticClass();
	this->AutoPossessAI = EAutoPossessAI::PlacedInWorldOrSpawned;
}


void AAIPlayer::BeginPlay()
{
	Super::BeginPlay();
	GetGameInstance()->GetDelegateManager()->OnObjectBeginPlay.AddUObject(this,&AAIPlayer::OnObjectBeginPlay);
	GetGameInstance()->GetDelegateManager()->OnObjectEndPlay.AddUObject(this, &AAIPlayer::OnObjectEndPlay);
	GetGameInstance()->GetDelegateManager()->OnGameOver.AddUObject(this, &AAIPlayer::OnGameOver);
	GetGameInstance()->GetDelegateManager()->OnCreateAIPlayer.AddUObject(this, &AAIPlayer::OnCreateAIPlayer);

}


void AAIPlayer::EndPlay(EEndPlayReason::Type EndPlayResason)
{
	Super::EndPlay(EndPlayResason);

}


void AAIPlayer::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}


UFTL_GameInstance* AAIPlayer::GetGameInstance()
{
	if (this->GameInstance == nullptr)
	{
		this->GameInstance = Cast<UFTL_GameInstance>(UGameplayStatics::GetGameInstance(this));

	}
	return this->GameInstance;
}


void AAIPlayer::OnObjectBeginPlay(AActor* Object)
{

	if (Object!=this)
	{
		return;
	}
	
}

void AAIPlayer::OnObjectEndPlay(AActor* Object)
{
	if (Object != this)
	{
		return;
	}
	
}

void AAIPlayer::OnGameOver(bool IsLanlordWin)
{
	GetGameInstance()->GetObjectPoolManager()->ReturnObject(GetGameInstance(), TEXT("AIPlayer"), this);


}

void AAIPlayer::OnCreateAIPlayer(int32 PlayerID)
{
	ABattleGameMode* GameMode = Cast<ABattleGameMode>(UGameplayStatics::GetGameMode(this));
	TArray<FCardInformation> Array;
	Array = GameMode->GetPlayerCardHand(PlayerID);
	AFTL_AIController* AIController = Cast<AFTL_AIController>(GetController());
	AIController->SetPlayerCardHand(Array);
	AIController->SetPlayerID(PlayerID);



}

