﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "Player/FTL_Player.h"


AFTL_Player::AFTL_Player()
{
	PrimaryActorTick.bCanEverTick = false;

}

void AFTL_Player::BeginPlay()
{
	Super::BeginPlay();

}

void AFTL_Player::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

void AFTL_Player::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

}

