﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "BehaviorTree/Decorator/CheckHasValidHandTypeDecorator.h"


#include "GameInstance/FTL_GameInstance.h"
#include "kismet/GameplayStatics.h"
#include "GameMode/BattleGameMode.h"
#include "Manager/DelegateManager.h"
#include "Manager/ObjectPoolManager.h"
#include "AIController/FTL_AIController.h"



bool UCheckHasValidHandTypeDecorator::CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const
{
	Super::CalculateRawConditionValue(OwnerComp, NodeMemory);
	AFTL_AIController* AIController = Cast<AFTL_AIController>(OwnerComp.GetAIOwner());
	/*FCardInformation SelectedCard;
	FTurnHandTypeInformation Information = AIController->GetGameMode()->GetLastTurnHandTypeInformation();
	int32 t = 0;
	int32 CardNumber = AIController->CardArray.Num();
	SelectedCard.Value = -1;
	if (Information.Information.HandType != EHandType::Single)
	{
		AIController->RemoveAllSelectedCard();
		return false;
	}
	if (Information.PlayerID == -1)
	{
		SelectedCard = AIController->CardArray[FMath::RandRange(0, CardNumber - 1)];
		AIController->SelectedCardArray.Add(SelectedCard);
		return true;
	}
	if (Information.PlayerID == AIController->GetPlayerID())
	{
		SelectedCard = AIController->CardArray[FMath::RandRange(0, CardNumber - 1)];
		AIController->SelectedCardArray.Add(SelectedCard);
		return true;
	}
	while (SelectedCard.Value < Information.Information.Value && t < 100)
	{
		SelectedCard = AIController->CardArray[FMath::RandRange(0, CardNumber - 1)];
	}
	if (SelectedCard.Value > Information.Information.Value)
	{
		AIController->SelectedCardArray.Add(SelectedCard);

		return true;
	}*/

	return AIController->CheckHasValidHandType();
	
}



