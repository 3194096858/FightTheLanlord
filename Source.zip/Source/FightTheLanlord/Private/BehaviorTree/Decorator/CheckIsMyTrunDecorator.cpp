﻿

#include "BehaviorTree/Decorator/CheckIsMyTrunDecorator.h"

#include "GameInstance/FTL_GameInstance.h"
#include "kismet/GameplayStatics.h"
#include "GameMode/BattleGameMode.h"
#include "Manager/DelegateManager.h"
#include "Manager/ObjectPoolManager.h"
#include "AIController/FTL_AIController.h"



bool UCheckIsMyTrunDecorator::CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const
{
	Super::CalculateRawConditionValue(OwnerComp,NodeMemory);
	ABattleGameMode* GameMode = Cast<ABattleGameMode>(UGameplayStatics::GetGameMode(this));
	AFTL_AIController* AIController = Cast<AFTL_AIController>(OwnerComp.GetAIOwner());
	//GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Red, FString::Printf(TEXT(" PlayerID 22222222222== %d "),AIController->GetPlayerID()));

	if (GameMode->GetCurrentTurnPlayerID() == AIController->GetPlayerID())
	{

		return true;
	}
	else
	{

		return false;

	}
}



