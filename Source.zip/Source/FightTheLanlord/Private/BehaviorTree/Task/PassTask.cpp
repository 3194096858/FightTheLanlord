﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "BehaviorTree/Task/PassTask.h"


#include "GameInstance/FTL_GameInstance.h"
#include "kismet/GameplayStatics.h"
#include "GameMode/BattleGameMode.h"
#include "Manager/DelegateManager.h"
#include "Manager/ObjectPoolManager.h"
#include "AIController/FTL_AIController.h"

EBTNodeResult::Type UPassTask::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	Super::ExecuteTask(OwnerComp, NodeMemory);
	AFTL_AIController* AIController = Cast<AFTL_AIController>(OwnerComp.GetAIOwner());
	AIController->Pass();
	return EBTNodeResult::Succeeded;
}