﻿

#include "PlayerState/FTL_PlayerStateBase.h"
#include "GameInstance/FTL_GameInstance.h"
#include "Net/UnrealNetwork.h"
#include "Manager/WidgetManager.h"

AFTL_PlayerStateBase::AFTL_PlayerStateBase()
{
	
   /// Super::OnRep_Playr
}



float AFTL_PlayerStateBase::GetBean()
{
    return this->Bean.GetCurrent();
}


int32 AFTL_PlayerStateBase::GetID()
{
    return this->ID;
}

void AFTL_PlayerStateBase::SetID(int32 NewID)
{
    this->ID = NewID;
}

void AFTL_PlayerStateBase::SetCardHand(const TArray<FCardInformation>& NewArray)
{
    this->CardArray = NewArray;

}



void AFTL_PlayerStateBase::SetAllSelectedCard(const TArray<FCardInformation>& NewArray)
{

    this->SelectedCardArray = NewArray;

}

TArray<FCardInformation> AFTL_PlayerStateBase::GetAllSelectedCardFormCardHand()
{
    UFTL_GameInstance* GameInstance = Cast<UFTL_GameInstance>(GetGameInstance());
    this->SelectedCardArray = GameInstance->GetWidgetManager()->GetAllSelectedCardInformationFromCardHand();
    if (this->SelectedCardArray.Num() == 0)
    {
        //GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, FString::Printf(TEXT("this->SelectedCardArray.Num() == 0  ：ID= %d   !!!"),GetID()));
    }


    return this->SelectedCardArray;
}


void AFTL_PlayerStateBase::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps)const
{
    Super::GetLifetimeReplicatedProps(OutLifetimeProps);
    DOREPLIFETIME(AFTL_PlayerStateBase,ID);
    DOREPLIFETIME(AFTL_PlayerStateBase, SelectedCardArray);


}

