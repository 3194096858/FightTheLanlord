﻿

#include "GameInstance/FTL_GameInstance.h"
#include "Manager/AudioManager.h"
#include "Manager/DelegateManager.h"
#include "Manager/FTL_AssetManager.h"
#include "Manager/WidgetManager.h"
#include "Manager/GameSettingsManager.h"
#include "Manager/GameSessionManager.h"
#include "Manager/FTL_TimerManager.h"
#include "Manager/CardLibrary.h"
#include "Manager/LevelManager.h"
#include "Kismet/GameplayStatics.h"
#include "Widget/WidgetBase.h"
#include "GameState/FTL_GameStateBase.h"
#include "PlayerController/BattleLevelPlayerController.h"
#include "Kismet/KismetSystemLibrary.h"

#include "Manager/ObjectPoolManager.h"

UFTL_GameInstance::UFTL_GameInstance()
{



}

void UFTL_GameInstance::Init()
{
	Super::Init();
	GetDelegateManager()->OnLocalClientSwitchLevel.AddUObject(this,&UFTL_GameInstance::OnLocalClientSwitchLevel);
	GetDelegateManager()->OnLocalClientSwitchLevelComplete.AddUObject(this, &UFTL_GameInstance::OnLocalClientSwitchLevelComplete);
	GetGameSessionManager()->OnQuitSessionComplete.AddUObject(this, &UFTL_GameInstance::OnQuitSessionComplete);
	GetGameSessionManager()->OnJoinSessionComplete.AddUObject(this, &UFTL_GameInstance::OnJoinSessionComplete);

	GEngine->OnNetworkFailure().AddUObject(this,&UFTL_GameInstance::OnNetworkFailure);
	GetDelegateManager()->OnPlayLoadingAnimationComplete.AddUObject(this, &UFTL_GameInstance::OnPlayLoadingAnimationComplete);
	this->ClientGUID = FGuid::NewGuid().ToString();
	///GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Red, FString::Printf(TEXT("GameInstance : GUID = %s !!!! "),*this->ClientGUID));
}



void UFTL_GameInstance::OnStart()
{
	Super::OnStart();

}

UGameSessionManager* UFTL_GameInstance::GetGameSessionManager()
{
	if (this->GameSessionManager == nullptr)
	{
		this->GameSessionManager = NewObject<UGameSessionManager>(this);
	}
	return this->GameSessionManager;
}

UGameSettingsManager* UFTL_GameInstance::GetGameSettingsManager()
{
	if (this->GameSettingsManager == nullptr)
	{
		this->GameSettingsManager = NewObject<UGameSettingsManager>(this);
	}
	return this->GameSettingsManager;
}

UWidgetManager* UFTL_GameInstance::GetWidgetManager()
{
	if (this->WidgetManager == nullptr)
	{
		this->WidgetManager = NewObject<UWidgetManager>(this);
	}
	return this->WidgetManager;
}

UAudioManager* UFTL_GameInstance::GetAudioManager()
{
	if (this->AudioManager == nullptr)
	{
		this->AudioManager = NewObject<UAudioManager>(this);
	}
	return this->AudioManager;
}


UDelegateManager* UFTL_GameInstance::GetDelegateManager()
{
	if (this->DelegateManager == nullptr)
	{
		this->DelegateManager = NewObject<UDelegateManager>(this);

	}
	return this->DelegateManager;

}


UFTL_AssetManager* UFTL_GameInstance::GetAssetManager()
{
	if (this->AssetManager == nullptr && this->AssetManagerClass != nullptr)
	{
		this->AssetManager = NewObject<UFTL_AssetManager>(this,this->AssetManagerClass);
	}
	return this->AssetManager;
}


UFTL_TimerManager* UFTL_GameInstance::GetTimerManager()
{
	if (this->TimerManager == nullptr)
	{
		this->TimerManager = NewObject<UFTL_TimerManager>(this);
	}
	return this->TimerManager;
}




AFTL_GameStateBase* UFTL_GameInstance::GetGameState()
{
	if (this->GameState == nullptr)
	{
		this->GameState = Cast<AFTL_GameStateBase>(UGameplayStatics::GetGameState(this));
	}
	return this->GameState;
}


UCardLibrary* UFTL_GameInstance::GetCardLibrary()
{
	if (this->CardLibrary == nullptr)
	{
		this->CardLibrary = NewObject<UCardLibrary>(this);
	}
	return this->CardLibrary;
}

ULevelManager* UFTL_GameInstance::GetLevelManager()
{
	if (this->LevelManager == nullptr)
	{
		this->LevelManager = NewObject<ULevelManager>(this);
	}
	return this->LevelManager;
}


UObjectPoolManager* UFTL_GameInstance::GetObjectPoolManager()
{

	if (this->ObjectPoolManager == nullptr)
	{
		this->ObjectPoolManager = NewObject<UObjectPoolManager>(this);
	}
	return this->ObjectPoolManager;
}


void UFTL_GameInstance::DestroyCardLibrary()
{
	if (this->CardLibrary!=nullptr)
	{
		this->CardLibrary = nullptr;
	}

}

void UFTL_GameInstance::OnLocalClientSwitchLevel()
{
	GetWidgetManager()->PlayLoadingAnimation(true);
	GetAudioManager()->PauseAllBGM();
}

void UFTL_GameInstance::OnLocalClientSwitchLevelComplete(const FString& CurrentLevelName)
{
	GEngine->AddOnScreenDebugMessage(-1, 11.f, FColor::Red, FString::Printf(TEXT("GameInstance : Switch  Level Complete ，CurrentLevel=%s !!!! "),*CurrentLevelName));
	GetWidgetManager()->InitializeGameScreen();
	GetWidgetManager()->PlayLoadingAnimation(false);
	if (CurrentLevelName == TEXT("GameMainPageLevel"))
	{
		GEngine->AddOnScreenDebugMessage(-1, 11.f, FColor::Red, FString::Printf(TEXT("GameInstance : Switch   GameMainPageLevel Complete !!!! ")));

		GetDelegateManager()->OnGameMainPageOpen.Broadcast();
		return;
	}
	if (CurrentLevelName == TEXT("GameLobbyLevel"))
	{
		GetDelegateManager()->OnGameLobbyPanelOpen.Broadcast();
		return;

	}
	if (CurrentLevelName == TEXT("BattleLevel"))
	{
		GetWidgetManager()->UpdateBackGroundImage(this, TEXT("Battle"));
		GetDelegateManager()->OnOperationPanelOpen.Broadcast();
		GetDelegateManager()->OnPlayerPanelOpen.Broadcast();
		GetDelegateManager()->OnCardTableWidgetOpen.Broadcast();
		GetWidgetManager()->PlayDealCardAnimation();
		return;
	}

}



void UFTL_GameInstance::OnPlayLoadingAnimationComplete(bool IsForward)
{
	if (IsForward == true)
	{
		GetWidgetManager()->RemoveAllWidgetFromViewport(EWidgetRenderingLevel::HUD);
		GetLevelManager()->SwitchLevel(this);
		GEngine->AddOnScreenDebugMessage(-1, 11.f, FColor::Red, FString::Printf(TEXT("GameInstance : Switch    Level !!!! ")));

	}




}



void UFTL_GameInstance::OnQuitSessionComplete(const FName& Session)
{
	GetLevelManager()->SetLevelSwitchSettings(TEXT("GameMainPageLevel"), false);
	GetDelegateManager()->OnLocalClientSwitchLevel.Broadcast();
	GEngine->AddOnScreenDebugMessage(-1, 11.f, FColor::Red, FString::Printf(TEXT("GameInstance : Quit Session Complete !!!! ")));


}


void UFTL_GameInstance::OnJoinSessionComplete(const FName& Session)
{
	FString HostIP;
	FString HostPort;
	GetGameSessionManager()->GetHostIPAndPort(Session,HostIP,HostPort);
	GetLevelManager()->SetLevelSwitchSettings(HostIP);
	GetDelegateManager()->OnLocalClientSwitchLevel.Broadcast();


}

void UFTL_GameInstance::JoinSelectedSession(bool IsServer)
{
	if (IsServer == true)
	{
		GetGameSessionManager()->SetCurrentSessionName(GetGameSessionManager()->GetSelectedSessionName());
		GetLevelManager()->SetLevelSwitchSettings(TEXT("GameLobbyLevel"), true);
		GetDelegateManager()->OnLocalClientSwitchLevel.Broadcast();
	}
	else
	{
		GetGameSessionManager()->JoinSelectedSession();
	}
}




void UFTL_GameInstance::OnNetworkFailure(UWorld* World, UNetDriver* NetDriver, ENetworkFailure::Type FailureType, const FString& ErrorString)
{
	if (FailureType == ENetworkFailure::ConnectionLost)
	{
		auto Lambda = [this]()
		{
				GetGameSessionManager()->QuitCurrentSession();
				GetLevelManager()->SetLevelSwitchSettings(TEXT("GameMainPageLevel"), false);
				GetLevelManager()->SwitchLevel(this);
				GetAudioManager()->PauseAllBGM();
		};
		GetWorld()->GetTimerManager().SetTimer(this->TimerHandle,Lambda, 1.0f, false);

	}

}