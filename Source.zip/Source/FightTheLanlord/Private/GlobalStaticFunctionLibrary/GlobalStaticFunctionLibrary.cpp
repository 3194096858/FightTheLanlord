﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "GlobalStaticFunctionLibrary/GlobalStaticFunctionLibrary.h"

FName UGlobalStaticFunctionLibrary::GetNameByEnum(ECardSuit Suit)
{
	if (CardSuitMap.Num() == 0)
	{
		CardSuitMap.Add(TEXT("Heart"),ECardSuit::Heart);
		CardSuitMap.Add(TEXT("Clud"), ECardSuit::Clud);
		CardSuitMap.Add(TEXT("Spade"), ECardSuit::Spade);
		CardSuitMap.Add(TEXT("Diamond"), ECardSuit::Diamond);

	}
	const FName* Name = CardSuitMap.FindKey(Suit);
	if (Name!=nullptr)
	{
		return *Name;
	}
	return TEXT("None");
}


FName UGlobalStaticFunctionLibrary::GetNameByEnum(EHandType HandType)
{
	if (HandTypeMap.Num() == 0)
	{
		HandTypeMap.Add(TEXT("Single"),EHandType::Single);
		HandTypeMap.Add(TEXT("Pair"), EHandType::Pair);
		HandTypeMap.Add(TEXT("Triple"), EHandType::Triple);
		HandTypeMap.Add(TEXT("SingleStraight"), EHandType::SingleStraight);
		HandTypeMap.Add(TEXT("PairStraight"), EHandType::PairStraight);
		HandTypeMap.Add(TEXT("TripletWithKicker"), EHandType::TripletWithKicker);
		HandTypeMap.Add(TEXT("Airplane"), EHandType::Airplane);
		HandTypeMap.Add(TEXT("Bomb"), EHandType::Bomb);
		HandTypeMap.Add(TEXT("JokerBomb"), EHandType::JokerBomb);
		HandTypeMap.Add(TEXT("AirplaneWithWing"), EHandType::AirplaneWithWing);

	}
	const FName* Name = HandTypeMap.FindKey(HandType);
	if (Name != nullptr)
	{
		return *Name;
	}
	return TEXT("None");
}