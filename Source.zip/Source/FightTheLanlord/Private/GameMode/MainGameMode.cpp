﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "GameMode/MainGameMode.h"



#include "GameInstance/FTL_GameInstance.h"

#include "Kismet/GameplayStatics.h"
#include "Manager/WidgetManager.h"

#include "Manager/GameSettingsManager.h"
#include "Manager/DelegateManager.h"

///#include "GameState/FTL_GameStateBase.h"
#include "Widget/BackGroundWidget.h"

AMainGameMode::AMainGameMode()
{



}


void AMainGameMode::BeginPlay()
{
	Super::BeginPlay();
	///GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, TEXT(" OpenMainLevel !!!!"));
	///GetGameInstance()->GetDelegateManager()->OnStartMenuOpen.Broadcast();

}

void AMainGameMode::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}





