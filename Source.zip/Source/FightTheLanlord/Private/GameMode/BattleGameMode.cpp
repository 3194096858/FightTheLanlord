﻿

#include "GameMode/BattleGameMode.h"



#include "GameInstance/FTL_GameInstance.h"

#include "Kismet/GameplayStatics.h"

#include "PlayerController/BattleLevelPlayerController.h"

#include "GameState/FTL_GameStateBase.h"
#include "PlayerState/FTL_PlayerStateBase.h"
#include "Manager/CardLibrary.h"
#include "Widget/BackGroundWidget.h"
#include "Manager/DelegateManager.h"

#include "GlobalStaticFunctionLibrary/GlobalStaticFunctionLibrary.h"
#include "Manager/FTL_TimerManager.h"
#include "Manager/ObjectPoolManager.h"

#include "Player/AIPlayer.h"
#include "Enum/PlayerPlayCardFailureReason.h"
#include "Manager/GameSessionManager.h"

#include "GameFramework/GameSession.h"






ABattleGameMode::ABattleGameMode()
{
	this->LastTurnHandTypeInformation.PlayerID = -1;
	this->CurrentTurnHandTypeInformation.PlayerID = -1;
	this->GameplayInformation.PlayerNumber = 2;
	this->GameplayInformation.TurnDuration = 30;
	this->GameplayInformation.AFKLimit = 3;
	this->GameplayInformation.PlayerCardNumber = 5;
	this->GameplayInformation.HoleCardNumber = 3;

}


void ABattleGameMode::BeginPlay()
{
	Super::BeginPlay();

}


void ABattleGameMode::EndPlay(EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);
	GetWorld()->GetTimerManager().ClearTimer(this->CountdownTimerHandle);
	GetGameInstance()->DestroyCardLibrary();

}


void ABattleGameMode::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

void ABattleGameMode::InitGame(const FString& MapName, const FString& Options, FString& ErrorMessage)
{
	Super::InitGame(MapName,Options,ErrorMessage);
	GetGameInstance()->GetCardLibrary()->Initialize(GetGameInstance());
	this->LanlordPlayerID = FMath::RandRange(1, this->GameplayInformation.PlayerNumber);
	this->CurrentTurnPlayerID = this->LanlordPlayerID;
	FCardInformation Card;
	for (int32 i = 0; i < this->GameplayInformation.HoleCardNumber; i++)
	{
		Card = GetGameInstance()->GetCardLibrary()->GetRandomCard();
		this->HoleCardArray.Add(Card);

	}
	GetWorld()->GetTimerManager().SetTimer(this->CountdownTimerHandle,this,&ABattleGameMode::Countdown,1.0f,true);
	GetWorld()->GetTimerManager().PauseTimer(this->CountdownTimerHandle);
}

void ABattleGameMode::PreLogin(const FString& Options, const FString& Address, const FUniqueNetIdRepl& UniqueId, FString& ErrorMessage)
{
	Super::PreLogin(Options,Address,UniqueId,ErrorMessage);
	if (this->IsGameStart == true)
	{
		ErrorMessage = TEXT("PlayerLoginFailure: Game Start  !!!!");
		GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Red, FString::Printf(TEXT("GameMode:  %s  !!!!!"),*ErrorMessage));

	}
}

void ABattleGameMode::PostLogin(APlayerController* NewPlayer)
{
	Super::PostLogin(NewPlayer);
	InitializePlayerID(NewPlayer);
	InitializePlayerCardHand(NewPlayer);
	InitializePlayerHoleCard(NewPlayer);
	this->PlayerAFKNumberMap.Add(GameState->PlayerArray.Num() + 1, 0);
	GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Red, FString::Printf(TEXT("GameMode:  Player Login !!!!!")));

}


void ABattleGameMode::Logout(AController* Exiting)
{
	Super::Logout(Exiting);
	GameState->RemovePlayerState(Exiting->PlayerState);
	int32 ID = Cast<ABattleLevelPlayerController>(Exiting)->GetPlayerID();
	this->AIPlayerCardHandMap.Add(ID,GetPlayerCardHand(ID));
	this->PlayerCardHandMap.Remove(ID);
	/////this->ClientGUIDMap.Remove(ID);
	if (this->IsGameOver == true)
	{
		return;
	}
	if (GetGameInstance()->GetFirstLocalPlayerController() != Exiting)
	{
		GetGameInstance()->GetObjectPoolManager()->GetObject<AAIPlayer>(GetGameInstance(), TEXT("AIPlayer"), FTransform());
		GetGameInstance()->GetDelegateManager()->OnCreateAIPlayer.Broadcast(ID);
		return;
	}
	ABattleLevelPlayerController* Controller = nullptr;
	Controller = Cast<ABattleLevelPlayerController>(Exiting);
	for (auto& Element : GetGameInstance()->GetGameState()->PlayerArray)
	{
		Controller = Cast<ABattleLevelPlayerController>(Element->GetPlayerController());
		if (Controller != GetGameInstance()->GetFirstLocalPlayerController())
		{
			Controller->Client_QuitSession();
		}

	}
	GetWorld()->GetTimerManager().SetTimer(this->QuitSessionTimerHandle, this, &ABattleGameMode::QuitSession, 1.0f, false);
}
bool ABattleGameMode::CheckClientGUIDIsExist(const FString& GUID)
{
	/*TArray<FString> GUIDArray;
	this->ClientGUIDMap.GenerateValueArray(GUIDArray);
	bool IsExist = GUIDArray.Contains(GUID);
	if (GetPlayerController(GUID)!= nullptr)
	{
		///GetPlayerController(GUID)->Client_OnServerCheckClientGUIDComplete(IsExist);
		GetPlayerController(GUID)->Client_QuitSession();

	}
	else
	{
		GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Red, FString::Printf(TEXT("GameMode: GUID Is Invalid : %s  !!!!!"),*GUID));

	}*/
	return false;
}
void ABattleGameMode::OnCheckClientGUIDComplete(const FString& GUID,bool IsExist)
{
	/*if (IsExist == true)
	{
		GetPlayerController(GUID)->Client_QuitSession();
	}*/

}
void ABattleGameMode::InitializePlayerID(APlayerController* PlayerController)
{
	if (PlayerController ==nullptr)
	{
		return;
	}
	int32 Index = 0;
	bool IsExist = false;
	AFTL_PlayerStateBase* PlayerState = Cast<AFTL_PlayerStateBase>(PlayerController->PlayerState);
	ABattleLevelPlayerController* Controller = Cast<ABattleLevelPlayerController>(PlayerController);
	IsExist = GameState->PlayerArray.Find(PlayerController->PlayerState, Index);
	if (IsExist == true)
	{
		PlayerState->SetID(Index + 1);
	}
}


void ABattleGameMode::InitializePlayerCardHand(APlayerController* PlayerController)
{
	if (PlayerController == nullptr)
	{
		return;
	}
	ABattleLevelPlayerController* Controller = Cast<ABattleLevelPlayerController>(PlayerController);
	AFTL_PlayerStateBase* PlayerState = Cast<AFTL_PlayerStateBase>(PlayerController->PlayerState);
	TArray<FCardInformation> CardArray;
	FCardInformation Card;
	int32 CardNumber = this->GameplayInformation.PlayerCardNumber;
	int32 ID = PlayerState->GetID();
	for (int32 i = 0; i < CardNumber; i++)
	{
		Card = GetGameInstance()->GetCardLibrary()->GetRandomCard();
		CardArray.Add(Card);
	}
	if (ID == this->LanlordPlayerID)
	{
		for (int32 i = 0; i < this->GameplayInformation.HoleCardNumber; i++)
		{
			CardArray.Add(HoleCardArray[i]);
		}
	}
	PlayerState->SetCardHand(CardArray);
	this->PlayerCardHandMap.Add(ID, CardArray);
	Controller->Client_AddCardToPlayerCardHand(CardArray);
	/*for (auto& Element: GetPlayerCardHand(ID))
	{
		FName Name = UGlobalStaticFunctionLibrary::GetNameByEnum(Element.Suit);
		UE_LOG(LogTemp, Warning, TEXT("GameMode: PlayerID= %d, CardName = %s, CardSuit = %s  "), ID,*Element.Name.ToString(),*Name.ToString() );

	}*/
	
}



void ABattleGameMode::InitializePlayerHoleCard(APlayerController* PlayerController)
{
	//ABattleLevelPlayerController* Controller = Cast<ABattleLevelPlayerController>(PlayerController);
	//Controller->Client_InitializeHoleCard(this->HoleCardArray);
	/////GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Red, FString::Printf(TEXT("GameMode: Initialize   Player%d   HoleCardPanel !!!!!"),Controller->GetPlayerID()));
	//for (auto& Element: this->HoleCardArray)
	//{
	//	////FName Name = UGlobalStaticFunctionLibrary::GetNameByEnum(Element.Suit);
	//	GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Red, FString::Printf(TEXT("GameMode: Initialize HoleCardPanel: %s  !!!!!"),*Element.Name.ToString()));
	//}

}

void ABattleGameMode::AddClientGUID(int32 PlayerID, const FString& GUID)
{
	if (this->ClientGUIDMap.Find(PlayerID) != nullptr)
	{
		return;
	}
	this->ClientGUIDMap.Add(PlayerID, GUID);


}


int32 ABattleGameMode::GetCurrentTurnPlayerID()
{
	return this->CurrentTurnPlayerID;

}


void ABattleGameMode::QuitSession()
{
	GetGameInstance()->GetGameSessionManager()->QuitCurrentSession();
	GetWorld()->GetTimerManager().ClearTimer(this->QuitSessionTimerHandle);

}

void ABattleGameMode::Countdown()
{
	if (GetCurrentTurnPlayerController() !=nullptr)
	{
		GetCurrentTurnPlayerController()->Client_SetCountdownTimerText(this->TurnTimeleft);
	}
	this->TurnTimeleft--;
	if (this->TurnTimeleft == 0)
	{
		OnPlayerTimeout();
	}


}

int32 ABattleGameMode::GetLanlordPlayerID()
{
	return this->LanlordPlayerID;

}


ABattleLevelPlayerController* ABattleGameMode::GetCurrentTurnPlayerController()
{
	int32 Index = this->CurrentTurnPlayerID - 1;
	ABattleLevelPlayerController* Controller = nullptr;

	if (GameState->PlayerArray.IsValidIndex(Index) == true)
	{
		 Controller = Cast<ABattleLevelPlayerController>(GameState->PlayerArray[Index]->GetPlayerController());
	}
	
	return Controller;

}

ABattleLevelPlayerController* ABattleGameMode::GetPlayerController(const FString& GUID)
{
	if(this->ClientGUIDMap.FindKey(GUID)==nullptr)
	{
		return nullptr;
	}
	int32 PlayerID = *this->ClientGUIDMap.FindKey(GUID);
	return GetPlayerController(PlayerID);

}
ABattleLevelPlayerController* ABattleGameMode::GetPlayerController(int32 PlayerID)
{
	int32 Index = PlayerID - 1;
	ABattleLevelPlayerController* Controller = nullptr;
	if (GameState->PlayerArray.IsValidIndex(Index) == true)
	{
		Controller = Cast<ABattleLevelPlayerController>(GameState->PlayerArray[Index]->GetPlayerController());
	}
	return Controller;

}

TArray<ABattleLevelPlayerController*> ABattleGameMode::GetAllPlayerController()
{
	TArray<ABattleLevelPlayerController*> Array;
	ABattleLevelPlayerController* Controller = nullptr;
	for (auto& Element:GameState->PlayerArray)
	{
		Controller = Cast<ABattleLevelPlayerController>(Element->GetPlayerController());
		Array.Add(Controller);
	}
	return Array;
}

int32 ABattleGameMode::GetCurrentPlayerNumber()
{
	return GameState->PlayerArray.Num();
}

EHandType ABattleGameMode::CheckIsLegalHandType(const TArray<FCardInformation>& CardArray)
{
	int32 CardNumber = CardArray.Num();
	int32 RedJokerValue = 15;
	int32 BlackJokerValue = 14;
	if (CardNumber == 1)
	{
		return EHandType::Single;
	}
	if (CardNumber == 2)
	{
		if (CardArray[0].Value == CardArray[1].Value)
		{
			return EHandType::Pair;
		}
		if (CardArray[0].Value >= BlackJokerValue && CardArray[1].Value >= BlackJokerValue)
		{
			return EHandType::JokerBomb;
		}
	}
	if (CardNumber == 3)
	{
		if (CardArray[0].Value == CardArray[1].Value && CardArray[0].Value == CardArray[2].Value)
		{
			return EHandType::Triple;
		}
	}
	if (CardNumber == 4)
	{
		if (CardArray[0].Value == CardArray[1].Value && CardArray[0].Value == CardArray[2].Value && CardArray[0].Value == CardArray[3].Value)
		{
			return EHandType::Bomb;
		}
	}
	if (CheckHandTypeIsTripletWithKicker(CardArray) == true)
	{
		return EHandType::TripletWithKicker;
	}
	if (CheckHandTypeIsSingleStraight(CardArray) == true)
	{
		return EHandType::SingleStraight;
	}
	if (CheckHandTypeIsPairStraight(CardArray) == true)
	{
		return EHandType::PairStraight;
	}
	if (CheckHandTypeIsAirplane(CardArray) == true)
	{
		return EHandType::Airplane;
	}
	if (CheckHandTypeIsAirplaneWithWing(CardArray) == true)
	{
		return EHandType::AirplaneWithWing;
	}
	if (CheckHandTypeIsFourWithTwo(CardArray) == true)
	{
		return EHandType::FourWithTwo;
	}
	return EHandType::None;

}

int32 ABattleGameMode::GetHandTypeValue(const TArray<FCardInformation>& CardArray)
{
	EHandType HandType = CheckIsLegalHandType(CardArray);
	if (HandType== EHandType::None)
	{
		return -1;
	}
	int32 CardNumber = CardArray.Num();
	TArray<int32> CardValueArray;
	TArray<int32> Value1Array;
	TArray<int32> Value2Array;
	TArray<int32> Value3Array;
	TArray<int32> Value4Array;
	int32 Value1 = CardNumber != 0 ? CardArray[FMath::RandRange(0, CardNumber - 1)].Value : -1;
	int32 Value2 = Value1;
	int32 Value3 = Value2;
	int32 Value4 = Value2;

	int32 t = 0;
	int32 HandTypeValue = -1;
	for (auto& Element : CardArray)
	{
		CardValueArray.Add(Element.Value);
	}
	CardValueArray.Sort();
	switch (HandType)
	{
	case EHandType::Single:
		HandTypeValue = CardValueArray[0];
		break;
	case EHandType::Pair:
		HandTypeValue = CardValueArray[0];
		break;
	case EHandType::Triple:
		HandTypeValue = CardValueArray[0];
		break;
	case EHandType::Bomb:
		HandTypeValue = CardValueArray[0];
		break;
	case EHandType::JokerBomb:
		HandTypeValue = CardValueArray[CardNumber - 1];
		break;
	case EHandType::TripletWithKicker:
		while (Value2 == Value1 && t < 100)
		{
			t++;
			Value2 = CardArray[FMath::RandRange(0, CardNumber - 1)].Value;
		}
		if (Value2 == Value1)
		{
			return -1;
		}
		for (auto& Element : CardArray)
		{
			if (Element.Value == Value1)
			{
				Value1Array.Add(Element.Value);
			}
			if (Element.Value == Value2)
			{
				Value2Array.Add(Element.Value);
			}
		}
		Value1Array.Num() == 3 ? HandTypeValue = Value1 : HandTypeValue = Value2;
		break;
	case EHandType::SingleStraight:
		HandTypeValue = CardValueArray[CardNumber - 1];
		break;
	case EHandType::PairStraight:
		HandTypeValue = CardValueArray[CardNumber - 1];
		break;
	case EHandType::Airplane:
		HandTypeValue = CardValueArray[CardNumber - 1];
		break;
	case EHandType::AirplaneWithWing:
		while (Value2 == Value1 && t < 100)
		{
			t++;
			Value2 = CardArray[FMath::RandRange(0, CardNumber - 1)].Value;
		}
		if (Value2 == Value1)
		{
			return -1;
		}
		while ((Value3 == Value1 || Value3 == Value2) && t < 100)
		{
			t++;
			Value3 = CardArray[FMath::RandRange(0, CardNumber - 1)].Value;
		}
		if (Value3 == Value1 || Value3 == Value2)
		{
			return -1;
		}
		while ((Value4 == Value1 || Value4 == Value2 || Value4 == Value3) && t < 100)
		{
			t++;
			Value3 = CardArray[FMath::RandRange(0, CardNumber - 1)].Value;
		}
		if ((Value4 == Value1 || Value4 == Value2 || Value4 == Value3))
		{
			return -1;
		}
		for (auto& Element : CardArray)
		{
			if (Element.Value == Value1)
			{
				Value1Array.Add(Element.Value);
			}
			if (Element.Value == Value2)
			{
				Value2Array.Add(Element.Value);
			}
			if (Element.Value == Value3)
			{
				Value3Array.Add(Element.Value);
			}
			if (Element.Value == Value4)
			{
				Value3Array.Add(Element.Value);
			}
		}
		if (Value1Array.Num() == 3 && Value2Array.Num() == 3)
		{
			Value1 > Value2  ? HandTypeValue = Value1 : HandTypeValue = Value2;
		}
		else if(Value1Array.Num() == 3 && Value3Array.Num() == 3)
		{
			Value1 > Value3 ? HandTypeValue = Value1 : HandTypeValue = Value3;

		}
		else if (Value1Array.Num() == 3 && Value4Array.Num() == 3)
		{
			Value1 > Value4 ? HandTypeValue = Value1 : HandTypeValue = Value4;

		}
		else if (Value2Array.Num() == 3 && Value3Array.Num() == 3)
		{
			Value2 > Value3 ? HandTypeValue = Value2 : HandTypeValue = Value3;

		}
		else if (Value2Array.Num() == 3 && Value4Array.Num() == 3)
		{
			Value2 > Value4 ? HandTypeValue = Value2 : HandTypeValue = Value4;
		}
		else
		{
			Value3 > Value4 ? HandTypeValue = Value3 : HandTypeValue = Value4;

		}
		break;
	case EHandType::FourWithTwo:
		while (Value2 == Value1 && t < 100)
		{
			t++;
			Value2 = CardArray[FMath::RandRange(0, CardNumber - 1)].Value;
		}
		if (Value2 == Value1)
		{
			return -1;
		}
		while ((Value3 == Value1|| Value3 == Value2) && t < 100)
		{
			t++;
			Value3 = CardArray[FMath::RandRange(0, CardNumber - 1)].Value;
		}
		if (Value3 == Value1 || Value3 == Value2)
		{
			return -1;
		}
		for (auto& Element : CardArray)
		{
			if (Element.Value == Value1)
			{
				Value1Array.Add(Element.Value);
			}
			if (Element.Value == Value2)
			{
				Value2Array.Add(Element.Value);
			}
			if (Element.Value == Value3)
			{
				Value3Array.Add(Element.Value);
			}
		}
		if (Value1Array.Num() == 4)
		{
			HandTypeValue = Value1;
		}
		else if(Value2Array.Num() == 4)
		{
			HandTypeValue = Value2;
		}
		else 
		{
			HandTypeValue = Value3;
		}
		break;
	}
	return HandTypeValue;
}


bool ABattleGameMode::CheckHandTypeIsTripletWithKicker(const TArray<FCardInformation>& CardArray)
{
	int32 CardNumber = CardArray.Num();
	if (CardNumber != 4 && CardNumber != 5)
	{
		return false;
	}
	TArray<int32> Value1Array;
	TArray<int32> Value2Array;
	int32 Value1 = CardNumber != 0 ? CardArray[FMath::RandRange(0, CardNumber - 1)].Value : -1;
	int32 Value2 = Value1;
	int32 t = 0;
	bool IsTripletWithKicker = false;
	while (Value2 == Value1 && t < 100)
	{
		t++;
		Value2 = CardArray[FMath::RandRange(0, CardNumber - 1)].Value;
	}
	if (Value2 == Value1)
	{
		return false;
	}
	for (auto& Element : CardArray)
	{
		if (Element.Value == Value1)
		{
			Value1Array.Add(Element.Value);
		}
		if (Element.Value == Value2)
		{
			Value2Array.Add(Element.Value);
		}
	}
	if (Value1Array.Num() == 3 && Value2Array.Num() == 2|| Value1Array.Num() == 3 && Value2Array.Num() == 1|| Value2Array.Num() == 3 && Value1Array.Num() == 2|| Value2Array.Num() == 3 && Value1Array.Num() == 1)
	{
		IsTripletWithKicker = true;
	}

	return IsTripletWithKicker;

}


bool ABattleGameMode::CheckHandTypeIsSingleStraight(const TArray<FCardInformation>& CardArray)
{
	int32 CardNumber = CardArray.Num();
	if (CardNumber < 5)
	{
		return false;
	}
	TArray<int32> CardValueArray;
	int32 t = 0;
	bool IsSingleStraight = true;
	for (auto& Element : CardArray)
	{
		CardValueArray.Add(Element.Value);
	}
	CardValueArray.Sort();
	if (CardValueArray[CardNumber-1] >= 13) 
	{
		return false;
	}
	for (int32 i = 0; i < CardNumber-1; i++)
	{
		if (CardValueArray[i + 1] - CardValueArray[i] != 1)
		{
			IsSingleStraight = false;
		}
	}
	return IsSingleStraight;
}


bool ABattleGameMode::CheckHandTypeIsPairStraight(const TArray<FCardInformation>& CardArray)
{
	int32 CardNumber = CardArray.Num();
	if (CardNumber < 6 || CardNumber % 2 == 1)
	{
		return false;
	}
	TArray<int32> Value1Array;
	TArray<int32> Value2Array;
	TArray<int32> Value3Array;
	int32 Value1 = CardNumber != 0 ? CardArray[FMath::RandRange(0, CardNumber - 1)].Value : -1;
	int32 Value2 = Value1;
	int32 Value3 = Value2;
	int32 t = 0;
	bool IsPairStraight = false;
	for (auto& Element : CardArray)
	{
		if (Element.Value >= 14)
		{
			return false;
		}
	}
	while (Value2 == Value1 && t < 100)
	{
		t++;
		Value2 = CardArray[FMath::RandRange(0, CardNumber - 1)].Value;
	}
	if (Value2 == Value1)
	{
		return false;
	}
	t = 0;
	while ((Value3 == Value1 || Value3 == Value2) && t < 100)
	{
		t++;
		Value3 = CardArray[FMath::RandRange(0, CardNumber - 1)].Value;
	}
	if (Value3 == Value2)
	{
		return false;
	}
	for (auto& Element : CardArray)
	{
		if (Element.Value == Value1)
		{
			Value1Array.Add(Element.Value);
		}
		if (Element.Value == Value2)
		{
			Value2Array.Add(Element.Value);
		}
		if (Element.Value == Value3)
		{
			Value3Array.Add(Element.Value);
		}
	}
	if (Value1Array.Num() == 2 && Value2Array.Num() == 2 && Value3Array.Num() == 2)
	{
		IsPairStraight = true;
	}
	return IsPairStraight;
}

bool ABattleGameMode::CheckHandTypeIsAirplane(const TArray<FCardInformation>& CardArray)
{
	int32 CardNumber = CardArray.Num();
	if (CardNumber != 6 )
	{
		return false;
	}
	TArray<int32> Value1Array;
	TArray<int32> Value2Array;
	int32 Value1 = CardNumber != 0 ? CardArray[FMath::RandRange(0, CardNumber - 1)].Value : -1;
	int32 Value2 = Value1;
	int32 t = 0;
	bool IsAirPlane = false;
	while (Value2 == Value1 && t < 100)
	{
		t++;
		Value2 = CardArray[FMath::RandRange(0, CardNumber - 1)].Value;
	}
	if (Value2 == Value1)
	{
		return false;
	}
	for (auto& Element : CardArray)
	{
		if (Element.Value == Value1)
		{
			Value1Array.Add(Element.Value);
		}
		if (Element.Value == Value2)
		{
			Value2Array.Add(Element.Value);
		}
	}
	if (Value1Array.Num() == 3 && Value2Array.Num() == 3 && FMath::Abs((Value1 - Value2)) == 1)
	{
		IsAirPlane = true;
	}
	return IsAirPlane;
}

bool ABattleGameMode::CheckHandTypeIsAirplaneWithWing(const TArray<FCardInformation>& CardArray)
{
	int32 CardNumber = CardArray.Num();
	if (CardNumber != 8 && CardNumber != 10)
	{
		return false;
	}
	TArray<int32> Value1Array;
	TArray<int32> Value2Array;
	TArray<int32> Value3Array;
	TArray<int32> Value4Array;

	int32 Value1 = CardNumber != 0 ? CardArray[FMath::RandRange(0, CardNumber - 1)].Value : -1;
	int32 Value2 = Value1;
	int32 Value3 = Value2;
	int32 Value4 = Value3;
	int32 t = 0;

	while (Value2 == Value1 && t < 100)
	{
		t++;
		Value2 = CardArray[FMath::RandRange(0, CardNumber - 1)].Value;
	}
	if (Value2 == Value1)
	{
		return false;
	}
	t = 0;
	while ((Value3 == Value1 || Value3 == Value2) && t < 100)
	{
		t++;
		Value3 = CardArray[FMath::RandRange(0, CardNumber - 1)].Value;
	}
	if ((Value3 == Value1 || Value3 == Value2))
	{
		return false;
	}
	t = 0;
	while ((Value4 == Value1 || Value4 == Value2|| Value4 == Value3) && t < 100)
	{
		t++;
		Value4 = CardArray[FMath::RandRange(0, CardNumber - 1)].Value;
	}
	if ((Value4 == Value1 || Value4 == Value2 || Value4 == Value3))
	{
		return false;
	}
	for (auto& Element : CardArray)
	{
		if (Element.Value == Value1)
		{
			Value1Array.Add(Element.Value);
		}
		if (Element.Value == Value2)
		{
			Value2Array.Add(Element.Value);
		}
		if (Element.Value == Value3)
		{
			Value3Array.Add(Element.Value);
		}
		if (Element.Value == Value4)
		{
			Value4Array.Add(Element.Value);
		}
	}
	if (Value1Array.Num() == 3 && Value2Array.Num() == 3 && FMath::Abs((Value1 - Value2)) == 1 && Value3Array.Num() == Value4Array.Num() 
		|| Value1Array.Num() == 3 && Value3Array.Num() == 3 && FMath::Abs((Value1 - Value3)) == 1 && Value2Array.Num() == Value4Array.Num()
		|| Value1Array.Num() == 3 && Value4Array.Num() == 3 && FMath::Abs((Value1 - Value4)) == 1 && Value2Array.Num() == Value3Array.Num()
		|| Value2Array.Num() == 3 && Value3Array.Num() == 3 && FMath::Abs((Value2 - Value3)) == 1 && Value1Array.Num() == Value4Array.Num()
		|| Value2Array.Num() == 3 && Value4Array.Num() == 3 && FMath::Abs((Value2 - Value4)) == 1 && Value1Array.Num() == Value3Array.Num()
		|| Value3Array.Num() == 3 && Value4Array.Num() == 3 && FMath::Abs((Value3 - Value4)) == 1 && Value1Array.Num() == Value2Array.Num()
	   )
	{
		return true;
	}
	return false;
}

bool ABattleGameMode::CheckHandTypeIsFourWithTwo(const TArray<FCardInformation>& CardArray)
{
	int32 CardNumber = CardArray.Num();
	if (CardNumber != 6 && CardNumber != 8)
	{
		return false;
	}
	TArray<int32> Value1Array;
	TArray<int32> Value2Array;
	int32 Value1 = CardNumber != 0 ? CardArray[FMath::RandRange(0, CardNumber - 1)].Value : -1;
	int32 Value2 = Value1;
	int32 t = 0;

	while (Value2 == Value1 && t < 100)
	{
		t++;
		Value2 = CardArray[FMath::RandRange(0, CardNumber - 1)].Value;
	}
	if (Value2 == Value1)
	{
		return false;
	}
	t = 0;

	for (auto& Element : CardArray)
	{
		if (Element.Value == Value1)
		{
			Value1Array.Add(Element.Value);
		}
		if (Element.Value == Value2)
		{
			Value2Array.Add(Element.Value);
		}

	}

	if ((Value1Array.Num() == 4 && (Value2Array.Num() == 1 || Value2Array.Num() == 2)) || (Value2Array.Num() == 4 && (Value1Array.Num() == 1 || Value1Array.Num() == 2)))
	{
		return true;
	}


	return false;
}



TArray<FCardInformation> ABattleGameMode::GetPlayerCardHand(int32 PlayerID)
{
	if (this->PlayerCardHandMap.Find(PlayerID)!= nullptr)
	{
		return *this->PlayerCardHandMap.Find(PlayerID);
	}

	if (this->AIPlayerCardHandMap.Find(PlayerID) != nullptr)
	{
		return *this->AIPlayerCardHandMap.Find(PlayerID);
	}
	return TArray<FCardInformation>{};

}

void ABattleGameMode::RemoveCardFromPlayerCardHand(int32 PlayerID, const TArray<FCardInformation>& CardArray)
{
	TArray<FCardInformation> PlayerCardHand ;
	if (this->PlayerCardHandMap.Find(PlayerID) != nullptr)
	{
		PlayerCardHand = *this->PlayerCardHandMap.Find(PlayerID);
	}
	if (this->AIPlayerCardHandMap.Find(PlayerID) != nullptr)
	{
		PlayerCardHand = *this->AIPlayerCardHandMap.Find(PlayerID);
	}
	for (auto& Element : CardArray)
	{
		for (int32 i = 0; i < PlayerCardHand.Num(); i++)
		{
			if (Element.Name == PlayerCardHand[i].Name && Element.Suit == PlayerCardHand[i].Suit)
			{
				PlayerCardHand.RemoveAt(i);
			}
		}

	}
	if (this->PlayerCardHandMap.Find(PlayerID) != nullptr)
	{
		this->PlayerCardHandMap.Add(PlayerID, PlayerCardHand);
	}
	if (this->AIPlayerCardHandMap.Find(PlayerID) != nullptr)
	{
		this->AIPlayerCardHandMap.Add(PlayerID, PlayerCardHand);
	}

}


FTurnHandTypeInformation ABattleGameMode::GetLastTurnHandTypeInformation()
{

	return this->LastTurnHandTypeInformation;
}


void ABattleGameMode::OnPlayerPlayCard(int32 PlayerID, const TArray<FCardInformation>& CardArray)
{
	if (this->PlayerCardHandMap.Find(PlayerID)==nullptr)
	{
		return;
	}
	int32 CardNumber = CardArray.Num();
	EPlayerPlayCardFailureReason FailureReason = EPlayerPlayCardFailureReason::None;
	FTurnHandTypeInformation TurnHandTypeInformation;
	TurnHandTypeInformation.Information.HandType = CheckIsLegalHandType(CardArray);
	TurnHandTypeInformation.Information.Value = GetHandTypeValue(CardArray);
	TurnHandTypeInformation.Information.Number = CardNumber;
	TurnHandTypeInformation.PlayerID = PlayerID;
	if (GetCurrentTurnPlayerID() != PlayerID)
	{
		FailureReason = EPlayerPlayCardFailureReason::NotYourTurn;
	}
	if (TurnHandTypeInformation.Information.Number == 0)
	{
		FailureReason = EPlayerPlayCardFailureReason::NoSelectedCard;
	}
	if (TurnHandTypeInformation.Information.HandType == EHandType::None)
	{
		FailureReason = EPlayerPlayCardFailureReason::IllegalHandType;
	}
	if (FailureReason != EPlayerPlayCardFailureReason::None)
	{
		GetPlayerController(PlayerID)->Client_OnPlayCardFailed(FailureReason);
		return;
	}
	if (this->LastTurnHandTypeInformation.PlayerID == -1 || this->LastTurnHandTypeInformation.PlayerID == this->CurrentTurnPlayerID)
	{
		this->CurrentTurnHandTypeInformation.Information.HandType = TurnHandTypeInformation.Information.HandType;
		this->CurrentTurnHandTypeInformation.Information.Value = TurnHandTypeInformation.Information.Value;
		this->CurrentTurnHandTypeInformation.Information.Number = TurnHandTypeInformation.Information.Number;
		this->CurrentTurnHandTypeInformation.PlayerID = PlayerID;
		RemoveCardFromPlayerCardHand(PlayerID, CardArray);
		for (auto& Element : GetAllPlayerController())
		{
			Element->Client_OnPlayerPlayCardSucceed(PlayerID, CardArray);
			if (GetPlayerController(PlayerID) != Element)
			{
				Element->Client_UpdatePlayerCardNumber(PlayerID, GetPlayerCardHand(PlayerID).Num());
			}
		}
		OnTurnEnd(PlayerID);
		return;
	}
	if (TurnHandTypeInformation.Information.HandType != this->LastTurnHandTypeInformation.Information.HandType &&(TurnHandTypeInformation.Information.HandType != EHandType::Bomb && TurnHandTypeInformation.Information.HandType != EHandType::JokerBomb))
	{
		FailureReason = EPlayerPlayCardFailureReason::DefferentHandType;
		GetPlayerController(PlayerID)->Client_OnPlayCardFailed(FailureReason);
		return;
	}
	if (TurnHandTypeInformation.Information.Value <= this->LastTurnHandTypeInformation.Information.Value )
	{
		FailureReason = EPlayerPlayCardFailureReason::SmallHandType;
		GetPlayerController(PlayerID)->Client_OnPlayCardFailed(FailureReason);
		return;
	}
	this->CurrentTurnHandTypeInformation.Information.HandType = TurnHandTypeInformation.Information.HandType;
	this->CurrentTurnHandTypeInformation.Information.Value = TurnHandTypeInformation.Information.Value;
	this->CurrentTurnHandTypeInformation.Information.Number = TurnHandTypeInformation.Information.Number;
	this->CurrentTurnHandTypeInformation.PlayerID = PlayerID;
	RemoveCardFromPlayerCardHand(PlayerID, CardArray);
	///FName Name = UGlobalStaticFunctionLibrary::GetNameByEnum(this->CurrentTurnHandTypeInformation.Information.HandType);
	///GEngine->AddOnScreenDebugMessage(-1,11.0f,FColor::Blue,FString::Printf(TEXT("2222222222222222222 PlayerID= %d : HandTypeName == %s  , Value= %d  , Number=%d  !!!!!"),PlayerID,*Name.ToString(), this->CurrentTurnHandTypeInformation.Information.Value, this->CurrentTurnHandTypeInformation.Information.Number));
	for (auto& Element : GetAllPlayerController())
	{
		Element->Client_OnPlayerPlayCardSucceed(PlayerID, CardArray);
		if (GetPlayerController(PlayerID) != Element)
		{
			Element->Client_UpdatePlayerCardNumber(PlayerID, GetPlayerCardHand(PlayerID).Num());
		}
	}
	OnTurnEnd(PlayerID);

}

void ABattleGameMode::OnAIPlayerPlayCard(int32 PlayerID, TArray<FCardInformation> CardArray)
{
	if (this->AIPlayerCardHandMap.Find(PlayerID) == nullptr)
	{
		return;
	}
	int32 CardNumber = CardArray.Num();
	EPlayerPlayCardFailureReason FailureReason = EPlayerPlayCardFailureReason::None;
	this->CurrentTurnHandTypeInformation.Information.HandType = CheckIsLegalHandType(CardArray);
	this->CurrentTurnHandTypeInformation.Information.Value = GetHandTypeValue(CardArray);
	this->CurrentTurnHandTypeInformation.Information.Number = CardNumber;
	this->CurrentTurnHandTypeInformation.PlayerID = PlayerID;
	RemoveCardFromPlayerCardHand(PlayerID, CardArray);
	for (auto& Element : GetAllPlayerController())
	{
		Element->Client_OnPlayerPlayCardSucceed(PlayerID, CardArray);
		if (GetPlayerController(PlayerID) != Element)
		{
			Element->Client_UpdatePlayerCardNumber(PlayerID, GetPlayerCardHand(PlayerID).Num());
		}
	}
	OnTurnEnd(PlayerID);

}


void ABattleGameMode::OnPlayerPass(int32 PlayerID)
{
	if (GetCurrentTurnPlayerID() == PlayerID/* && this->LastTurnHandTypeInformation.PlayerID != -1*/ )
	{
		OnTurnEnd(PlayerID);
		for (auto& Element : GetAllPlayerController())
		{
			Element->Client_OnPlayerPass(PlayerID);
		}
	}


}


void ABattleGameMode::OnTurnStart(int32 PlayerID)
{
	this->TurnTimeleft = this->GameplayInformation.TurnDuration;
	GetWorld()->GetTimerManager().UnPauseTimer(this->CountdownTimerHandle);
	if (GetCurrentTurnPlayerController() != nullptr)
	{
		GetCurrentTurnPlayerController()->Client_OnTurnStart(PlayerID);
	}


}


void ABattleGameMode::OnTurnEnd(int32 PlayerID)
{
	GetWorld()->GetTimerManager().PauseTimer(this->CountdownTimerHandle);
	for (auto& Element : this->PlayerCardHandMap)
	{
		if(this->PlayerCardHandMap.Find(Element.Key) ==nullptr)
		{
			continue;
		}
		if (Element.Value.Num() == 0)
		{
			this->WinnerPlayerID = Element.Key;
			OnGameOver();
			return;
		}
	}
	for (auto& Element : this->AIPlayerCardHandMap)
	{
		if (this->AIPlayerCardHandMap.Find(Element.Key) == nullptr)
		{
			continue;
		}
		if (Element.Value.Num() == 0)
		{
			this->WinnerPlayerID = Element.Key;
			OnGameOver();
			return;
		}
	}
	if (GetCurrentTurnPlayerController() != nullptr)
	{
		GetCurrentTurnPlayerController()->Client_OnTurnEnd(PlayerID);
	}
	if (this->CurrentTurnPlayerID < this->GameplayInformation.PlayerNumber)
	{
		this->CurrentTurnPlayerID++;
	}
	else
	{
		this->CurrentTurnPlayerID = 1;
	}
	this->LastTurnHandTypeInformation.Information.HandType = this->CurrentTurnHandTypeInformation.Information.HandType;
	this->LastTurnHandTypeInformation.Information.Value = this->CurrentTurnHandTypeInformation.Information.Value;
	this->LastTurnHandTypeInformation.Information.Number = this->CurrentTurnHandTypeInformation.Information.Number;
	this->LastTurnHandTypeInformation.PlayerID = this->CurrentTurnHandTypeInformation.PlayerID;
	OnTurnStart(this->CurrentTurnPlayerID);


}

void ABattleGameMode::OnGameStart()
{
	for (auto& Element : GetAllPlayerController())
	{
		Element->Client_InitializeHoleCard(this->HoleCardArray);

	}
	//ABattleLevelPlayerController* Controller = Cast<ABattleLevelPlayerController>(PlayerController);
	///GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Red, FString::Printf(TEXT("GameMode: Initialize   Player%d   HoleCardPanel !!!!!"),Controller->GetPlayerID()));
	/*for (auto& Element : this->HoleCardArray)
	{
		GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Red, FString::Printf(TEXT("GameMode: Initialize HoleCardPanel: %s  !!!!!"), *Element.Name.ToString()));
	}*/
	OnTurnStart(this->CurrentTurnPlayerID);
	this->IsGameStart = true;
}


void ABattleGameMode::OnGameOver()
{
	for (auto& Element : GetAllPlayerController())
	{
		Element->Client_OnGameOver(this->LanlordPlayerID,this->WinnerPlayerID);
		this->IsGameOver = true;
		this->CurrentTurnPlayerID = -1;
		this->PlayerAFKNumberMap.Empty();
	}
}



void ABattleGameMode::OnDealCardComplete(int32 LocalPlayerID)
{
	static int32 Number = 0;

	for (auto& Element : this->PlayerCardHandMap)
	{
		if (LocalPlayerID != Element.Key)
		{
			int32 CardNumber = GetPlayerCardHand(Element.Key).Num();
			GetPlayerController(LocalPlayerID)->Client_UpdatePlayerCardNumber(Element.Key, CardNumber);
		}

	}
	Number++;
	if (Number == this->GameplayInformation.PlayerNumber)
	{
		//OnTurnStart(this->CurrentTurnPlayerID);
		OnGameStart();
		Number = 0;
	}
}


void ABattleGameMode::OnPlayerSendMessage(int32 PlayerID, const FString& Message)
{

	for (auto& Element : GetAllPlayerController())
	{
		Element->Client_SendMessage(PlayerID,Message);
	}
}

void ABattleGameMode::OnPlayerTimeout()
{
	if(this->PlayerAFKNumberMap.Find(this->CurrentTurnPlayerID) == nullptr|| GetCurrentTurnPlayerController()==nullptr)
	{
		return;
	}
	int32 CurrentAFKNumber = *this->PlayerAFKNumberMap.Find(this->CurrentTurnPlayerID);
	if (CurrentAFKNumber == this->GameplayInformation.AFKLimit)
	{
		GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Red, FString::Printf(TEXT("GameMode: Player%d 多次挂机，已被踢出游戏 !!!!!"), this->CurrentTurnPlayerID));
		GetCurrentTurnPlayerController()->Client_QuitSession();
		return;
	}
	else
	{
		CurrentAFKNumber++;
		this->PlayerAFKNumberMap.Add(this->CurrentTurnPlayerID, CurrentAFKNumber);
		GetCurrentTurnPlayerController()->Client_Pass();
		
	}

}




