﻿

#include "GameMode/FTL_GameModeBase.h"

#include "GameInstance/FTL_GameInstance.h"

#include "Kismet/GameplayStatics.h"


#include "GameState/FTL_GameStateBase.h"
#include "Widget/BackGroundWidget.h"

AFTL_GameModeBase::AFTL_GameModeBase()
{



}


void AFTL_GameModeBase::BeginPlay()
{
	Super::BeginPlay();


}

void AFTL_GameModeBase::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}


bool AFTL_GameModeBase::GetIsInServer()
{
	bool IsInServer = false;
	if (GetNetMode() == NM_DedicatedServer || GetNetMode() == NM_ListenServer)
	{
		IsInServer = true;
	}
	else
	{
		IsInServer = false;

	}
	return IsInServer;
}


UFTL_GameInstance* AFTL_GameModeBase::GetGameInstance()
{

	if (this->GameInstance == nullptr)
	{
		this->GameInstance = Cast<UFTL_GameInstance>(UGameplayStatics::GetGameInstance(GetWorld()));
	}
	return this->GameInstance;
}


void AFTL_GameModeBase::PostLogin(APlayerController* NewPlayer)
{
	Super::PostLogin(NewPlayer);
	

}



void AFTL_GameModeBase::Logout(AController* Exiting)
{
	Super::Logout(Exiting);

}