﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "GameMode/GameLobbyGameMode.h"


#include "GameInstance/FTL_GameInstance.h"

#include "Kismet/GameplayStatics.h"

#include "Manager/WidgetManager.h"

#include "Manager/GameSettingsManager.h"
#include "Manager/GameSessionManager.h"

#include "Manager/DelegateManager.h"
#include "Widget/BackGroundWidget.h"
#include "PlayerController/GameLobbyLevelPlayerController.h"

#include "GameState/FTL_GameStateBase.h"
#include "PlayerState/FTL_PlayerStateBase.h"


AGameLobbyGameMode::AGameLobbyGameMode()
{



}


void AGameLobbyGameMode::BeginPlay()
{
	Super::BeginPlay();

}

void AGameLobbyGameMode::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}


void AGameLobbyGameMode::PostLogin(APlayerController* NewPlayer)
{
	Super::PostLogin(NewPlayer);
	for (auto& Element : GameState->PlayerArray)
	{
		AGameLobbyLevelPlayerController* Controller = Cast<AGameLobbyLevelPlayerController>(Element->GetPlayerController());
		Controller->Client_SetGameLobbyPanelPlayerNumber(GameState->PlayerArray.Num());

	}

}


void AGameLobbyGameMode::Logout(AController* Exiting)
{
	Super::Logout(Exiting);
	GameState->RemovePlayerState(Exiting->PlayerState);
	for (auto& Element : GameState->PlayerArray)
	{
		AGameLobbyLevelPlayerController* ClientController = Cast<AGameLobbyLevelPlayerController>(Element->GetPlayerController());
		ClientController->Client_SetGameLobbyPanelPlayerNumber(GameState->PlayerArray.Num());


	}


}


int32 AGameLobbyGameMode::GetCurrentPlayerNumber()
{
	return GameState->PlayerArray.Num();
}