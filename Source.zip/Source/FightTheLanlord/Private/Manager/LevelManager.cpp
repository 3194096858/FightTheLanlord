﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "Manager/LevelManager.h"

#include "GameInstance/FTL_GameInstance.h"
ULevelManager::ULevelManager()
{

}

void ULevelManager::SetLevelSwitchSettings(const FString& LevelName, bool IsServer)
{
	this->SettingsData.LevelName = LevelName;
	this->SettingsData.IsServer = IsServer;
	this->SettingsData.IsSwitchByIP = false;
	this->SettingsData.HostIP = TEXT("None");

}



void ULevelManager::SetLevelSwitchSettings(const FString& HostIP)
{
	this->SettingsData.HostIP = HostIP;
	this->SettingsData.IsServer = false;
	this->SettingsData.IsSwitchByIP = true;
	this->SettingsData.LevelName = TEXT("None");
}



void ULevelManager::SetLevelSwitchSettings(const FLevelSwitchSettingsData& NewData)
{

	this->SettingsData = NewData;

}

void ULevelManager::SwitchLevel(UFTL_GameInstance* GameInstance)
{
	if (GameInstance == nullptr)
	{
		return;
	}
	if (this->SettingsData.IsSwitchByIP == true && this->SettingsData.HostIP != TEXT("None"))
	{
		GameInstance->GetFirstLocalPlayerController()->ClientTravel(this->SettingsData.HostIP, ETravelType::TRAVEL_Absolute);
		GEngine->AddOnScreenDebugMessage(-1, 11.f, FColor::Red, FString::Printf(TEXT("LevelManager : Switch Level By IP  !!!! ")));
		ResetLevelSwitchSettings();
		return;
	}
	if (this->SettingsData.LevelName == TEXT("None"))
	{
		GEngine->AddOnScreenDebugMessage(-1, 11.f, FColor::Red, FString::Printf(TEXT("LevelManager :  LevelName == None !!!! ")));

		return;
	}
	FString LevelPath = TEXT("/Game/Blueprint/Level/") + this->SettingsData.LevelName;
	if (this->SettingsData.IsServer == true)
	{
		GameInstance->GetWorld()->ServerTravel(LevelPath + TEXT("?Listen"));
		GEngine->AddOnScreenDebugMessage(-1, 11.f, FColor::Red, FString::Printf(TEXT("LevelManager : Server Travel , LevelName = %s !!!! "), *this->SettingsData.LevelName));

	}
	else
	{
		GameInstance->GetFirstLocalPlayerController()->ClientTravel(LevelPath, ETravelType::TRAVEL_Absolute);
		GEngine->AddOnScreenDebugMessage(-1, 11.f, FColor::Red, FString::Printf(TEXT("LevelManager : Client Travel , LevelName = %s !!!! "),*this->SettingsData.LevelName));

	}
	ResetLevelSwitchSettings();

}

void ULevelManager::ResetLevelSwitchSettings()
{
	this->SettingsData = FLevelSwitchSettingsData();

}