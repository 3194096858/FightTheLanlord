﻿

#include "Manager/FTL_AssetManager.h"
#include "Sound/SoundMix.h"

#include "Struct/CardInformation.h"
#include "Widget/WidgetBase.h"

UClass* UFTL_AssetManager::GetWidgetClass(const FString& WidgetName)
{ 
	TMap<FString, UClass*> WidgetClassMap = this->WidgetAsset.WidgetClassMap;
	if (WidgetClassMap.Find(WidgetName) == nullptr)
	{
		return nullptr;
	}
	return *WidgetClassMap.Find(WidgetName);
}

UBehaviorTree* UFTL_AssetManager::GetAIPlayerBehaviorTree()
{

	return this->AIPlayerBehaviorTree;
}



TArray<FString> UFTL_AssetManager::GetAllWidgetName()
{
	TArray<FString> Array;

	this->WidgetAsset.WidgetClassMap.GenerateKeyArray(Array);

	return Array;
}



UDataTable* UFTL_AssetManager::GetCardInformationTable()
{

	return this->CardLibraryAsset.CardInformationTable;
}


UTexture2D* UFTL_AssetManager::GetCardImage( const FName& Name, ECardSuit Suit)
{
	TArray<FCardInformation*> Array;
	if (this->CardLibraryAsset.CardInformationTable != nullptr)
	{
		this->CardLibraryAsset.CardInformationTable->GetAllRows<FCardInformation>(TEXT(""), Array);
	}
	if (Array.Num() == 0)
	{
		return nullptr;
	}

	for (auto& Element : Array)
	{
		if (Element->Name == Name && Element->Suit == Suit)
		{
			return Element->Image;
		}
	}
	return nullptr;

}


USoundBase* UFTL_AssetManager::GetHandTypeSFX(EHandType HandType, int32 Value)
{
	TArray<FHandTypeInformation*> Array;
	if (this->HandTypeInformationTable != nullptr)
	{
		this->HandTypeInformationTable->GetAllRows<FHandTypeInformation>(TEXT(""), Array);
	}
	for (auto& Element : Array)
	{
		if (Element->HandType == EHandType::Single || Element->HandType == EHandType::Pair || Element->HandType == EHandType::Triple)
		{
			if (Element->HandType == HandType && Element->Value == Value)
			{
				return Element->SFX;
			}
		}
		if (Element->HandType == HandType && HandType == EHandType::Airplane)
		{
			return Element->SFX;
		}
		if (Element->HandType == HandType && HandType == EHandType::Bomb)
		{
			return Element->SFX;
		}
		if (Element->HandType == HandType && HandType == EHandType::SingleStraight)
		{
			return Element->SFX;
		}
		if (Element->HandType == HandType && HandType == EHandType::PairStraight)
		{
			return Element->SFX;
		}
		if (Element->HandType == HandType && HandType == EHandType::JokerBomb)
		{
			return Element->SFX;
		}
		if (Element->HandType == HandType && HandType == EHandType::TripletWithKicker)
		{
			return Element->SFX;
		}
		if (Element->HandType == HandType && HandType == EHandType::AirplaneWithWing)
		{
			return Element->SFX;
		}
		if (Element->HandType == HandType && HandType == EHandType::FourWithTwo)
		{
			return Element->SFX;
		}
	}
	return nullptr;
}


USoundBase* UFTL_AssetManager::GetBGM(const FString& BGMName)
{
	if (this->BGMMap.Find(BGMName) == nullptr)
	{
		return nullptr;
	}
	return *this->BGMMap.Find(BGMName);
}


TArray<FString> UFTL_AssetManager::GetAllBGMName()
{
	TArray<FString> Array;
	this->BGMMap.GenerateKeyArray(Array);


	return Array;
}



USoundBase* UFTL_AssetManager::GetSFX(const FString& SFXName)
{
	if (this->SFXMap.Find(SFXName) == nullptr)
	{
		return nullptr;
	}
	return *this->SFXMap.Find(SFXName);
}

TArray<FString> UFTL_AssetManager::GetAllSFXName()
{
	TArray<FString> Array;
	this->SFXMap.GenerateKeyArray(Array);

	return Array;
}


USoundMix* UFTL_AssetManager::GetSoundMix()
{
	return this->SoundMix;

}


USoundClass* UFTL_AssetManager::GetBGMSoundClass()
{
	return this->BGMSoundClass;

}

USoundClass* UFTL_AssetManager::GetSFXSoundClass()
{
	return this->SFXSoundClass;

}