﻿

#include "Manager/WidgetManager.h"

#include "GameMode/FTL_GameModeBase.h"
#include "GameInstance/FTL_GameInstance.h"
#include "Widget/StartMenu.h"
#include "Widget/BackGroundWidget.h"
#include "Widget/UserTipWidget.h"
#include "Widget/HUDWidget.h"
#include "Widget/ButtonWidget.h"
#include "Widget/TextBlockWidget.h"
#include "Widget/ComboBoxWidget.h"
#include "Widget/ComboBoxMenuWidget.h"
#include "Widget/ComboBoxItemWidget.h"
#include "Widget/EditableTextBoxWidget.h"
#include "Widget/SessionWidget.h"
#include "Widget/WidgetBase.h"
#include "Widget/GameMainPage.h"
#include "Widget/PlayerWidget.h"
#include "Widget/GameSettingsOptionWidget.h"
#include "Widget/GameSettingsPanel.h"
#include "Manager/DelegateManager.h"
#include "Widget/WarningPanel.h"
#include "Widget/OperationPanel.h"
#include "Widget/GameSessionPanel.h"
#include "Widget/ResourcePanel.h"
#include "Widget/GameLobbyPanel.h"
#include "Widget/PlayerPanel.h"
#include "Widget/CardTableWidget.h"
#include "Manager/FTL_AssetManager.h"
#include "GameState/FTL_GameStateBase.h"
#include "PlayerController/PlayerControllerBase.h"
#include "Widget/CardWidget.h"
#include "Kismet/GameplayStatics.h"
#include "Widget/ResultPanel.h"
#include "Widget/HoleCardPanel.h"
#include "Widget/TipWidgetBase.h"
#include "Widget/MessagePanel.h"

#include "Widget/MessageWidget.h"

UWidgetManager::UWidgetManager()
{
	TArray<UWidgetBase*> ActiveWidgetArray;
	this->ActiveWidgetMap.Add(EWidgetRenderingLevel::BackGround, ActiveWidgetArray);
	this->ActiveWidgetMap.Add(EWidgetRenderingLevel::HUD, ActiveWidgetArray);
	this->ActiveWidgetMap.Add(EWidgetRenderingLevel::UserTip, ActiveWidgetArray);
	this->WarningPanelDecriptionMap.Add(TEXT("QuitGame"),TEXT("确定退出游戏？"));
	this->WarningPanelDecriptionMap.Add(TEXT("ResetSettings"), TEXT("确定重置所有设置？"));
	this->WarningPanelDecriptionMap.Add(TEXT("DestroySession"), TEXT("确定删除该房间？"));
	this->WarningPanelDecriptionMap.Add(TEXT("JoinSession"), TEXT("确定进入该房间？"));
	this->WarningPanelDecriptionMap.Add(TEXT("QuitSession"), TEXT("确定退出该房间？"));

}



void UWidgetManager::InitializeWidget(UFTL_GameInstance* GameInstance)
{
	if (GameInstance == nullptr)
	{
		return;
	}
	UWidgetBase* Widget = nullptr;
	UClass* WidgetClass = nullptr;
	for (auto& Element : GameInstance->GetAssetManager()->GetAllWidgetName())
	{
		WidgetClass = GameInstance->GetAssetManager()->GetWidgetClass(Element);
		Widget = CreateWidget<UWidgetBase>(GameInstance, WidgetClass);
		this->WidgetMap.Add(Element,Widget);

	}
	InitializeGameScreen();




}



void UWidgetManager::InitializeEditableTextBox(UEditableTextBoxWidget* EditableTextBox, FEditableTextBoxWidgetData Data, FEditableTextBoxWidgetAsset Asset)
{
	if (EditableTextBox == nullptr)
	{
		return;
	}
	EditableTextBox->SetBackGroundImage(Asset.BackGroundImage.Image);
	EditableTextBox->SetBackGroundImageColor(Data.BackGroundImage.Color);
	EditableTextBox->SetFontColor(Data.TextBlock.FontColor);
	EditableTextBox->SetFontSize(Data.TextBlock.FontSize);

	EditableTextBox->SetWidgetSize(Data.Size);
	EditableTextBox->SetRelativePosition(Data.RelativePosition);
	EditableTextBox->SetHintText(Data.HintText.ToString());


}


void UWidgetManager::InitializeTextBlock(UTextBlockWidget* TextBlock, FTextBlockWidgetData Data, FTextBlockWidgetAsset Asset)
{
	if (TextBlock == nullptr)
	{
		return;
	}
	TextBlock->SetBackGroundImage(Asset.BackGroundImage.Image);
	TextBlock->SetFontColor(Data.FontColor);
	TextBlock->SetFontSize(Data.FontSize);
	TextBlock->SetTextVisibility(Data.IsShowText == true ? ESlateVisibility::HitTestInvisible : ESlateVisibility::Collapsed);
	TextBlock->SetBackGroundImageVisibility(Data.BackGroundImage.IsShowImage == true ? ESlateVisibility::HitTestInvisible : ESlateVisibility::Collapsed);
	TextBlock->SetWidgetSize(Data.Size);
	TextBlock->SetBackGroundImageColor(Data.BackGroundImage.Color);
	TextBlock->SetRelativePosition(Data.RelativePosition);
	TextBlock->SetText(Data.Text);
	TextBlock->SetTextRelativePosition(Data.TextRelativePosition);

}


void UWidgetManager::InitializeButton(UButtonWidget* Button, FButtonWidgetData Data, FButtonWidgetAsset Asset)
{
	if (Button == nullptr)
	{
		return;
	}
	Button->SetIconImage(Asset.Icon.Image);
	Button->SetBackGroundImage(Asset.BackGroundImage.Image);
	Button->SetText(Data.TextBlock.Text);
	Button->SetTextRelativePosition(Data.TextBlock.RelativePosition);
	Button->SetFontColor(Data.TextBlock.FontColor);
	Button->SetFontSize(Data.TextBlock.FontSize);
	Button->SetBackGroundImageVisibility(Data.BackGroundImage.IsShowImage == true ? ESlateVisibility::HitTestInvisible : ESlateVisibility::Collapsed);
	Button->SetIconVisibility(Data.Icon.IsShowImage == true ? ESlateVisibility::HitTestInvisible : ESlateVisibility::Collapsed);
	Button->SetTextBlockVisibility(Data.TextBlock.IsShowText == true ? ESlateVisibility::HitTestInvisible : ESlateVisibility::Collapsed);
	Button->SetIconSize(Data.Icon.Size);
	Button->SetIconColor(Data.Icon.Color);
	Button->SetBackGroundImageColor(Data.BackGroundImage.Color);
	Button->SetWidgetSize(Data.Size);
	Button->SetIconRelativePosition(Data.Icon.RelativePosition);
	Button->SetRelativePosition(Data.RelativePosition);
}

void UWidgetManager::InitializeComboBox(UComboBoxWidget* ComboBox, FComboBoxWidgetData Data, FComboBoxWidgetAsset Asset)
{
	if (ComboBox == nullptr)
	{
		return;
	}
	ComboBox->SetDownArrowVisibility(ESlateVisibility::HitTestInvisible);
	ComboBox->SetButtonBackGroundImage(Asset.Button.BackGroundImage.Image);
	ComboBox->SetDownArrowImage(Asset.Button.Icon.Image);
    ComboBox->SetDownArrowRelativePosition(Data.Button.Icon.RelativePosition);
	ComboBox->SetDownArrowImageColor(Data.Button.Icon.Color);
	ComboBox->SetDownArrowSize(Data.Button.Icon.Size);
	ComboBox->SetButtonTextRelativePosition(Data.Button.TextBlock.RelativePosition);
	ComboBox->SetButtonFontColor(Data.Button.TextBlock.FontColor);
	ComboBox->SetButtonFontSize(Data.Button.TextBlock.FontSize);
	ComboBox->SetButtonRelativePosition(Data.Button.RelativePosition);
	ComboBox->SetWidgetSize(Data.Button.Size);
	ComboBox->SetButtonBackGroundImageColor(Data.Button.BackGroundImage.Color);
	ComboBox->SetRelativePosition(Data.RelativePosition);



}

void UWidgetManager::InitializeGameSettingsOption(UGameSettingsOptionWidget* GameSettingsOptionWidget, FGameSettingsOptionWidgetData Data, FGameSettingsOptionWidgetAsset Asset)
{
	if (GameSettingsOptionWidget == nullptr)
	{
		return;
	}
	GameSettingsOptionWidget->SetOptionType(Data.OptionType);
	GameSettingsOptionWidget->SetWidgetSize(Data.Size);
	GameSettingsOptionWidget->SetRelativePosition(Data.RelativePosition);
	GameSettingsOptionWidget->SetFontColor(Data.TextBlock.FontColor);
	GameSettingsOptionWidget->SetFontSize(Data.TextBlock.FontSize);
	GameSettingsOptionWidget->SetTextRelativePosition(Data.TextBlock.RelativePosition);
	GameSettingsOptionWidget->SetBackGroundImage(Asset.BackGroundImage.Image);
	GameSettingsOptionWidget->SetBackGroundImage(Asset.BackGroundImage.Image);
	GameSettingsOptionWidget->SetBackGroundImageColor(Data.BackGroundImage.Color);
	GameSettingsOptionWidget->SetText(Data.TextBlock.Text);

	GameSettingsOptionWidget->SetBackGroundImageVisibility(Data.BackGroundImage.IsShowImage == true ? ESlateVisibility::HitTestInvisible : ESlateVisibility::Collapsed);
	switch (Data.OptionType)
	{
		case EGameSettingsOptionType::ComboBox:
			GameSettingsOptionWidget->HideComboBoxMenuScrollBar();
			GameSettingsOptionWidget->SetComboBoxSize(Data.ComboBox.Size);
			GameSettingsOptionWidget->SetComboBoxRelativePosition(Data.ComboBox.RelativePosition);
			GameSettingsOptionWidget->SetComboBoxButtonText(Data.TextBlock.Text.ToString());
			GameSettingsOptionWidget->SetComboBoxFontColor(Data.ComboBox.Button.TextBlock.FontColor, Data.ComboBox.ItemButton.TextBlock.FontColor);
			GameSettingsOptionWidget->SetComboBoxFontSize(Data.ComboBox.Button.TextBlock.FontSize, Data.ComboBox.ItemButton.TextBlock.FontSize);
			GameSettingsOptionWidget->SetComboBoxDownArrowRelativePosition(Data.ComboBox.Button.Icon.RelativePosition);
			GameSettingsOptionWidget->SetComboBoxDownArrowImage(Asset.ComboBox.Button.Icon.Image);
			GameSettingsOptionWidget->SetComboBoxDownArrowImageColor(Data.ComboBox.Button.Icon.Color);
			GameSettingsOptionWidget->SetComboBoxDownArrowSize(Data.ComboBox.Button.Icon.Size);
			GameSettingsOptionWidget->SetComboBoxButtonTextRelativePosition(Data.ComboBox.Button.TextBlock.RelativePosition);
			GameSettingsOptionWidget->SetComboBoxButtonBackGroundImageColor(Data.ComboBox.Button.BackGroundImage.Color);
			GameSettingsOptionWidget->SetComboBoxButtonBackGroundImage(Asset.ComboBox.Button.BackGroundImage.Image);
			GameSettingsOptionWidget->SetComboBoxMenuRelativePosition(Data.ComboBox.Menu.RelativePosition);
			GameSettingsOptionWidget->SetComboBoxMenuBackGroundImageColor(Data.ComboBox.Menu.Color);
			GameSettingsOptionWidget->SetComboBoxMenuSize(Data.ComboBox.Menu.Size);
			GameSettingsOptionWidget->SetComboBoxItemBackGroundImageColor(Data.ComboBox.ItemButton.BackGroundImage.Color);
			GameSettingsOptionWidget->SetComboBoxItemBackGroundImage(Asset.ComboBox.ItemButton.BackGroundImage.Image);
			GameSettingsOptionWidget->SetComboBoxItemBackGroundImageVisibility(Data.ComboBox.ItemButton.BackGroundImage.IsShowImage == true ? ESlateVisibility::HitTestInvisible : ESlateVisibility::Collapsed);
			GameSettingsOptionWidget->SetComboBoxItemSize(Data.ComboBox.ItemButton.Size);
			break;
		case EGameSettingsOptionType::CheckBox:
			break;
		case EGameSettingsOptionType::Slider:
			GameSettingsOptionWidget->SetSliderSize(Data.Slider.Size);
			GameSettingsOptionWidget->SetSliderRelativePosition(Data.Slider.RelativePosition);
			GameSettingsOptionWidget->SetSliderBackGroundImage(Asset.Slider.BackGroundImage.Image);
			GameSettingsOptionWidget->SetSliderBarImage(Asset.Slider.BarImage.Image);
			GameSettingsOptionWidget->SetSliderHandleImage(Asset.Slider.HandleImage.Image);
			GameSettingsOptionWidget->SetSliderBackGroundImageColor(Data.Slider.BackGroundImage.Color);
			GameSettingsOptionWidget->SetSliderBackGroundImageVisibility(Data.Slider.BackGroundImage.IsShowImage == true ? ESlateVisibility::HitTestInvisible : ESlateVisibility::Collapsed);
			GameSettingsOptionWidget->SetSliderBarColor(Data.Slider.BarImage.Color);
			GameSettingsOptionWidget->SetSliderHandleColor(Data.Slider.HandleImage.Color);
			GameSettingsOptionWidget->SetSliderBarThickness(Data.Slider.BarThickness);
			GameSettingsOptionWidget->SetSliderText(Data.Slider.TextBlock.Text.ToString());
			GameSettingsOptionWidget->SetSliderTextBlockVisibility(Data.Slider.TextBlock.IsShowText == true? ESlateVisibility::HitTestInvisible : ESlateVisibility::Collapsed);
			GameSettingsOptionWidget->SetSliderFontSize(Data.Slider.TextBlock.FontSize);
			GameSettingsOptionWidget->SetSliderFontColor(Data.Slider.TextBlock.FontColor);
			GameSettingsOptionWidget->SetSliderStepSize(Data.Slider.StepSize);
			GameSettingsOptionWidget->SetSliderHandleSize(Data.Slider.HandleImage.Size);
			GameSettingsOptionWidget->SetSliderTextBlockRelativePosition(Data.Slider.TextBlock.RelativePosition);


			break;
	}

}


UWidgetBase* UWidgetManager::GetWidget(const FString& WidgetName)
{
	if (this->WidgetMap.Find(WidgetName) == nullptr)
	{
		return nullptr;
	}
	return *this->WidgetMap.Find(WidgetName);
}

UBackGroundWidget* UWidgetManager::GetBackGroundWidget()
{
	return Cast<UBackGroundWidget>(GetWidget(TEXT("BackGroundWidget")));

}

UHUDWidget* UWidgetManager::GetHUDWidget()
{
	return Cast<UHUDWidget>(GetWidget(TEXT("HUDWidget")));

}

UUserTipWidget* UWidgetManager::GetUserTipWidget()
{
	return Cast<UUserTipWidget>(GetWidget(TEXT("UserTipWidget")));

}
UHoleCardPanel* UWidgetManager::GetHoleCardPanel()
{
	return Cast<UHoleCardPanel>(GetWidget(TEXT("HoleCardPanel")));

}
UPlayerPanel* UWidgetManager::GetPlayerPanel()
{
	return Cast<UPlayerPanel>(GetWidget(TEXT("PlayerPanel")));

}
UOperationPanel* UWidgetManager::GetOperationPanel()
{
	return Cast<UOperationPanel>(GetWidget(TEXT("OperationPanel")));

}
UGameSessionPanel* UWidgetManager::GetGameSessionPanel()
{
	return Cast<UGameSessionPanel>(GetWidget(TEXT("GameSessionPanel")));

}
UGameSettingsPanel* UWidgetManager::GetGameSettingPanel()
{
	return Cast<UGameSettingsPanel>(GetWidget(TEXT("GameSettingsPanel")));

}
UStartMenu* UWidgetManager::GetStartMenu()
{
	return Cast<UStartMenu>(GetWidget(TEXT("StartMenu")));

}
UGameMainPage* UWidgetManager::GetGameMainPage()
{
	return Cast<UGameMainPage>(GetWidget(TEXT("GameMainPage")));

}
UResultPanel* UWidgetManager::GetResultPanel()
{
	return Cast<UResultPanel>(GetWidget(TEXT("ResultPanel")));

}
UGameLobbyPanel* UWidgetManager::GetGameLobbyPanel()
{
	return Cast<UGameLobbyPanel>(GetWidget(TEXT("GameLobbyPanel")));

}

UCardTableWidget* UWidgetManager::GetCardTableWidget()
{
	return Cast<UCardTableWidget>(GetWidget(TEXT("CardTableWidget")));

}

UMessagePanel* UWidgetManager::GetMessagePanel()
{
	return Cast<UMessagePanel>(GetWidget(TEXT("MessagePanel")));

}
void UWidgetManager::AddCardToHoleCardPanel(const TArray<FCardInformation>& CardArray)
{
	GetHoleCardPanel()->AddCard(CardArray);

}

void UWidgetManager::PlayLoadingAnimation(bool IsForward)
{
	GetUserTipWidget()->PlayLoadingAnimation(IsForward);

}


void UWidgetManager::AddMessage(UMessageWidget* MessageWidget, int32 PlayerID, const FString& Message)
{
	if (MessageWidget == nullptr)
	{
		return;
	}
	GetMessagePanel()->AddMessage(MessageWidget);
	MessageWidget->SetMessage(PlayerID,Message);


}

void UWidgetManager::AddCardToCardTable(const TArray<FCardInformation>& CardArray)
{
	GetCardTableWidget()->AddCard(CardArray);

}

void UWidgetManager::ClearCardTable()
{
	GetCardTableWidget()->Clear();

}
UTipWidgetBase* UWidgetManager::GetTipWidget(UFTL_GameInstance* GameInstance)
{
	if (GameInstance == nullptr)
	{
		return nullptr;
	}
	UTipWidgetBase* TipWidget = nullptr;
	if (this->TipWidgetArray.Num() == 0)
	{
		FString WidgetName = TEXT("TipWidgetBase");
		UClass* WidgetClass = nullptr;
		WidgetClass = GameInstance->GetAssetManager()->GetWidgetClass(WidgetName);
		TipWidget = SpawnWidget<UTipWidgetBase>(WidgetClass);
		return TipWidget;
	}
	TipWidget = this->TipWidgetArray[0];
	this->TipWidgetArray.RemoveAt(0);
	return TipWidget;
}
void UWidgetManager::ReturnTipWidget(UTipWidgetBase* TipWidget)
{
	if (this->TipWidgetArray.Contains(TipWidget) == false)
	{
		this->TipWidgetArray.Add(TipWidget);

	}
}
void UWidgetManager::AddTipWidgetToViewport(UTipWidgetBase* TipWidget)
{
}
TArray<FCardInformation> UWidgetManager::GetAllSelectedCardInformationFromCardHand()
{
	TArray<FCardInformation> InformationArray;
	TArray<UCardWidget*> WidgetArray = GetOperationPanel()->GetAllCardFromCardHand();
	for (auto& Element : WidgetArray)
	{
		if (Element->GetIsSelected() == true)
		{
			InformationArray.Add(Element->GetCardInformation());
		}

	}

	return InformationArray;
}

TArray<UCardWidget*> UWidgetManager::GetAllSelectedCardWidgetFromCardHand()
{
	TArray<UCardWidget*> Array;
	for (auto& Element : GetOperationPanel()->GetAllCardFromCardHand())
	{
		if (Element->GetIsSelected() == true)
		{
			Array.Add(Element);
		}

	}
	return Array;
}


void UWidgetManager::PlayDealCardAnimation()
{
	GetOperationPanel()->PlayDealCardAnimation();



}

void UWidgetManager::SetCountdownTimerText(int32 CurrentSecond)
{
	GetOperationPanel()->SetCountdownTimerText(CurrentSecond);

}



void UWidgetManager::ShowCountdownTimer()
{
	GetOperationPanel()->ShowCountdownTimer();
}
void UWidgetManager::HideCountdownTimer()
{
	GetOperationPanel()->HideCountdownTimer();

}
void UWidgetManager::SetActiveCardInformation(UCardWidget* Widget, const FCardInformation& Information)
{
	if (this->ActiveCardInformationMap.Find(Widget) == nullptr)
	{
		return;
	}
	this->ActiveCardInformationMap.Add(Widget, Information);

}


TArray<FCardInformation> UWidgetManager::GetAllActiveCardInformation()
{
	TArray<FCardInformation> Array;
	////this->ActiveCardInformationMap.GenerateValueArray(Array);

	for (auto& Element : this->ActiveCardInformationMap)
	{
		Array.Add(Element.Value);
	}


	return Array;


}


FCardInformation UWidgetManager::GetActiveCardInformation(UCardWidget* ActiveCard)
{


	FCardInformation* Information = this->ActiveCardInformationMap.Find(ActiveCard);
	if (Information == nullptr)
	{
		return FCardInformation();
	}
	return *Information;


}


TArray<UCardWidget*> UWidgetManager::GetAllCardFromCardHand()
{
	return GetOperationPanel()->GetAllCardFromCardHand();
}

void UWidgetManager::AddCardToCardHand(const FCardInformation& Information, UCardWidget* Widget)
{
	if (Widget == nullptr)
	{
		return;
	}
	if (this->ActiveCardInformationMap.Find(Widget) != nullptr)
	{
		return;
	}

	GetOperationPanel()->AddCardToCardHand(Widget);
	this->ActiveCardInformationMap.Add(Widget, Information);


}

void UWidgetManager::RemoveCardFromCardHand(UCardWidget* Card)
{

	GetOperationPanel()->RemoveCardFromCardHand(Card);
	this->ActiveCardInformationMap.Remove(Card);
}

void UWidgetManager::RemoveAllCardFromCardHand()
{
	GetOperationPanel()->RemoveAllCardFromCardHand();
	this->ActiveCardInformationMap.Empty();
}

UMessageWidget* UWidgetManager::GetMessageWidget(UFTL_GameInstance* GameInstance)
{
	if (GameInstance == nullptr)
	{
		return nullptr;
	}
	UMessageWidget* MessageWidget = nullptr;
	if (this->MessageWidgetArray.Num() == 0)
	{
		FString WidgetName = TEXT("MessageWidget");
		UClass* WidgetClass = nullptr;
		WidgetClass = GameInstance->GetAssetManager()->GetWidgetClass(WidgetName);
		MessageWidget = SpawnWidget<UMessageWidget>(WidgetClass);
		return MessageWidget;
	}
	MessageWidget = this->MessageWidgetArray[0];
	this->MessageWidgetArray.RemoveAt(0);
	return MessageWidget;
}

void UWidgetManager::ReturnMessageWidget(UMessageWidget* MessageWidget)
{
	if (this->MessageWidgetArray.Contains(MessageWidget) == false)
	{
		MessageWidget->SetVisibility(ESlateVisibility::Visible);
		this->MessageWidgetArray.Add(MessageWidget);

	}

}
UCardWidget* UWidgetManager::GetCardWidget(UFTL_GameInstance* GameInstance)
{
	if (GameInstance == nullptr)
	{
		return nullptr;
	}
	UCardWidget* CardWidget = nullptr;
	if (this->CardWidgetArray.Num() == 0)
	{
		FString WidgetName = TEXT("CardWidget");
		UClass* WidgetClass = nullptr;
		WidgetClass = GameInstance->GetAssetManager()->GetWidgetClass(WidgetName);
		CardWidget = SpawnWidget<UCardWidget>(WidgetClass);
		return CardWidget;
	}
	CardWidget = this->CardWidgetArray[0];
	this->CardWidgetArray.RemoveAt(0);
	return CardWidget;
}

void UWidgetManager::ReturnCardWidget(UCardWidget* CardWidget)
{
	if (this->CardWidgetArray.Contains(CardWidget) == false)
	{
		CardWidget->SetVisibility(ESlateVisibility::Visible);
		CardWidget->SetIsSelected(false);
		CardWidget->SetRelativePosition(FVector2D::ZeroVector);
		this->CardWidgetArray.Add(CardWidget);

	}

}
void UWidgetManager::UpdatePlayerCardNumber(int32 PlayerID, int32 NewValue)
{
	GetPlayerPanel()->SetPlayerCardNumber(PlayerID,NewValue);
}

void UWidgetManager::InitializPlayerID(int32 LocalPlayerID)
{
	GetPlayerPanel()->InitializePlayerID(LocalPlayerID);


}


void UWidgetManager::SetGameLobbyPlayerNumber(int32 CurrentNumber)
{
	GetGameLobbyPanel()->SetCurrentPlayerNumber(CurrentNumber);
}



USessionWidget* UWidgetManager::GetSessionWidget(UFTL_GameInstance* GameInstance)
{
	USessionWidget* SessionWidget = nullptr;
	if (this->SessionWidgetArray.Num() == 0)
	{
		FString WidgetName = TEXT("SessionWidget");
		UClass* WidgetClass = nullptr;
		WidgetClass = GameInstance->GetAssetManager()->GetWidgetClass(WidgetName);
		SessionWidget = SpawnWidget<USessionWidget>(WidgetClass);
		return SessionWidget;
	}
	SessionWidget = this->SessionWidgetArray[0];
	this->SessionWidgetArray.RemoveAt(0);
	return SessionWidget;
}

void UWidgetManager::ReturnSessionWidget(USessionWidget* SessionWidget)
{
	if (this->SessionWidgetArray.Contains(SessionWidget) == false)
	{
		this->SessionWidgetArray.Add(SessionWidget);

	}
	
}

void UWidgetManager::DestroyAllSessionWidget()
{
	if (this->SessionWidgetArray.Num() != 0)
	{
		for (auto& Element : this->SessionWidgetArray)
		{
			Element->RemoveFromScrollBox();
		}
		this->SessionWidgetArray.Empty();
	}

}

void UWidgetManager::DestroyAllCardWidget()
{
	if (this->CardWidgetArray.Num() != 0)
	{
		
		this->CardWidgetArray.Empty();
	}

}


TArray<UWidgetBase*> UWidgetManager::GetAllActiveWidgetFromViewport(EWidgetRenderingLevel RenderingLevel)
{
	TArray<UWidgetBase*>* Array;

	Array = this->ActiveWidgetMap.Find(RenderingLevel);
	if (Array!=nullptr)
	{
		return *Array;
	}

	return TArray<UWidgetBase*>{};
}


void UWidgetManager::AddWidgetToViewport(EWidgetRenderingLevel RenderingLevel, UWidgetBase* Widget, const FVector2D& Size, const FAnchorData& AnchorData)
{
	if (Widget == nullptr)
	{
		return;
	}

	TArray<UWidgetBase*> ActiveWidgetArray;
	int32 ZOrder = 0;
	switch (RenderingLevel)
	{
	case EWidgetRenderingLevel::BackGround:
		GetBackGroundWidget()->AddWidgetToCanvasPanel(Widget, Size, AnchorData);
		ActiveWidgetArray = *this->ActiveWidgetMap.Find(EWidgetRenderingLevel::BackGround);
		break;
	case EWidgetRenderingLevel::HUD:
		GetHUDWidget()->AddWidgetToCanvasPanel(Widget, Size, AnchorData);
		ActiveWidgetArray = *this->ActiveWidgetMap.Find(EWidgetRenderingLevel::HUD);
		OnWidgetAddToHUD(ActiveWidgetArray);
		break;
	case EWidgetRenderingLevel::UserTip:
		GetUserTipWidget()->AddWidgetToCanvasPanel(Widget, Size, AnchorData);
		ActiveWidgetArray = *this->ActiveWidgetMap.Find(EWidgetRenderingLevel::UserTip);
		break;
	}

	ZOrder = ActiveWidgetArray.Num();
	Widget->Open(ZOrder);
	/*for (auto& Element : ActiveWidgetArray)
	{
		GEngine->AddOnScreenDebugMessage(-1, 12.0f, FColor::Blue, FString::Printf(TEXT(" Name = %s "), *Element->GetName()));

	}*/


}



void UWidgetManager::RemoveWidgetFromViewport(EWidgetRenderingLevel RenderingLevel, UWidgetBase* Widget)
{
	TArray<UWidgetBase*> ActiveWidgetArray;
	if (this->ActiveWidgetMap.Find(RenderingLevel) == nullptr)
	{
		return;
	}
	ActiveWidgetArray = *this->ActiveWidgetMap.Find(RenderingLevel);
	if (ActiveWidgetArray.Contains(Widget) == true)
	{
		Widget->Close();
		ActiveWidgetArray.Remove(Widget);
		this->ActiveWidgetMap.Add(RenderingLevel, ActiveWidgetArray);
		RenderingLevel == EWidgetRenderingLevel::HUD ? OnWidgetRemoveFromHUD(ActiveWidgetArray) : void();
	}
	/*if (Widget == this->CardTableWidget)
	{
		GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, TEXT("WidgetManager: Remove  CardTableWidget"));
	}
	else
	{
		GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, TEXT("000000000000000"));

	}*/
}


void UWidgetManager::RemoveTopWidgetFromViewport(EWidgetRenderingLevel RenderingLevel)
{
	TArray<UWidgetBase*> ActiveWidgetArray;
	int32 TopIndex = 0;

	if (this->ActiveWidgetMap.Find(RenderingLevel) == nullptr)
	{
		return;
	}
	ActiveWidgetArray = *this->ActiveWidgetMap.Find(RenderingLevel);
	if (ActiveWidgetArray.Num() != 0)
	{
		TopIndex = ActiveWidgetArray.Num() - 1;
		ActiveWidgetArray[TopIndex]->Close();
		ActiveWidgetArray.RemoveAt(TopIndex);
		this->ActiveWidgetMap.Add(RenderingLevel, ActiveWidgetArray);
		RenderingLevel == EWidgetRenderingLevel::HUD ? OnWidgetRemoveFromHUD(ActiveWidgetArray) : void();

	}



}

void UWidgetManager::RemoveAllWidgetFromViewport(EWidgetRenderingLevel RenderingLevel)
{
	TArray<UWidgetBase*> ActiveWidgetArray;
	if (this->ActiveWidgetMap.Find(RenderingLevel) == nullptr)
	{
		return;
	}
	ActiveWidgetArray = *this->ActiveWidgetMap.Find(RenderingLevel);
	for (auto& Element : ActiveWidgetArray)
	{
		Element->Close();
	}
	if (ActiveWidgetArray.Num() != 0)
	{
		ActiveWidgetArray.Empty();
	}
	this->ActiveWidgetMap.Add(RenderingLevel, ActiveWidgetArray);


}

void UWidgetManager::InitializeGameScreen()
{
	GetBackGroundWidget()->AddToViewport(-100);
	GetHUDWidget()->AddToViewport();
	GetUserTipWidget()->AddToViewport(100);

}



FName UWidgetManager::GetWarningName(const FString& Description)
{
	const FName* WarningName;
	WarningName = this->WarningPanelDecriptionMap.FindKey(Description);
	if (WarningName != nullptr)
	{
		return *WarningName;
	}

	return TEXT("");
}


void UWidgetManager::OpenMessagePanel(const FVector2D& Size, const FAnchorData& AnchorData)
{
	TArray<UWidgetBase*> ActiveWidgetArray;
	EWidgetRenderingLevel RenderingLevel = EWidgetRenderingLevel::HUD;
	UWidgetBase* Widget = GetWidget(TEXT("MessagePanel"));
	if (this->ActiveWidgetMap.Find(RenderingLevel) == nullptr || Widget == nullptr)
	{
		return;
	}

	ActiveWidgetArray = *this->ActiveWidgetMap.Find(RenderingLevel);
	if (ActiveWidgetArray.Contains(Widget) == false)
	{
		ActiveWidgetArray.Add(Widget);
		this->ActiveWidgetMap.Add(RenderingLevel, ActiveWidgetArray);
		AddWidgetToViewport(RenderingLevel, Widget, Size, AnchorData);

	}

}


void UWidgetManager::CloseMessagePanel()
{

	EWidgetRenderingLevel RenderingLevel = EWidgetRenderingLevel::HUD;
	UWidgetBase* Widget = GetWidget(TEXT("MessagePanel"));

	RemoveWidgetFromViewport(RenderingLevel, Widget);


}

void UWidgetManager::OpenHoleCardPanel(const FVector2D& Size, const FAnchorData& AnchorData)
{
	TArray<UWidgetBase*> ActiveWidgetArray;
	EWidgetRenderingLevel RenderingLevel = EWidgetRenderingLevel::UserTip;
	UWidgetBase* Widget = GetWidget(TEXT("HoleCardPanel"));
	if (this->ActiveWidgetMap.Find(RenderingLevel) == nullptr || Widget == nullptr)
	{
		return;
	}

	ActiveWidgetArray = *this->ActiveWidgetMap.Find(RenderingLevel);
	if (ActiveWidgetArray.Contains(Widget) == false)
	{
		ActiveWidgetArray.Add(Widget);
		this->ActiveWidgetMap.Add(RenderingLevel, ActiveWidgetArray);
		AddWidgetToViewport(RenderingLevel, Widget, Size, AnchorData);

	}


}


void UWidgetManager::CloseHoleCardPanel()
{

	EWidgetRenderingLevel RenderingLevel = EWidgetRenderingLevel::UserTip;
	UWidgetBase* Widget = GetWidget(TEXT("HoleCardPanel"));

	RemoveWidgetFromViewport(RenderingLevel, Widget);


}

void UWidgetManager::OpenResultPanel(const FVector2D& Size, const FAnchorData& AnchorData)
{
	TArray<UWidgetBase*> ActiveWidgetArray;
	EWidgetRenderingLevel RenderingLevel = EWidgetRenderingLevel::HUD;
	UWidgetBase* Widget = GetWidget(TEXT("ResultPanel"));
	if (this->ActiveWidgetMap.Find(RenderingLevel) == nullptr || Widget == nullptr)
	{
		return;
	}

	ActiveWidgetArray = *this->ActiveWidgetMap.Find(RenderingLevel);
	if (ActiveWidgetArray.Contains(Widget) == false)
	{
		ActiveWidgetArray.Add(Widget);
		this->ActiveWidgetMap.Add(RenderingLevel, ActiveWidgetArray);
		AddWidgetToViewport(RenderingLevel, Widget, Size, AnchorData);

	}

}


void UWidgetManager::CloseResultPanel()
{

	EWidgetRenderingLevel RenderingLevel = EWidgetRenderingLevel::HUD;
	UWidgetBase* Widget = GetWidget(TEXT("ResultPanel"));

	RemoveWidgetFromViewport(RenderingLevel, Widget);


}

void UWidgetManager::OpenCardTableWidget(const FVector2D& Size, const FAnchorData& AnchorData)
{
	TArray<UWidgetBase*> ActiveWidgetArray;
	EWidgetRenderingLevel RenderingLevel = EWidgetRenderingLevel::UserTip;
	UWidgetBase* Widget = GetWidget(TEXT("CardTableWidget"));
	if (this->ActiveWidgetMap.Find(RenderingLevel) == nullptr || Widget == nullptr)
	{
		return;
	}

	ActiveWidgetArray = *this->ActiveWidgetMap.Find(RenderingLevel);
	if (ActiveWidgetArray.Contains(Widget) == false)
	{
		ActiveWidgetArray.Add(Widget);
		this->ActiveWidgetMap.Add(RenderingLevel, ActiveWidgetArray);
		AddWidgetToViewport(RenderingLevel, Widget, Size, AnchorData);

	}
}


void UWidgetManager::CloseCardTableWidget()
{

	EWidgetRenderingLevel RenderingLevel = EWidgetRenderingLevel::UserTip;
	UWidgetBase* Widget = GetWidget(TEXT("CardTableWidget"));

	RemoveWidgetFromViewport(RenderingLevel, Widget);


}


void UWidgetManager::OpenOperationPanel(const FVector2D& Size, const FAnchorData& AnchorData)
{
	TArray<UWidgetBase*> ActiveWidgetArray;
	EWidgetRenderingLevel RenderingLevel = EWidgetRenderingLevel::HUD;
	UWidgetBase* Widget = GetWidget(TEXT("OperationPanel"));
	if (this->ActiveWidgetMap.Find(RenderingLevel) == nullptr || Widget == nullptr)
	{
		return;
	}

	ActiveWidgetArray = *this->ActiveWidgetMap.Find(RenderingLevel);
	if (ActiveWidgetArray.Contains(Widget) == false)
	{
		ActiveWidgetArray.Add(Widget);
		this->ActiveWidgetMap.Add(RenderingLevel, ActiveWidgetArray);
		AddWidgetToViewport(RenderingLevel, Widget, Size, AnchorData);

	}


}


void UWidgetManager::CloseOperationPanel()
{

	EWidgetRenderingLevel RenderingLevel = EWidgetRenderingLevel::HUD;
	UWidgetBase* Widget = GetWidget(TEXT("OperationPanel"));

	RemoveWidgetFromViewport(RenderingLevel, Widget);


}

void UWidgetManager::OpenPlayerPanel(const FVector2D& Size, const FAnchorData& AnchorData)
{
	TArray<UWidgetBase*> ActiveWidgetArray;
	EWidgetRenderingLevel RenderingLevel = EWidgetRenderingLevel::UserTip;
	UWidgetBase* Widget = GetWidget(TEXT("PlayerPanel"));
	if (this->ActiveWidgetMap.Find(RenderingLevel) == nullptr || Widget == nullptr)
	{
		return;
	}

	ActiveWidgetArray = *this->ActiveWidgetMap.Find(RenderingLevel);
	if (ActiveWidgetArray.Contains(Widget) == false)
	{
		ActiveWidgetArray.Add(Widget);
		this->ActiveWidgetMap.Add(RenderingLevel, ActiveWidgetArray);
		AddWidgetToViewport(RenderingLevel, Widget, Size, AnchorData);

	}
	///////////(*this->ActiveWidgetMap.Find(RenderingLevel)).Add(this->StartMenu);///////////




}



void UWidgetManager::ClosePlayerPanel()
{
	EWidgetRenderingLevel RenderingLevel = EWidgetRenderingLevel::UserTip;
	UWidgetBase* Widget = GetWidget(TEXT("PlayerPanel"));

	RemoveWidgetFromViewport(RenderingLevel, Widget);


}

void UWidgetManager::OpenGameLobbyPanel(const FVector2D& Size, const FAnchorData& AnchorData)
{
	TArray<UWidgetBase*> ActiveWidgetArray;
	EWidgetRenderingLevel RenderingLevel = EWidgetRenderingLevel::HUD;
	UWidgetBase* Widget = GetWidget(TEXT("GameLobbyPanel"));
	if (this->ActiveWidgetMap.Find(RenderingLevel) == nullptr || Widget == nullptr)
	{
		return;
	}

	ActiveWidgetArray = *this->ActiveWidgetMap.Find(RenderingLevel);
	if (ActiveWidgetArray.Contains(Widget) == false)
	{
		ActiveWidgetArray.Add(Widget);
		this->ActiveWidgetMap.Add(RenderingLevel, ActiveWidgetArray);
		AddWidgetToViewport(RenderingLevel, Widget, Size, AnchorData);

	}


}


void UWidgetManager::CloseGameLobbyPanel()
{

	EWidgetRenderingLevel RenderingLevel = EWidgetRenderingLevel::HUD;
	UWidgetBase* Widget = GetWidget(TEXT("GameLobbyPanel"));

	RemoveWidgetFromViewport(RenderingLevel, Widget);


}

void UWidgetManager::OpenGameSessionPanel(const FVector2D& Size, const FAnchorData& AnchorData)
{
	TArray<UWidgetBase*> ActiveWidgetArray;
	EWidgetRenderingLevel RenderingLevel = EWidgetRenderingLevel::HUD;
	UWidgetBase* Widget = GetWidget(TEXT("GameSessionPanel"));
	if (this->ActiveWidgetMap.Find(RenderingLevel) == nullptr || Widget == nullptr)
	{
		return;
	}

	ActiveWidgetArray = *this->ActiveWidgetMap.Find(RenderingLevel);
	if (ActiveWidgetArray.Contains(Widget) == false)
	{
		ActiveWidgetArray.Add(Widget);
		this->ActiveWidgetMap.Add(RenderingLevel, ActiveWidgetArray);
		AddWidgetToViewport(RenderingLevel, Widget, Size, AnchorData);

	}


}


void UWidgetManager::CloseGameSessionPanel()
{

	EWidgetRenderingLevel RenderingLevel = EWidgetRenderingLevel::HUD;
	UWidgetBase* Widget = GetWidget(TEXT("WarningPanel"));

	RemoveWidgetFromViewport(RenderingLevel, Widget);


}

void UWidgetManager::OpenWarningPanel(const FVector2D& Size, const FAnchorData& AnchorData, const FName& WarningName)
{
	TArray<UWidgetBase*> ActiveWidgetArray;
	EWidgetRenderingLevel RenderingLevel = EWidgetRenderingLevel::HUD;
	UWidgetBase* Widget = GetWidget(TEXT("WarningPanel"));
	FString Description;
	if (this->WarningPanelDecriptionMap.Find(WarningName) != nullptr)
	{
		Description = *this->WarningPanelDecriptionMap.Find(WarningName);
	}
	if (this->ActiveWidgetMap.Find(RenderingLevel) == nullptr || Widget == nullptr)
	{
		return;
	}

	ActiveWidgetArray = *this->ActiveWidgetMap.Find(RenderingLevel);
	if (ActiveWidgetArray.Contains(Widget) == false)
	{
		ActiveWidgetArray.Add(Widget);
		this->ActiveWidgetMap.Add(RenderingLevel, ActiveWidgetArray);
		Cast<UWarningPanel>(Widget)->SetDescription(Description);

		AddWidgetToViewport(RenderingLevel, Widget, Size, AnchorData);

	}

}


void UWidgetManager::CloseWarningPanel()
{
	EWidgetRenderingLevel RenderingLevel = EWidgetRenderingLevel::HUD;
	UWidgetBase* Widget = GetWidget(TEXT("WarningPanel"));

	RemoveWidgetFromViewport(RenderingLevel, Widget);


}

void UWidgetManager::OpenResourcePanel(const FVector2D& Size, const FAnchorData& AnchorData)
{
	
	TArray<UWidgetBase*> ActiveWidgetArray;
	EWidgetRenderingLevel RenderingLevel = EWidgetRenderingLevel::UserTip;
	UWidgetBase* Widget = GetWidget(TEXT("ResourcePanel"));
	if (this->ActiveWidgetMap.Find(RenderingLevel) == nullptr || Widget == nullptr)
	{
		return;
	}

	ActiveWidgetArray = *this->ActiveWidgetMap.Find(RenderingLevel);
	if (ActiveWidgetArray.Contains(Widget) == false)
	{
		ActiveWidgetArray.Add(Widget);
		this->ActiveWidgetMap.Add(RenderingLevel, ActiveWidgetArray);
		AddWidgetToViewport(RenderingLevel, Widget, Size, AnchorData);

	}

}


void UWidgetManager::CloseResourcePanel()
{
	EWidgetRenderingLevel RenderingLevel = EWidgetRenderingLevel::UserTip;
	UWidgetBase* Widget = GetWidget(TEXT("ResourcePanel"));

	RemoveWidgetFromViewport(RenderingLevel, Widget);


}


void UWidgetManager::OpenComboBoxMenu(UComboBoxMenuWidget* Menu, const FVector2D& Size, const FAnchorData& AnchorData)
{
	TArray<UWidgetBase*> ActiveWidgetArray;
	EWidgetRenderingLevel RenderingLevel = EWidgetRenderingLevel::HUD;
	if (this->ActiveWidgetMap.Find(RenderingLevel) == nullptr || Menu == nullptr)
	{
		return;
	}

	ActiveWidgetArray = *this->ActiveWidgetMap.Find(RenderingLevel);
	if (ActiveWidgetArray.Contains(Menu) == false)
	{
		ActiveWidgetArray.Add(Menu);
		this->ActiveWidgetMap.Add(RenderingLevel, ActiveWidgetArray);
		AddWidgetToViewport(RenderingLevel, Menu, Size, AnchorData);

	}
	

}



void UWidgetManager::CloseComboBoxMenu(UComboBoxMenuWidget* Menu)
{
	TArray<UWidgetBase*> ActiveWidgetArray;
	EWidgetRenderingLevel RenderingLevel = EWidgetRenderingLevel::HUD;
	if (this->ActiveWidgetMap.Find(RenderingLevel) == nullptr)
	{
		return;
	}
	ActiveWidgetArray = *this->ActiveWidgetMap.Find(RenderingLevel);
	if (ActiveWidgetArray.Contains(Menu) == true)
	{
		RemoveWidgetFromViewport(RenderingLevel, Menu);
	}


}



void UWidgetManager::OpenStartMenu(const FVector2D& Size, const FAnchorData& AnchorData)
{
	TArray<UWidgetBase*> ActiveWidgetArray;
	EWidgetRenderingLevel RenderingLevel = EWidgetRenderingLevel::HUD;
	UWidgetBase* Widget = GetWidget(TEXT("StartMenu"));
	if (this->ActiveWidgetMap.Find(RenderingLevel) == nullptr || Widget == nullptr)
	{
		return;
	}

	ActiveWidgetArray = *this->ActiveWidgetMap.Find(RenderingLevel);
	if (ActiveWidgetArray.Contains(Widget) == false)
	{
		ActiveWidgetArray.Add(Widget);
		this->ActiveWidgetMap.Add(RenderingLevel, ActiveWidgetArray);
		AddWidgetToViewport(RenderingLevel, Widget, Size, AnchorData);

	}
	///////////(*this->ActiveWidgetMap.Find(RenderingLevel)).Add(this->StartMenu);///////////
	



}



void UWidgetManager::CloseStartMenu()
{
	EWidgetRenderingLevel RenderingLevel = EWidgetRenderingLevel::HUD;
	UWidgetBase* Widget = GetWidget(TEXT("StartMenu"));

	RemoveWidgetFromViewport(RenderingLevel,Widget);


}

void UWidgetManager::OpenGameMainPage(const FVector2D& Size, const FAnchorData& AnchorData)
{
	TArray<UWidgetBase*> ActiveWidgetArray;
	EWidgetRenderingLevel RenderingLevel = EWidgetRenderingLevel::HUD;
	UWidgetBase* Widget = GetWidget(TEXT("GameMainPage"));

	if (this->ActiveWidgetMap.Find(RenderingLevel) == nullptr || Widget == nullptr)
	{
		return;
	}

	ActiveWidgetArray = *this->ActiveWidgetMap.Find(RenderingLevel);
	if (ActiveWidgetArray.Contains(Widget) == false)
	{
		ActiveWidgetArray.Add(Widget);
		this->ActiveWidgetMap.Add(RenderingLevel, ActiveWidgetArray);
		AddWidgetToViewport(RenderingLevel, Widget, Size, AnchorData);

	}

}



void UWidgetManager::CloseGameMainPage()
{
	EWidgetRenderingLevel RenderingLevel = EWidgetRenderingLevel::HUD;
	UWidgetBase* Widget = GetWidget(TEXT("GameMainPage"));

	RemoveWidgetFromViewport(RenderingLevel, Widget);

}

void UWidgetManager::OpenGameSettingsPanel(const FVector2D& Size, const FAnchorData& AnchorData)
{
	TArray<UWidgetBase*> ActiveWidgetArray;
	EWidgetRenderingLevel RenderingLevel = EWidgetRenderingLevel::HUD;
	UWidgetBase* Widget = GetWidget(TEXT("GameSettingsPanel"));
	if (this->ActiveWidgetMap.Find(RenderingLevel) == nullptr || Widget == nullptr)
	{
		return;
	}

	ActiveWidgetArray = *this->ActiveWidgetMap.Find(RenderingLevel);
	if (ActiveWidgetArray.Contains(Widget) == false)
	{
		ActiveWidgetArray.Add(Widget);
		this->ActiveWidgetMap.Add(RenderingLevel, ActiveWidgetArray);
		AddWidgetToViewport(RenderingLevel, Widget, Size, AnchorData);

	}


}


void UWidgetManager::CloseGameSettingsPanel(UFTL_GameInstance* GameInstance)
{
	EWidgetRenderingLevel RenderingLevel = EWidgetRenderingLevel::HUD;
	UWidgetBase* Widget = GetWidget(TEXT("GameSettingsPanel"));

	RemoveWidgetFromViewport(RenderingLevel, Widget);

}

void UWidgetManager::UpdateBackGroundImage(UFTL_GameInstance* GameInstance,const FName& BackGroundName)
{
	if (GameInstance ==nullptr)
	{
		return;
	}
	UTexture2D* NewBackGround = nullptr;
	if (BackGroundName == TEXT("None"))
	{
		GetBackGroundWidget()->HideBackGroundImage();
		return;
	}

	NewBackGround = *GameInstance->GetAssetManager()->WidgetAsset.BackGroundWidget.BackGroundImageMap.Find(BackGroundName);
	GetBackGroundWidget()->SetBackGroundImage(NewBackGround);
	GetBackGroundWidget()->ShowBackGroundImage();


}


void UWidgetManager::OnWidgetAddToHUD(TArray<UWidgetBase*> ActiveWidgetArray)
{
	int32 Number = ActiveWidgetArray.Num();
	if (ActiveWidgetArray.IsValidIndex(Number - 1) == true)
	{
		ActiveWidgetArray[Number - 1]->SetVisibility(ESlateVisibility::Visible);
	}
	if (ActiveWidgetArray.IsValidIndex(Number - 2) == true)
	{
		ActiveWidgetArray[Number - 2]->SetVisibility(ESlateVisibility::HitTestInvisible);
	}


}


void UWidgetManager::OnWidgetRemoveFromHUD(TArray<UWidgetBase*> ActiveWidgetArray)
{
	int32 Number = ActiveWidgetArray.Num();

	if (ActiveWidgetArray.IsValidIndex(Number - 1) == true)
	{
		ActiveWidgetArray[Number - 1]->SetVisibility(ESlateVisibility::Visible);
	}
	

}








