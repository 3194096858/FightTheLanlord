﻿

#include "Manager/CardLibrary.h"

#include "Struct/CardInformation.h"
#include "GameInstance/FTL_GameInstance.h"
#include "Manager/DelegateManager.h"
#include "Manager/FTL_AssetManager.h"
#include "GlobalStaticFunctionLibrary/GlobalStaticFunctionLibrary.h"
#include "Kismet/GameplayStatics.h"
#include "PlayerState/FTL_PlayerStateBase.h"
#include "GameState/FTL_GameStateBase.h"


void UCardLibrary::Initialize(UFTL_GameInstance* GameInstance)
{
	if (GameInstance == nullptr || this->CardArray.Num() != 0)
	{
		return;
	}

	UDataTable* Table = GameInstance->GetAssetManager()->GetCardInformationTable();
	if (Table != nullptr)
	{
		Table->GetAllRows<FCardInformation>(TEXT(""), this->CardArray);
	}



}


FCardInformation UCardLibrary::GetRandomCard()
{
	
	FCardInformation Card;
	int32 Index = 0;
	if (this->CardArray.Num() == 0)
	{
		return Card;
	}
	Index = FMath::RandRange(0,this->CardArray.Num()-1);
	Card = *this->CardArray[Index];
	this->CardArray.RemoveAt(Index);
	this->ActiveCardArray.Add(&Card);	
	return Card;

}



FCardInformation UCardLibrary::GetCardByIndex(int32 CardIndex)
{
	FCardInformation Card;
	/*if (CardArray.Num() == 0)
	{
		return Card;
	}
	if (CardArray.IsValidIndex(CardIndex) == true)
	{
		Card = *CardArray[CardIndex];
		CardArray.RemoveAt(CardIndex);
	}*/
	return Card;
}



