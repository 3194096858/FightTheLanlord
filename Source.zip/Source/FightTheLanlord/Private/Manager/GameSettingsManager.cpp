﻿

#include "Manager/GameSettingsManager.h"


#include "GameFramework//GameUserSettings.h"
#include "Kismet/KismetSystemLibrary.h"







UGameSettingsManager::UGameSettingsManager()
{
	this->ResolutionMap.Add(TEXT("1280 x 720"), FIntPoint(1280, 720));
	this->ResolutionMap.Add(TEXT("1920 x 1080"), FIntPoint(1920, 1080));
	this->ResolutionMap.Add(TEXT("2560 x 1440"), FIntPoint(2560, 1440));
	///this->ResolutionMap.Add(TEXT("FullScreen"), FIntPoint(0.0f));

}


bool UGameSettingsManager::CheckResolutionIsExist(const FIntPoint& Resolution)
{
	
	return this->ResolutionMap.FindKey(Resolution) != nullptr ? true : false;
}

bool UGameSettingsManager::CheckResolutionIsExist(const FString& Resolution)
{
	
	return this->ResolutionMap.Find(Resolution) != nullptr ? true : false;

}

void UGameSettingsManager::GetAllResolution(TArray<FString>& ResolutionArray)
{
	TArray<FString> ResolutionArray_String;
	this->ResolutionMap.GenerateKeyArray(ResolutionArray_String);

	if (ResolutionArray_String.Num() == 0)
	{
		return;
	}
	ResolutionArray_String.Add(TEXT("FullScreen"));
	ResolutionArray = ResolutionArray_String;


}

void UGameSettingsManager::GetAllResolution(TArray<FIntPoint>& ResolutionArray)
{
	this->ResolutionMap.GenerateValueArray(ResolutionArray);



}


void UGameSettingsManager::SetScreenResolution(const FIntPoint& NewResolution)
{
	FIntPoint CurrentResolution;
	GetScreenResolution(CurrentResolution);
	if (CheckResolutionIsExist(NewResolution) ==false || CurrentResolution == NewResolution)
	{
		return;
	}
	GetGameUserSettings()->SetScreenResolution(NewResolution);
	GetGameUserSettings()->ApplySettings(false);

}

void UGameSettingsManager::SetScreenResolution(const FString& NewResolution)
{
	FIntPoint CurrentResolution;
	FIntPoint* Resolution = this->ResolutionMap.Find(NewResolution);
	GetScreenResolution(CurrentResolution);
	if (Resolution!=nullptr && CurrentResolution != *Resolution)
	{
		GetGameUserSettings()->SetScreenResolution(*Resolution);
		GetGameUserSettings()->ApplySettings(false);
	}

	/*NewResolution.ParseIntoArray(StringArray,TEXT(" x "));
	if (StringArray.Num() == 2)
	{
		Resolution.X = FCString::Atoi(*StringArray[0]);
		Resolution.Y = FCString::Atoi(*StringArray[1]);
	}*/
	

	
}


void UGameSettingsManager::GetScreenResolution(FIntPoint& CurrentResolution)
{
	CurrentResolution = GetGameUserSettings()->GetScreenResolution();

}


void UGameSettingsManager::GetScreenResolution(FString& CurrentResolution)
{
	FIntPoint Resolution = FIntPoint(0);
	GetScreenResolution(Resolution);
	if (CheckResolutionIsExist(Resolution) == true)
	{
		CurrentResolution = *this->ResolutionMap.FindKey(Resolution);

	}

}


UGameUserSettings* UGameSettingsManager::GetGameUserSettings()
{
	if (this->UserSettings == nullptr)
	{
		this->UserSettings = GEngine->GetGameUserSettings();
	}

	return this->UserSettings;
}


void UGameSettingsManager::SetWindowMode(const EWindowMode::Type& NewMode)
{
	EWindowMode::Type CurrentMode = GetWindowMode();
	if (CurrentMode != NewMode)
	{
		GetGameUserSettings()->SetFullscreenMode(NewMode);
		GetGameUserSettings()->ApplySettings(false);
	}

}



EWindowMode::Type UGameSettingsManager::GetWindowMode()
{
	return GetGameUserSettings()->GetFullscreenMode();
}



















