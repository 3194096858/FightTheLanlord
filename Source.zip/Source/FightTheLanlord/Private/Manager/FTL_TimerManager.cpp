﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "Manager/FTL_TimerManager.h"


int32 UFTL_TimerManager::GetRandomID()
{
	uint32 ID = 0;
	while (true)
	{
		ID = FMath::RandRange(0, 9999);
		if (this->TimerHandleMap.Find(ID) == nullptr)
		{
			return ID;
		}
	}

}

FTimerHandle UFTL_TimerManager::GetTimerHandle(uint32 ID, bool& IsExists)
{
	FTimerHandle Timer;
	if (this->TimerHandleMap.Find(ID) == nullptr)
	{
		IsExists = false;
		return Timer;
	}
	IsExists = true;
	return *this->TimerHandleMap.Find(ID);

}


void UFTL_TimerManager::ClearTimer(uint32 ID)
{
	bool IsExists = false;
	UObject* Object = nullptr;
	FTimerHandle Timer = GetTimerHandle(ID, IsExists);
	if (IsExists == false)
	{
		return;
	}
	GetWorld()->GetTimerManager().ClearTimer(Timer);
	this->TimerHandleMap.Remove(ID);
	
}



void UFTL_TimerManager::ClearAllTimer()
{
	if (this->TimerHandleMap.Num() == 0)
	{
		return;
	}
	for (auto& Element : this->TimerHandleMap)
	{
		GetWorld()->GetTimerManager().ClearTimer(Element.Value);

	}
	this->TimerHandleMap.Empty();
}

void UFTL_TimerManager::ClearAllTimerForObject(UObject* Object)
{
	if (this->TimerHandleMap.Num() == 0 || Object == nullptr )
	{
		return;
	}
	
	GetWorld()->GetTimerManager().ClearAllTimersForObject(Object);

}


void UFTL_TimerManager::PauseAllTimer()
{
	if (this->TimerHandleMap.Num() == 0)
	{
		return;
	}
	for (auto& Element : this->TimerHandleMap)
	{
		if (GetWorld()->GetTimerManager().IsTimerActive(Element.Value) == true)
		{
			GetWorld()->GetTimerManager().PauseTimer(Element.Value);

		}

	}

}


void UFTL_TimerManager::UnpauseAllTimer()
{
	if (this->TimerHandleMap.Num() == 0)
	{
		return;
	}
	for (auto& Element : this->TimerHandleMap)
	{
		if (GetWorld()->GetTimerManager().IsTimerPaused(Element.Value) == true)
		{
			GetWorld()->GetTimerManager().UnPauseTimer(Element.Value);
		}
	}

}


bool UFTL_TimerManager::CheckTimerIsExists(uint32 ID)
{
	return this->TimerHandleMap.Find(ID) != nullptr;

}


bool UFTL_TimerManager::CheckTimerIsPause(uint32 ID)
{
	bool IsExists = false;
	FTimerHandle Timer = GetTimerHandle(ID, IsExists);
	if (IsExists == false)
	{
		return false;
	}
	return GetWorld()->GetTimerManager().IsTimerPaused(Timer);
}


void UFTL_TimerManager::PauseTimer(uint32 ID)
{
	bool IsExists = false;
	FTimerHandle Timer = GetTimerHandle(ID, IsExists);
	if (IsExists == false)
	{
		return;
	}
	GetWorld()->GetTimerManager().PauseTimer(Timer);

}

void UFTL_TimerManager::UnpauseTimer(uint32 ID)
{
	bool IsExists = false;
	FTimerHandle Timer = GetTimerHandle(ID, IsExists);
	if (IsExists == false)
	{
		return;
	}
	if (GetWorld()->GetTimerManager().IsTimerPaused(Timer) == false)
	{
		return;
	}
	GetWorld()->GetTimerManager().UnPauseTimer(Timer);


}


float UFTL_TimerManager::GetTimerRemainingTime(uint32 ID)
{
	bool IsExists = false;
	FTimerHandle Timer = GetTimerHandle(ID, IsExists);
	if (IsExists == false)
	{
		return -1.0f;
	}
	return GetWorld()->GetTimerManager().GetTimerRemaining(Timer);

}


