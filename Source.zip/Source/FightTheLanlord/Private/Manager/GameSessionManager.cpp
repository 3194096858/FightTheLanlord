﻿

#include "Manager/GameSessionManager.h"

#include "GameInstance/FTL_GameInstance.h"
#include "Manager/DelegateManager.h"
#include "Kismet/GameplayStatics.h"
#include "PlayerState/FTL_PlayerStateBase.h"
#include "GameState/FTL_GameStateBase.h"
#include "Interfaces/OnlineIdentityInterface.h"
UGameSessionManager::UGameSessionManager()
{
	
	this->SessionSearchSettings = MakeShared<FOnlineSessionSearch>();

}


IOnlineSubsystem* UGameSessionManager::GetOnlineSubsystem()
{
	if (this->OnlineSubsystem == nullptr)
	{
		this->OnlineSubsystem = IOnlineSubsystem::Get();
	}
	return this->OnlineSubsystem;
}

void UGameSessionManager::CreateSession()
{
	
	int32 Index = 1;
	FString SessionName = TEXT("本地房间") + FString::FromInt(Index);
	while (this->LocalSessionMap.Find(SessionName)!=nullptr)
	{
		Index++;
		SessionName = TEXT("本地房间") + FString::FromInt(Index);
	}
	FOnlineSessionSettings Settings;
	Settings.NumPublicConnections = 3;
	Settings.bIsLANMatch = true;
	Settings.bShouldAdvertise = true;
	Settings.bAllowJoinInProgress = false;
	///Settings.bUsesPresence = false;
	///Settings.bAllowJoinViaPresence = false;
	FOnCreateSessionCompleteDelegate OnCreateSessionCompleteDelegate = FOnCreateSessionCompleteDelegate::CreateUObject(this, &UGameSessionManager::OnCreateSessionFinish);
	this->CreateSessionHandle = GetOnlineSubsystem()->GetSessionInterface()->AddOnCreateSessionCompleteDelegate_Handle(OnCreateSessionCompleteDelegate);
	GetOnlineSubsystem()->GetSessionInterface()->CreateSession(0, FName(SessionName), Settings);
	this->OnCreateSession.Broadcast();
}


void UGameSessionManager::SearchSession()
{
	if (this->SessionSearchSettings ==nullptr)
	{
		return;
	}
	FOnFindSessionsCompleteDelegate OnFindSessionCompleteDelegate = FOnFindSessionsCompleteDelegate::CreateUObject(this, &UGameSessionManager::OnSearchSessionFinish);
	this->SearchSessionHandle = GetOnlineSubsystem()->GetSessionInterface()->AddOnFindSessionsCompleteDelegate_Handle(OnFindSessionCompleteDelegate);

	GetOnlineSubsystem()->GetSessionInterface()->FindSessions(0, this->SessionSearchSettings.ToSharedRef());
	this->OnSearchSession.Broadcast();

	
}

void UGameSessionManager::JoinSession(const FString& SessionName, const FOnlineSessionSearchResult& SearchResult)
{
	/*if (this->JoinedSessionIDArray.Contains(GetRemoteSession(SessionName)->GetSessionIdStr()) == true)
	{
		GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Red, TEXT("已经进入过该房间，无法再次进入 ！！！！"));
		return;
	}*/
	FOnJoinSessionCompleteDelegate OnJoinSessionCompleteDelegate = FOnJoinSessionCompleteDelegate::CreateUObject(this, &UGameSessionManager::OnJoinSessionFinish);
	this->JoinSessionHandle = GetOnlineSubsystem()->GetSessionInterface()->AddOnJoinSessionCompleteDelegate_Handle(OnJoinSessionCompleteDelegate);
	
	FNamedOnlineSession* Session = GetOnlineSubsystem()->GetSessionInterface()->GetNamedSession(FName(SessionName));
	GetOnlineSubsystem()->GetSessionInterface()->JoinSession(0,FName(SessionName),SearchResult);
	this->OnJoinSession.Broadcast();
	/*FOnSessionFailureDelegate OnSessionFailureDelegate = FOnSessionFailureDelegate::CreateUObject(this, &UGameSessionManager::OnSessionConnectInterrupt);
	this->SessionConnectFailureHandle = GetOnlineSubsystem()->GetSessionInterface()->AddOnSessionFailureDelegate_Handle(OnSessionFailureDelegate);*/

}

void UGameSessionManager::JoinSelectedSession()
{
	if (this->SelectedSessionName == TEXT("None"))
	{
		return;

	}
	/*if (this->JoinedSessionIDArray.Contains(GetRemoteSession(this->SelectedSessionName)->GetSessionIdStr()) == true)
	{
		GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Red, TEXT("已经进入过该房间，无法再次进入 ！！！！"));
		return;
	}*/
	FOnJoinSessionCompleteDelegate OnJoinSessionCompleteDelegate = FOnJoinSessionCompleteDelegate::CreateUObject(this, &UGameSessionManager::OnJoinSessionFinish);
	this->JoinSessionHandle = GetOnlineSubsystem()->GetSessionInterface()->AddOnJoinSessionCompleteDelegate_Handle(OnJoinSessionCompleteDelegate);
	FOnlineSessionSearchResult* SearchResult = GetRemoteSession(this->SelectedSessionName);
	if (SearchResult == nullptr)
	{
		return;
	}
	GetOnlineSubsystem()->GetSessionInterface()->JoinSession(0, FName(this->SelectedSessionName), *SearchResult);
	this->OnJoinSession.Broadcast();

}

void UGameSessionManager::DestroySession(const FString& SessionName)
{
	FOnDestroySessionCompleteDelegate OnDestroySessionCompleteDelegate = FOnDestroySessionCompleteDelegate::CreateUObject(this, &UGameSessionManager::OnDestroySessionFinish);
	this->DestroySessionHandle = GetOnlineSubsystem()->GetSessionInterface()->AddOnDestroySessionCompleteDelegate_Handle(OnDestroySessionCompleteDelegate);
	GetOnlineSubsystem()->GetSessionInterface()->DestroySession(FName(SessionName));
	///GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, TEXT("Destroy Session !!!!"));
	this->OnDestroySession.Broadcast();

}

void UGameSessionManager::DestroySelectedSession()
{
	if (this->SelectedSessionName == TEXT("None"))
	{
		return;

	}
	FOnDestroySessionCompleteDelegate OnDestroySessionCompleteDelegate = FOnDestroySessionCompleteDelegate::CreateUObject(this, &UGameSessionManager::OnDestroySessionFinish);
	this->DestroySessionHandle = GetOnlineSubsystem()->GetSessionInterface()->AddOnDestroySessionCompleteDelegate_Handle(OnDestroySessionCompleteDelegate);
	GetOnlineSubsystem()->GetSessionInterface()->DestroySession(FName(this->SelectedSessionName));
	///GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, TEXT("Destroy Session !!!!"));
	this->OnDestroySession.Broadcast();

}
void UGameSessionManager::QuitCurrentSession()
{
	if (this->CurrentSessionName == TEXT("None"))
	{
		return;
	}
	FOnDestroySessionCompleteDelegate OnDestroySessionCompleteDelegate = FOnDestroySessionCompleteDelegate::CreateUObject(this, &UGameSessionManager::OnDestroySessionFinish);
	this->DestroySessionHandle = GetOnlineSubsystem()->GetSessionInterface()->AddOnDestroySessionCompleteDelegate_Handle(OnDestroySessionCompleteDelegate);
	this->IsQuit = true;
	GetOnlineSubsystem()->GetSessionInterface()->DestroySession(FName(this->CurrentSessionName));
	

}


void UGameSessionManager::QuitSession(const FString& SessionName)
{
	FOnDestroySessionCompleteDelegate OnDestroySessionCompleteDelegate = FOnDestroySessionCompleteDelegate::CreateUObject(this, &UGameSessionManager::OnDestroySessionFinish);
	this->DestroySessionHandle = GetOnlineSubsystem()->GetSessionInterface()->AddOnDestroySessionCompleteDelegate_Handle(OnDestroySessionCompleteDelegate);
	this->IsQuit = true;
	GetOnlineSubsystem()->GetSessionInterface()->DestroySession(FName(SessionName));

}

FNamedOnlineSession* UGameSessionManager::GetLocalSession(const FString& SessionName)
{
	return GetOnlineSubsystem()->GetSessionInterface()->GetNamedSession(FName(SessionName));

}

TArray<FNamedOnlineSession*> UGameSessionManager::GetAllLocalSession()
{
	TArray<FNamedOnlineSession*> SessionArray;
	this->LocalSessionMap.GenerateValueArray(SessionArray);
	return SessionArray;
}


FOnlineSessionSearchResult* UGameSessionManager::GetRemoteSession(const FString& SessionName)
{
	FOnlineSessionSearchResult** SearchResult = this->RemoteSessionMap.Find(SessionName);
	if (SearchResult == nullptr)
	{
		return nullptr;
	}

	return *SearchResult;

}
//
//TArray<FOnlineSession*> UGameSessionManager::GetAllRemoteSession()
//{
//	TArray<FOnlineSession*> SessionArray;
//
//	this->RemoteSessionMap.GenerateValueArray(SessionArray);
//	return SessionArray;
//
//}

FString UGameSessionManager::GetLocalSessionName(FNamedOnlineSession* Session)
{
	const FString* Name;
	Name = this->LocalSessionMap.FindKey(Session);
	if (Name!=nullptr)
	{
		return *Name;
	}
	return TEXT("InvalidLocalSession");

}

FString UGameSessionManager::GetRemoteSessionName(FOnlineSessionSearchResult* SearchResult)
{
	const FString* Name = nullptr;
	Name = this->RemoteSessionMap.FindKey(SearchResult);
	if (Name != nullptr)
	{
		return *Name;
	}
	return TEXT("InvalidRemoteSession");
}

void UGameSessionManager::GetHostIPAndPort(const FName& SessionName,FString& IP, FString& Port)
{
	FString ConnectInformation;
	GetOnlineSubsystem()->GetSessionInterface()->GetResolvedConnectString(SessionName,ConnectInformation);
	ConnectInformation.Split(TEXT(":"),&IP,&Port);


}

void UGameSessionManager::SetSelectedSessionName(const FString& NewSession)
{
	this->SelectedSessionName = NewSession;
}

void UGameSessionManager::SetCurrentSessionName(const FString& NewSession)
{
    this->CurrentSessionName = NewSession;
}

FString UGameSessionManager::GetSelectedSessionName()
{
	return this->SelectedSessionName;
}

FString UGameSessionManager::GetCurrentSessionName()
{
	return this->CurrentSessionName;
}



bool UGameSessionManager::CheckIsLocalSession(const FString& SessionName)
{
	return this->LocalSessionMap.Find(SessionName) != nullptr;

}


void UGameSessionManager::OnCreateSessionFinish(FName SessionName, bool bWasSuccessful)
{
	GetOnlineSubsystem()->GetSessionInterface()->ClearOnCreateSessionCompleteDelegate_Handle(this->CreateSessionHandle);
	this->CreateSessionHandle.Reset();
	if (bWasSuccessful == false)
	{
		/////GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, TEXT("No Create Session  !!!!"));
		return;
	}
	FNamedOnlineSession* Session = GetOnlineSubsystem()->GetSessionInterface()->GetNamedSession(SessionName);
	this->OnCreateSessionComplete.Broadcast(SessionName);
	FString Name = SessionName.ToString();
	if (this->LocalSessionMap.Find(Name) == nullptr)
	{
		this->LocalSessionMap.Add(Name, Session);
	}
	GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, FString::Printf(TEXT("LocalSessionID = %s"), *Session->SessionInfo->GetSessionId().ToString()));
	Session->SessionInfo->GetSessionId();
	

}


void UGameSessionManager::OnJoinSessionFinish(FName SessionName, EOnJoinSessionCompleteResult::Type Result)
{
	GetOnlineSubsystem()->GetSessionInterface()->ClearOnJoinSessionCompleteDelegate_Handle(this->JoinSessionHandle);
	this->JoinSessionHandle.Reset();
	switch (Result)
	{
	case EOnJoinSessionCompleteResult::AlreadyInSession:
		GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, FString::Printf(TEXT(" Join Session : AlreadyInSession")));

		break;
	case EOnJoinSessionCompleteResult::SessionIsFull:
		GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, FString::Printf(TEXT(" Join Session : SessionIsFull")));

		break;
	case EOnJoinSessionCompleteResult::SessionDoesNotExist:
		GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, FString::Printf(TEXT(" Join Session : SessionDoesNotExist")));

		break;
	case EOnJoinSessionCompleteResult::CouldNotRetrieveAddress:
		GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, FString::Printf(TEXT(" Join Session : CouldNotRetrieveAddress")));

		break;
	case EOnJoinSessionCompleteResult::UnknownError:
		GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, FString::Printf(TEXT("Join Session : UnknownError")));

		break;
	case EOnJoinSessionCompleteResult::Success:
		this->OnJoinSessionComplete.Broadcast(SessionName);
		this->CurrentSessionName = SessionName.ToString();
		this->JoinedSessionIDArray.Add(GetRemoteSession(SessionName.ToString())->GetSessionIdStr());
		GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, FString::Printf(TEXT(" Join Session : Success , ID = %s "), *GetRemoteSession(SessionName.ToString())->GetSessionIdStr()));

		break;

	}
	

}


void UGameSessionManager::OnSearchSessionFinish(bool bWasSuccessful)
{
	GetOnlineSubsystem()->GetSessionInterface()->ClearOnFindSessionsCompleteDelegate_Handle(this->SearchSessionHandle);
	this->CreateSessionHandle.Reset();
	if (this->SessionSearchSettings == nullptr)
	{
		return;
	}
	int32 Index = 0;
	FString SessionName;
	for (auto& Element : this->SessionSearchSettings->SearchResults)
	{
		Index++;
		SessionName = TEXT("非本地房间") + FString::FromInt(Index);
		if (this->RemoteSessionMap.Find(SessionName) == nullptr)
		{
			this->RemoteSessionMap.Add(SessionName, &Element);
		}

	}
	this->OnSearchSessionComplete.Broadcast(this->SessionSearchSettings);
	GEngine->AddOnScreenDebugMessage(-1,11.0f,FColor::Blue,FString::Printf(TEXT("Search Result : %d"), this->SessionSearchSettings->SearchResults.Num()));

	////GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, FString::Printf(TEXT("Number 222222222= %d"), this->RemoteSessionMap.Num()));

}

void UGameSessionManager::OnDestroySessionFinish(FName SessionName, bool bWasSuccessful)
{
	GetOnlineSubsystem()->GetSessionInterface()->ClearOnDestroySessionCompleteDelegate_Handle(this->DestroySessionHandle);
	this->DestroySessionHandle.Reset();
	if (bWasSuccessful == false)
	{
		GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, TEXT("No Destroy Session  !!!!"));
		return;
	}
	FString Name = SessionName.ToString();
	if (this->LocalSessionMap.Find(Name) != nullptr)
	{
		this->LocalSessionMap.Remove(Name);
	}
	if (this->RemoteSessionMap.Find(Name) != nullptr)
	{
		this->RemoteSessionMap.Remove(Name);
	}
	if (this->IsQuit == true)
	{
		this->IsQuit = false;
		this->OnQuitSessionComplete.Broadcast(SessionName);
		GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, TEXT("Quit Session Complete !!!!"));
	}
	else
	{
		this->OnDestroySessionComplete.Broadcast(SessionName);
		GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, TEXT("Destroy Session Complete !!!!"));

	}
	this->CurrentSessionName = TEXT("None");
	this->SelectedSessionName = TEXT("None");

}


void UGameSessionManager::OnSessionConnectInterrupt(const FUniqueNetId& NetId, ESessionFailure::Type FailureType)
{
	/*GetOnlineSubsystem()->GetSessionInterface()->ClearOnSessionFailureDelegate_Handle(this->SessionConnectFailureHandle);
	this->SessionConnectFailureHandle.Reset();
	GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, TEXT(" Session Connect Failure !!!!"));
*/

}