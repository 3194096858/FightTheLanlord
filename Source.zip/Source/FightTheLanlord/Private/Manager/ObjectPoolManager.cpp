﻿
#include "Manager/ObjectPoolManager.h"
#include "GameInstance/FTL_GameInstance.h"

#include "Manager/DelegateManager.h"


void UObjectPoolManager::ReturnObject(UFTL_GameInstance* GameInstance, const FString& PoolName, AActor* Object)
{
	TSet<AActor*> Pool;
	if (this->ObjectPoolMap.Find(PoolName) == nullptr)
	{
        Pool.Add(Object);
		this->ObjectPoolMap.Add(PoolName, Pool);
	}
	else
	{
		Pool = *this->ObjectPoolMap.Find(PoolName);
		Pool.Add(Object);
	}
	if (GameInstance->GetDelegateManager() != nullptr)
	{
		GameInstance->GetDelegateManager()->OnObjectEndPlay.Broadcast(Object);
	}



}

























