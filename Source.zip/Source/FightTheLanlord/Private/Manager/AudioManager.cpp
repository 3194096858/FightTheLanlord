﻿

#include "Manager/AudioManager.h"


#include "Components/AudioComponent.h"
#include "GameInstance/FTL_GameInstance.h"

#include "Kismet/GameplayStatics.h"

#include "Manager/FTL_AssetManager.h"
#include "Sound/SoundMix.h"
#include "GameState/FTL_GameStateBase.h"

UAudioManager::UAudioManager()
{


}

void UAudioManager::Initialize(UFTL_GameInstance* GameInstance)
{
	if (GameInstance == nullptr)
	{
		return;
	}
	UAudioComponent* AudioComponent = nullptr;
	USoundBase* BGM = nullptr;
	for (auto& Element : GameInstance->GetAssetManager()->GetAllBGMName())
	{
		BGM = GameInstance->GetAssetManager()->GetBGM(Element);
		AudioComponent = UGameplayStatics::CreateSound2D(GameInstance, BGM, 1.0f, 1.0f, 1.0f, nullptr, true, false);
		this->BGMAudioComponentMap.Add(Element, AudioComponent);
		AudioComponent->bStopWhenOwnerDestroyed = false;
	}
}



void UAudioManager::PlayBGM(const FString& BGMName)
{
	if (GetBGMAudioComponent(BGMName) == nullptr)
	{
		///GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, FString::Printf(TEXT("BGM == nullptr: BGMName = %s !!!!"),*BGMName));

		return;
	}
	EAudioComponentPlayState CurrentState = GetBGMAudioComponent(BGMName)->GetPlayState();
	if (CurrentState == EAudioComponentPlayState::Stopped)
	{
		GetBGMAudioComponent(BGMName)->Play();
	}
	else
	{
		UnpauseBGM(BGMName);

	}
}





void UAudioManager::PauseBGM(const FString& BGMName)
{
	if (GetBGMAudioComponent(BGMName) == nullptr)
	{
		return;
	}
	EAudioComponentPlayState CurrentState = GetBGMAudioComponent(BGMName)->GetPlayState();
	if (CurrentState == EAudioComponentPlayState::Playing)
	{
		GetBGMAudioComponent(BGMName)->SetPaused(true);
	}


}

void UAudioManager::PauseAllBGM()
{
	for (auto& Element:this->BGMAudioComponentMap)
	{
		PauseBGM(Element.Key);
	}


}




void UAudioManager::UnpauseBGM(const FString& BGMName)
{
	if (GetBGMAudioComponent(BGMName) == nullptr)
	{
		return;
	}
	EAudioComponentPlayState CurrentState = GetBGMAudioComponent(BGMName)->GetPlayState();

	if (CurrentState == EAudioComponentPlayState::Paused)
	{
		GetBGMAudioComponent(BGMName)->SetPaused(false);
	}

}





void UAudioManager::PlaySFX(USoundBase* SFX)
{
	if (SFX == nullptr)
	{
		GEngine->AddOnScreenDebugMessage(-1, 11.0f, FColor::Blue, FString::Printf(TEXT("SFX == nullptr    !!!!")));

		return;
	}
	UGameplayStatics::PlaySound2D(GetWorld(), SFX);

}





UAudioComponent* UAudioManager::GetBGMAudioComponent(const FString& BGMName)
{
	if (this->BGMAudioComponentMap.Find(BGMName) == nullptr)
	{
		return nullptr;
	}
	return *this->BGMAudioComponentMap.Find(BGMName);
}

void UAudioManager::SetBGMVolume(USoundMix* SoundMix, USoundClass* BGMSoundClass, float NewVolume)
{
	
	UGameplayStatics::SetSoundMixClassOverride(this, SoundMix,BGMSoundClass,NewVolume);

}


void UAudioManager::SetSFXVolume(USoundMix* SoundMix, USoundClass* SFXSoundClass, float NewVolume)
{

	UGameplayStatics::SetSoundMixClassOverride(this, SoundMix, SFXSoundClass, NewVolume);

}

